﻿
namespace CassPort.ApiGateway
{
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Hosting;
    using Microsoft.Extensions.Logging;
    using Ocelot.DependencyInjection;
    using Ocelot.Middleware;
    using Serilog;
    using CassPort.Core.Models;
    using CassPort.Infrastructure.Middleware;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;

    public class Startup
    {

        public Startup(IConfiguration configuration, ILogger<Startup> logger)
        {
            ILogger<Startup> _logger;
            Log.Logger = new LoggerConfiguration()
                               .ReadFrom.Configuration(configuration)
                               .CreateLogger();
            Configuration = configuration;

            _logger = logger;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddOcelot();
            services.AddCors();

            // Get Application Name
            IConfigurationSection appConfig = this.Configuration.GetSection("Source");
            services.Configure<ApplicationConfig>(appConfig);
            services.AddScoped<UserProfile>();
            services.AddMvc(option => option.EnableEndpointRouting = false);
            services.AddLogging((builder) =>
            {
                builder.AddSerilog(dispose: true);
            });
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }

            app.UseCors(x => x
               .AllowAnyOrigin()
               .AllowAnyMethod()
               .AllowAnyHeader());

            app.UseRouting();
            app.UseHttpsRedirection();                                 
            app.UseScopedLoggingMiddleware();
            app.UseExceptionMiddleware();
            app.UseOcelot();           
        }
    }
}
