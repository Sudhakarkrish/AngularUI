using CassPort.Core.Models;
using NUnit.Framework;
using System.Threading.Tasks;
using System.Collections.Generic;
using CassPort.Core.Services;
using Moq;
using CassPort.Core.Repositories;

namespace CassPort.Core.Test
{
    public class MenuServiceTest
    {
        [SetUp]
        public void Setup()
        {

        }

        /// <summary>
        /// GetMenusTest when MenuItemDetail contains LinkUrl as javascript...
        /// </summary>
        /// <returns></returns>
        [Test]
        public async Task GetMenusTest()
        {
            List<MenuItemDetail> menuList = new List<MenuItemDetail>();
            MenuItemDetail menu = new MenuItemDetail()
            {
                MenuGroup = "client",
                LinkUrl = "javascript"
            };
            menuList.Add(menu);
            var mock = new Mock<IMenuRepository>();
            mock.Setup(p => p.GetMenus()).Returns(Task.FromResult<List<MenuItemDetail>>(menuList));
            MenuService menuService = new MenuService(mock.Object);
            var result = await menuService.GetMenus();
            mock.Verify(p => p.GetMenus(), Times.Once());
            Assert.IsTrue(result != null && result.Count > 0);
        }

        /// <summary>
        /// GetMenusTest when MenuItemDetail contains LinkUrl otherthan javascript...
        /// </summary>
        /// <returns></returns>
        [Test]
        public async Task GetMenusTest1()
        {
            List<MenuItemDetail> menuList = new List<MenuItemDetail>();
            MenuItemDetail menu = new MenuItemDetail()
            {
                MenuGroup = "client",
                LinkUrl = "script"
            };
            menuList.Add(menu);
            var mock = new Mock<IMenuRepository>();
            mock.Setup(p => p.GetMenus()).Returns(Task.FromResult<List<MenuItemDetail>>(menuList));
            MenuService menuService = new MenuService(mock.Object);
            var result = await menuService.GetMenus();
            mock.Verify(p => p.GetMenus(), Times.Once());
            Assert.IsTrue(result != null && result.Count > 0);
        }


    }
}