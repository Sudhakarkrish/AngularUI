﻿namespace CassPort.Core.Common
{
    /// <summary>
    /// Handles Global constants
    /// </summary>
    public static class Constants
    {
        public const string CarrierCompanyType = "C";
        public const string ShipperCompanyType = "S";
        public const string BothCompanyType = "B";
        public const string ListType = "T";
        public const string CONSTSFRCLIENT5 = "SFRCLIENT5";
        public const string CONSTSFRCLIENT4 = "SFRCLIENT4";
        public const string CONSTCLIENTDUPONT = "DUPONT";
        public const string CONSTCLIENTVEOLIA = "VEOLIA";
        public const string CONSTCLIENTCHEMOURS = "CHEMOURS";
        public const string CONSTCASSRESPONSECODE = "CS9";

        public const int CONSTCPPASSWORDMINLENGTH = 8;
        public const int CONSTCPPASSWORDCHANGESUCCESSFUL = 11;

        public const string PwdString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@$?";
        public const string AccessDenied = "AccessDenied";
        public const string Success = "Success";
        public const string Failed = "Failed";
        public const string PwdUpdateFailed = "Your Password failed to update Please try again";
        public const string PwdCombNotMatch = "Current Username and password combination did not match";
        public const string PwdRequNotMatch = "Your Password did not meet the requirements please review them before proceeding";
        public const string LinkExpired = "Your Link is No longer Valid or Has Expired";
        public const string UrlType = "javascript";
        public const string NullVal = "null";
        public const string FilterVal = "0";
        public const string InputVal = "undefined";
        public const string Internal = "Internal";
        public const string External = "External";
        public const string FilterAll = "ALL";
        public const string FilterType = "N";
        public const string FilterCriteriaOver = "OVERDUE";
        public const string FilterCriteriaDisable = "Disable";
        public const string CommandDelete = "Deleted";
        public const string CommandForward = "Forward";
        public const string ErrorNoUser = "No Users Selected";
        public const string UnabletoEditUser = " The user profile you selected is currently being edited and cannot be changed.<br>";
        public const string UserId = "UserId: ";
        public const string UserName = "Username ";
        public const string Successbr = " success.<br>";
        public const string Successfull = "successfully ";
        public const string Space = " ";
        public const string Was = "was ";
        public const string NotEditSameUser = "A user cannot Edit themselves";
        public const string InvalidAttempt = "Invalid edit attempt";
        public const string CassCompanyType = "Cass Internal";
        public const string CompanyType = "I";
        public const string Country = "US";
        public const string PortalHomePage = "PortalWelcome.asp";
        public const string AccessRestricted = "You may not access this user profile";
        public const string CurrentlyEditMode = "You may not access this user profile because it is currently in edit mode";
        public const string ProfileDeleted = "You may no longer access this user profile because it has been deleted from the system";
        public const string ErrorAccess = "There was an Error Accessing the Requested User.";
        public const string AlreadyinEditing = "You have another user account locked for Editing already";
        public const string LoginId = "The Login ID ";
        public const string AlreadyinUse = " is already in use.<br>";
        public const string TryAgain = "Try Again to enter another unique Login ID";
        public const string DupontCode = "The Dupont Dol Code ";
        public const string AnotherUser = " is already in use by another Cass user.";
        public const string DomesticUser = " is already defined in the Domestic User table.";
        public const string InternationalUser = " is already defined in the International User table.";
        public const string ChemoursCode = "The Chemours Dol Code ";
        public const string VeoliaCode = "The Veolia Dol Code ";
        public const string CortevaCode = "The Corteva Dol Code ";
        public const string DowCode = "The DOW Dol Code ";
        public const string WelcomeExternal = "WelcomeExternal";
        public const string Welcome = "Welcome";
        public const string UpdateExternal = "UpdateExternal";
        public const string Update = "Update";
        public const string RegVerification = "Cass Registration Verification";
        public const string UpdateInfo = "Update Information from Cass";
        public const string Shipper = "Shipper";
        public const string Carrier = "Carrier";
        public const string AdminWarning = "AdminWarning";
        public const string ReplaceLoginName = "$$LOGINID$$";
        public const string ReplacePwd = "$$PASSWORD$$";
        public const string UnabletoLocate = "Unable to locate text for letter ";
        public const string CheckDb = "... Check database. ";
        public const string UnabletoRegisterUser = "Unable to Register User: ";
        public const string SuccessfullyRegister = "Successfully Registered User: ";
        public const string FailedUniqueRecord = "FailedInUniqueRecord";
        public const string AdminMenu = "AdminMenu";
        public const string UnabletoEditSameUser = "A user cannot Edit themselves <br>";
        public const string UnabletoFindUser = "Cannot find User to Delete <br>";
        public const string UnabletoDeleteUser = "Unable to Delete User: ";
        public const string SuccessfullyDeleted = " was successfully deleted";
        public const string LineBreak = "<br>";
        public const string Email = "EMAIL";
        public const string SysAdmin = "SysAdmin";
        public const string Selected = "Selected ";
        public const string UnRegisterUser = "unregistered user ";
        public const string HasBeen = "has been ";
        public static class PrivilegeSets
        {
            public static readonly int[] AdminMenu =
            {
                Privileges.AddNewUsersCarriers,
                Privileges.RegisterUsers,
                Privileges.EditRegisteredUsers,
                Privileges.AddNewInternalUsers,
                Privileges.EditRegisteredInternalUsers,
                Privileges.MassModifyClients,
                Privileges.MassModifyCarriers,
                Privileges.LoginMessages,
                Privileges.WhatsNewMessages,
                Privileges.UserAccountLetters,
                Privileges.AnomalyNotificationList,
                Privileges.ImportNotificationList,
                Privileges.CarrierStampAssignment,
                Privileges.UsageList,
                Privileges.UsageSummary,
                Privileges.EventListing,
                Privileges.CategoryListing,
                Privileges.UsageCube,
                Privileges.ImportManager,
                Privileges.BarcodeDuplicates,
                Privileges.BarcodeOrphans,
                Privileges.PrintRejects,
                Privileges.AnomalyManagement,
                Privileges.CubeAdmin,
                Privileges.FaqSets,
                Privileges.FaqGroups,
                Privileges.FaqItems,
                Privileges.SurveyAdmin,
                Privileges.ImportManagerAdmin,
                Privileges.TfaImportManagerView,
                Privileges.TfaImportManagerAdmin,
                Privileges.GapExportManagerView,
                Privileges.GapExportManagerAdmin,
                Privileges.ImageImportManagerView,
                Privileges.ImageImportItAdmin,
                Privileges.ImageImportIcAdmin,
                Privileges.FbaRejectsEditRejectReason,
                Privileges.CustomReportAdmin,
                Privileges.ParcelMaintenance
            };

            public static readonly int[] UserAdmin =
            {
                Privileges.AddNewUsersClients,
                Privileges.AddNewUsersCarriers,
                Privileges.RegisterUsers,
                Privileges.EditRegisteredUsers,
                Privileges.AddNewInternalUsers,
                Privileges.EditRegisteredInternalUsers,
                Privileges.MassModifyCarriers,
                Privileges.MassModifyClients
            };

            public static readonly int[] SiteConfig =
            {
                Privileges.LoginMessages,
                Privileges.WhatsNewMessages,
                Privileges.UserAccountLetters,
                Privileges.AnomalyNotificationList,
                Privileges.ImportNotificationList,
                Privileges.CarrierStampAssignment,
                Privileges.PermissionEditor
            };

            public static readonly int[] ImportManager =
            {
                Privileges.ImportManager,
                Privileges.ImportManagerAdmin,
                Privileges.TfaImportManagerView,
                Privileges.TfaImportManagerAdmin,
                Privileges.GapExportManagerView,
                Privileges.GapExportManagerAdmin,
                Privileges.ImageImportManagerView,
                Privileges.ImageImportItAdmin,
                Privileges.ImageImportIcAdmin
            };

            public static readonly int[] CustomReporting =
            {
                Privileges.BakerCustomReports,
                Privileges.EatonCustomReports
            };

            public static readonly int[] FbaAdmin =
            {
                Privileges.BarcodeDuplicates,
                Privileges.BarcodeOrphans,
                Privileges.FbaRejectsEditRejectReason,
                Privileges.PrintRejects
            };

            public static readonly int[] SpotQuote =
            {
                Privileges.SpotQuoteInquiry,
                Privileges.SpotQuoteAdd,
                Privileges.SpotQuoteRequestDelete,
                Privileges.SpotQuotePerformDelete
            };

            public static readonly int[] AuditContract =
            {
                Privileges.AuditContractUser,
                Privileges.AuditContractAdmin
            };

            public static readonly int[] EmersonContract =
            {
                Privileges.EmersonContractUser,
                Privileges.EmersonContractAdmin
            };

            public static readonly int[] ValidationViewer =
            {
                Privileges.ValidationViewerUser,
                Privileges.ValidationViewerAdmin
            };

            public static readonly int[] StandardReporting =
            {
                Privileges.ProcessedActivity,
                Privileges.AuditSavings,
                Privileges.RejectReportingClient,
                Privileges.CheckRelease,
                Privileges.GlobalProcessedActivitySummary
            };

            public static readonly int[] ParcelService =
            {
                Privileges.ParcelAddressCorrection,
                Privileges.ParcelUnauthorizedAccount,
                Privileges.AssignGlCoding
            };

            public static readonly int[] PortalSuffix =
            {
                Privileges.ProcessedActivity,
                Privileges.AuditSavings,
                Privileges.RejectReportingClient,
                Privileges.CheckRelease,
                Privileges.GlobalProcessedActivitySummary,
            };

            public static readonly int[] Dupont =
            {
                Privileges.DupontAdmin,
                Privileges.SfrEntry,
                Privileges.SetdEntry,
                Privileges.SfrResolution,
                Privileges.SfrValidityReport,
                Privileges.SfrInquiry,
                Privileges.SfrEditDelete,
                Privileges.DupontFreightBillResolution,
                Privileges.DupontCorpTableInquiry,
                Privileges.IsfrInquiry
            };

            public static readonly int[] DupontAdmin =
            {
                Privileges.SfrEntry,
                Privileges.SetdEntry,
                Privileges.SfrResolution,
                Privileges.SfrValidityReport,
                Privileges.SfrInquiry,
                Privileges.SfrEditDelete,
                Privileges.DupontFreightBillResolution,
                Privileges.IsfrInquiry,
                Privileges.DupontFbInquiry,
                Privileges.DupontResolvedSfrs,
                Privileges.DupontIsfrResolution,
                Privileges.DupontResolvedIsfrs,
                Privileges.DupontResolvedFb,
                Privileges.DupontIsfrValidityReport,
                Privileges.DupontCorpTableInquiry
            };

            public static readonly int[] Chemours =
            {
                Privileges.ChemoursSfrEntry,
                Privileges.ChemoursSetdEntry,
                Privileges.ChemoursSfrResolution,
                Privileges.ChemoursSfrValidityReport,
                Privileges.ChemoursSfrInquiry,
                Privileges.ChemoursSfrEditDelete,
                Privileges.ChemoursResolvedFbInquiry,
                Privileges.ChemoursCorpTableInquiry,
                Privileges.ChemoursIsfrInquiry
            };

            public static readonly int[] ChemoursAdmin =
            {
                Privileges.ChemoursAdmin,
                Privileges.ChemoursSfrEntry,
                Privileges.ChemoursSetdEntry,
                Privileges.ChemoursSfrResolution,
                Privileges.ChemoursSfrValidityReport,
                Privileges.ChemoursSfrInquiry,
                Privileges.ChemoursSfrEditDelete,
                Privileges.ChemoursSuspendedFreightBills,
                Privileges.ChemoursIsfrInquiry,
                Privileges.ChemoursResolvedFbInquiry,
                Privileges.ChemoursResolvedSfrs,
                Privileges.ChemoursIsfrResolution,
                Privileges.ChemoursResolvedIsfrs,
                Privileges.ChemoursResolvedFb,
                Privileges.ChemoursIsfrValidityReport,
                Privileges.ChemoursCorpTableInquiry,
            };

            public static readonly int[] Veolia =
            {
                Privileges.VeoliaAdmin,
                Privileges.VeoliaSfrEntry,
                Privileges.VeoliaSetdEntry,
                Privileges.VeoliaSfrResolution,
                Privileges.VeoliaSfrValidityReport,
                Privileges.VeoliaSfrInquiry,
                Privileges.VeoliaSfrEditDelete,
                Privileges.VeoliaResolvedFbInquiry,
                Privileges.VeoliaCorpTableInquiry,
                Privileges.VeoliaIsfrInquiry
            };

            public static readonly int[] VeoliaAdmin =
            {
                Privileges.VeoliaSfrEntry,
                Privileges.VeoliaSetdEntry,
                Privileges.VeoliaSfrResolution,
                Privileges.VeoliaSfrValidityReport,
                Privileges.VeoliaSfrInquiry,
                Privileges.VeoliaSfrEditDelete,
                Privileges.VeoliaSuspendedFreightBills,
                Privileges.VeoliaIsfrInquiry,
                Privileges.VeoliaResolvedFbInquiry,
                Privileges.VeoliaResolvedSfrs,
                Privileges.VeoliaIsfrResolution,
                Privileges.VeoliaResolvedIsfrs,
                Privileges.VeoliaResolvedFb,
                Privileges.VeoliaIsfrValidityReport,
                Privileges.VeoliaCorpTableInquiry,
            };

            public static readonly int[] SfrClient4Admin =
            {
                Privileges.SfrClient4SfrEntry,
                Privileges.SfrClient4SetdEntry,
                Privileges.SfrClient4SfrResolution,
                Privileges.SfrClient4SfrValidityReport,
                Privileges.SfrClient4SfrInquiry,
                Privileges.SfrClient4SfrEditDelete,
                Privileges.SfrClient4SuspendedFreightBills,
                Privileges.SfrClient4IsfrInquiry,
                Privileges.SfrClient4ResolvedFbInquiry,
                Privileges.SfrClient4ResolvedSfrs,
                Privileges.SfrClient4IsfrResolution,
                Privileges.SfrClient4ResolvedIsfrs,
                Privileges.SfrClient4ResolvedFb,
                Privileges.SfrClient4IsfrValidityReport,
                Privileges.SfrClient4CorpTableInquiry,
            };

            public static readonly int[] SfrClient5Admin =
            {
                Privileges.SfrClient5SfrEntry,
                Privileges.SfrClient5SetdEntry,
                Privileges.SfrClient5SfrResolution,
                Privileges.SfrClient5SfrValidityReport,
                Privileges.SfrClient5SfrInquiry,
                Privileges.SfrClient5SfrEditDelete,
                Privileges.SfrClient5SuspendedFreightBills,
                Privileges.SfrClient5IsfrInquiry,
                Privileges.SfrClient5ResolvedFbInquiry,
                Privileges.SfrClient5ResolvedSfrs,
                Privileges.SfrClient5IsfrResolution,
                Privileges.SfrClient5ResolvedIsfrs,
                Privileges.SfrClient5ResolvedFb,
                Privileges.SfrClient5IsfrValidityReport,
                Privileges.SfrClient5CorpTableInquiry,
            };
        }

        public static class Privileges
        {
            public const int Inquiry = 1;
            public const int Fba = 2;
            public const int RemittanceReporting = 3;
            public const int RejectReportingCarrier = 4;
            public const int BillingInstructions = 5;
            public const int RemittanceExport = 6;
            public const int RejectExport = 7;
            public const int ProcessedActivity = 8;
            public const int AuditSavings = 9;
            public const int RejectReportingClient = 10;
            public const int CheckRelease = 11;
            public const int TransportationAccounting = 12;
            public const int AddNewUsersClients = 14;
            public const int AddNewUsersCarriers = 15;
            public const int RegisterUsers = 16;
            public const int EditRegisteredUsers = 17;
            public const int AddNewInternalUsers = 18;
            public const int EditRegisteredInternalUsers = 19;
            public const int MassModifyClients = 20;
            public const int MassModifyCarriers = 21;
            public const int LoginMessages = 22;
            public const int WhatsNewMessages = 23;
            public const int UserAccountLetters = 24;
            public const int AnomalyNotificationList = 25;
            public const int ImportNotificationList = 26;
            public const int CarrierStampAssignment = 27;
            public const int UsageList = 28;
            public const int UsageSummary = 29;
            public const int EventListing = 30;
            public const int CategoryListing = 31;
            public const int BarcodeDuplicates = 32;
            public const int BarcodeOrphans = 33;
            public const int PrintRejects = 34;
            public const int AnomalyManagement = 35;
            public const int OverrideLoginStatus = 36;
            public const int AdminStl = 37;
            public const int AdminBos = 38;
            public const int AdminCol = 39;
            public const int CubeAdmin = 41;
            public const int ClientRelations = 42;
            public const int ImportManager = 43;
            public const int Sourcenet = 44;
            public const int Imageless = 45;
            public const int FaqSets = 46;
            public const int FaqGroups = 47;
            public const int FaqItems = 48;
            public const int FbaRejectsMassModApprove = 49;
            public const int FbaRejectsMassModReject = 50;
            public const int FbaRejectsMassModDelete = 51;
            public const int UsageCube = 52;
            public const int SurveyAdmin = 53;
            public const int GapCheckReports = 54;
            public const int GapCheckEntry = 55;
            public const int CustomCubeAdmin = 56;
            public const int FaqUserSetListing = 57;
            public const int Transinq = 58;
            public const int GlobalProcessedActivitySummary = 59;
            public const int CubeTotals = 60;
            public const int DeleteImage = 61;
            public const int ImportManagerAdmin = 62;
            public const int TfaImportManagerView = 63;
            public const int TfaImportManagerAdmin = 64;
            public const int GapExportManagerView = 65;
            public const int GapExportManagerAdmin = 66;
            public const int ImageImportManagerView = 67;
            public const int ImageImportItAdmin = 68;
            public const int ImageImportIcAdmin = 69;
            public const int CustomReportAdmin = 70;
            public const int DebitMemo = 71;
            public const int PermissionEditor = 72;
            public const int UpsReporting = 73;
            public const int DupontAdmin = 74;
            public const int SfrEntry = 75;
            public const int SetdEntry = 76;
            public const int SfrResolution = 77;
            public const int SfrValidityReport = 78;
            public const int SfrInquiry = 79;
            public const int SfrEditDelete = 80;
            public const int DupontFreightBillResolution = 81;
            public const int DupontCorpTableInquiry = 82;
            public const int AuditContractUser = 83;
            public const int AuditContractAdmin = 84;
            public const int IsfrInquiry = 85;
            public const int BarcodeInquiry = 86;
            public const int ClientDataInquiry = 87;
            public const int DupontLoginMessage = 88;
            public const int DupontFbInquiry = 89;
            public const int DupontResolvedSfrs = 90;
            public const int DupontIsfrResolution = 91;
            public const int DupontResolvedIsfrs = 92;
            public const int DupontResolvedFb = 93;
            public const int DupontIsfrValidityReport = 94;
            public const int FbaRejectsEditRejectReason = 95;
            public const int SubaruUpsReporting = 96;
            public const int FbaPriorityPay = 97;
            public const int EmersonContractUser = 98;
            public const int EmersonContractAdmin = 99;
            public const int ValidationViewerUser = 100;
            public const int ValidationViewerAdmin = 101;
            public const int BakerCustomReports = 102;
            public const int EatonCustomReports = 103;
            public const int IrFreightPlanAssignment = 104;
            public const int ShipperProfileEdit = 105;
            public const int SuspenseResolution = 106;
            public const int SuspenseMetricReporting = 107;
            public const int ParcelUnauthorizedAccount = 108;
            public const int ParcelMaintenance = 109;
            public const int ParcelAddressCorrection = 110;
            public const int SuspenseEditAmounts = 111;
            public const int AssignGlCoding = 112;
            public const int UpdateValidationFiles = 113;
            public const int CarrierProfile = 114;
            public const int Benchmarking = 115;
            public const int ClientManuals = 116;
            public const int DupontSfrPurge = 117;
            public const int DupontIsfrPurge = 118;
            public const int InvoiceRouting = 119;
            public const int FordAisAssignment = 120;
            public const int CarrierHistory = 121;
            public const int PrivImageArchive = 122;
            public const int ParcelAuditSavings = 123;
            public const int TransportationAccountingVerii = 124;
            public const int BusinessAnalytics = 125;
            public const int BusinessAnalyticsTfa = 126;
            public const int BusinessAnalyticsParcel = 127;
            public const int BusinessAnalyticsBenchmarking = 128;
            public const int BusinessAnalyticsPayment = 129;
            public const int BusinessAnalyticsBenchmarkingPlus = 130;
            public const int TransinqSunJava = 131;
            public const int SpotQuoteInquiry = 132;
            public const int SpotQuoteAdd = 133;
            public const int SpotQuoteRequestDelete = 134;
            public const int SpotQuotePerformDelete = 135;
            public const int IpBolEntry = 136;
            public const int IpBolInquiry = 137;
            public const int RatemakerSearch = 138;
            public const int GlobalCollaboration = 139;
            public const int GlobalAuditCollaboration = 140;
            public const int GlobaDataEntry = 141;
            public const int WebForms = 142;
            public const int GlobalInquiry = 143;
            public const int CreditAndDataChangesView = 144;
            public const int CreditAndDataChangesEdit = 145;
            public const int ChemoursSfrEntry = 146;
            public const int ChemoursSetdEntry = 147;
            public const int ChemoursSfrResolution = 148;
            public const int ChemoursSfrValidityReport = 149;
            public const int ChemoursSfrInquiry = 150;
            public const int ChemoursSfrEditDelete = 151;
            public const int ChemoursSuspendedFreightBills = 152;
            public const int ChemoursCorpTableInquiry = 153;
            public const int ChemoursIsfrInquiry = 154;
            public const int ChemoursResolvedFbInquiry = 155;
            public const int ChemoursResolvedSfrs = 156;
            public const int ChemoursIsfrResolution = 157;
            public const int ChemoursResolvedIsfrs = 158;
            public const int ChemoursResolvedFb = 159;
            public const int ChemoursIsfrValidityReport = 160;
            public const int ChemoursPurgedSfr = 161;
            public const int ChemoursPurgedIsfr = 162;
            public const int ChemoursAdmin = 163;
            public const int ChemoursLoginMessage = 164;
            public const int GlobalLeadOperator = 165;
            public const int GlobalCollaborationFba = 166;
            public const int GlobalCombinedCollaboration = 167;
            public const int CombinedCollaborationShipmentResolution = 168;
            public const int CombinedCollaborationFba = 169;
            public const int CombinedCollaborationInquiry = 170;
            public const int InvoiceUpload = 171;
            public const int VeoliaSfrEntry = 172;
            public const int VeoliaSetdEntry = 173;
            public const int VeoliaSfrResolution = 174;
            public const int VeoliaSfrValidityReport = 175;
            public const int VeoliaSfrInquiry = 176;
            public const int VeoliaSfrEditDelete = 177;
            public const int VeoliaSuspendedFreightBills = 178;
            public const int VeoliaCorpTableInquiry = 179;
            public const int VeoliaIsfrInquiry = 180;
            public const int VeoliaResolvedFbInquiry = 181;
            public const int VeoliaResolvedSfrs = 182;
            public const int VeoliaIsfrResolution = 183;
            public const int VeoliaResolvedIsfrs = 184;
            public const int VeoliaResolvedFb = 185;
            public const int VeoliaIsfrValidityReport = 186;
            public const int VeoliaPurgedSfr = 187;
            public const int VeoliaPurgedIsfr = 188;
            public const int VeoliaAdmin = 189;
            public const int VeoliaLoginMessage = 190;
            public const int SfrClient4SfrEntry = 191;
            public const int SfrClient4SetdEntry = 192;
            public const int SfrClient4SfrResolution = 193;
            public const int SfrClient4SfrValidityReport = 194;
            public const int SfrClient4SfrInquiry = 195;
            public const int SfrClient4SfrEditDelete = 196;
            public const int SfrClient4SuspendedFreightBills = 197;
            public const int SfrClient4CorpTableInquiry = 198;
            public const int SfrClient4IsfrInquiry = 199;
            public const int SfrClient4ResolvedFbInquiry = 200;
            public const int SfrClient4ResolvedSfrs = 201;
            public const int SfrClient4IsfrResolution = 202;
            public const int SfrClient4ResolvedIsfrs = 203;
            public const int SfrClient4ResolvedFb = 204;
            public const int SfrClient4IsfrValidityReport = 205;
            public const int SfrClient4PurgedSfr = 206;
            public const int SfrClient4PurgedIsfr = 207;
            public const int SfrClient4Admin = 208;
            public const int SfrClient4LoginMessage = 209;
            public const int SfrClient5SfrEntry = 217;
            public const int SfrClient5SetdEntry = 218;
            public const int SfrClient5SfrResolution = 219;
            public const int SfrClient5SfrValidityReport = 220;
            public const int SfrClient5SfrInquiry = 221;
            public const int SfrClient5SfrEditDelete = 222;
            public const int SfrClient5SuspendedFreightBills = 223;
            public const int SfrClient5CorpTableInquiry = 224;
            public const int SfrClient5IsfrInquiry = 225;
            public const int SfrClient5ResolvedFbInquiry = 226;
            public const int SfrClient5ResolvedSfrs = 227;
            public const int SfrClient5IsfrResolution = 228;
            public const int SfrClient5ResolvedIsfrs = 229;
            public const int SfrClient5ResolvedFb = 230;
            public const int SfrClient5IsfrValidityReport = 231;
            public const int SfrClient5PurgedSfr = 232;
            public const int SfrClient5PurgedIsfr = 233;
            public const int SfrClient5Admin = 234;
            public const int SfrClient5LoginMessage = 235;
        }
    }
}