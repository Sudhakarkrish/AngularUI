﻿namespace CassPort.Core.Common
{
    using System;
    using System.Diagnostics;
    using System.IO;
    using System.Net.Mail;
    using System.Text;
    using CassPort.Core.Models;
    using Microsoft.Extensions.Configuration;

    /// <summary>
    /// Utility functions.
    /// </summary>
    public static class Utils
    {
        public static ConfigurationBuilder AppConfiguration()
        {
            var configurationBuilder = new ConfigurationBuilder();
            var path = string.Empty;
            if (Debugger.IsAttached)
            {
                 path = Path.Combine(Directory.GetCurrentDirectory(), "appsettings.json");
            }
            else
            {
                 path = Path.Combine(Directory.GetCurrentDirectory(), "appsettings." + Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") + ".json");
            }

            configurationBuilder.AddJsonFile(path, false);
            return configurationBuilder;
        }

        public static async System.Threading.Tasks.Task SendMailBackground(string recipientAddress, string subject, string body, bool isHtml = false)
        {
            await SendMailAsync(recipientAddress, subject, body, isHtml);
        }

        public static async System.Threading.Tasks.Task SendMailAsync(string recipientAddress, string subject, string body, bool isHtml = false)
        {
            var root = AppConfiguration().Build();
            string mailHost = Convert.ToString(root.GetSection("ForgotPassword").GetSection("EmailServer").Value) ?? "exchange.cassinfo.com";
            string fromAddress = Convert.ToString(root.GetSection("ForgotPassword").GetSection("EMAIL_ALIAS").Value) ?? "noreply@cassinfo.com";
            using (var mailClient = new SmtpClient(mailHost))
            {
                var msg = new MailMessage()
                {
                    Body = body,
                    From = new MailAddress(fromAddress),
                    IsBodyHtml = isHtml,
                    Subject = subject,
                };
                foreach (string recipient in recipientAddress.Split(
                    new[] { ',', ';', ' ' },
                    StringSplitOptions.RemoveEmptyEntries))
                {
                    msg.To.Add(recipient);
                }

               await mailClient.SendMailAsync(msg);
            }
        }

        public static string DecodeFrom64(string encodedData)
        {
            byte[] encodedDataAsBytes = Convert.FromBase64String(encodedData);
            return Encoding.ASCII.GetString(encodedDataAsBytes);
        }
    }
}
