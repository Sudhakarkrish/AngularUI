﻿namespace CassPort.Core.Exception
{
    /// <summary>
    /// Custom Exception.
    /// </summary>
    public class CustomException : System.Exception
    {
        private readonly int code;
        private readonly string description;

        /// <summary>
        ///  Initializes a new instance of the <see cref="CustomException"/> class.
        /// </summary>
        /// <param name="message">Message to handle.</param>
        /// <param name="description">Description of the message.</param>
        /// <param name="code">Message code.</param>
        public CustomException(string message, string description, int code)
            : base(message)
        {
            this.code = code;
            this.description = description;
        }

        /// <summary>
        /// Gets Code.
        /// </summary>
        public int Code
        {
            get => this.code;
        }

        /// <summary>
        /// Gets Description.
        /// </summary>
        public string Description
        {
            get => this.description;
        }
    }
}
