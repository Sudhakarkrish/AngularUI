﻿namespace CassPort.Core.Models
{
    using System.Collections.Generic;

    /// <summary>
    /// Model for main menu
    /// </summary>
    public class Menu
    {
        public string Name { get; set; }

        public string MenuIcon { get; set; }

        public List<MenuGroup> MenuGroup { get; set; }
    }
}
