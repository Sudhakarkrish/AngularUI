﻿namespace CassPort.Core.Models
{
    using System.Collections.Generic;

    /// <summary>
    /// Model for menu group
    /// </summary>
    public class MenuGroup
    {
        public string GroupName { get; set; }

        public string LinkUrl { get; set; }

        public List<MenuItemDetail> MenuItems { get; set; }
    }
}
