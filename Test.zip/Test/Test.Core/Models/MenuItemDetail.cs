﻿namespace CassPort.Core.Models
{
    /// <summary>
    /// Model to capture navigation menu details.
    /// </summary>
    public class MenuItemDetail
    {
        /// <summary>
        /// Gets or sets cassprt Navigation Id.
        /// </summary>
        public int CassportNavItemId { get; set; }

        /// <summary>
        /// Gets or sets cassprt parent Navigation Id.
        /// </summary>
        public int? ParentCassportNavItemId { get; set; }

        /// <summary>
        /// Gets or sets Link url.
        /// </summary>
        public string LinkUrl { get; set; }

        /// <summary>
        /// Gets or sets Text.
        /// </summary>
        public string Text { get; set; }

        /// <summary>
        /// Gets or sets Menu group.
        /// </summary>
        public string MenuGroup { get; set; }

        /// <summary>
        /// Gets or sets login level.
        /// </summary>
        public int? MinLoginLevel { get; set; }

        /// <summary>
        /// Gets or sets user is enable.
        /// </summary>
        public bool? IsEnabled { get; set; }

        /// <summary>
        /// Gets or sets sort order.
        /// </summary>
        public byte? ExplicitSortOrder { get; set; }

        /// <summary>
        /// Gets or sets Group name.
        /// </summary>
        public string GroupName { get; set; }

        /// <summary>
        /// Gets or sets Menu Icon.
        /// </summary>
        public string MenuIcon { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether gets or sets Menu Icon.
        /// </summary>
        public bool IsScriptMenu { get; set; }
    }
}
