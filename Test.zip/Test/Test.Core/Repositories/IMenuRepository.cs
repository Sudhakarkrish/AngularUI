﻿namespace CassPort.Core.Repositories
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CassPort.Core.Models;

    /// <summary>
    /// Menu Repository Interface.
    /// </summary>
    public interface IMenuRepository
    {
        /// <summary>
        /// Get CassPort Menu items.
        /// </summary>
        /// <returns>list of menu items.</returns>
        Task<List<MenuItemDetail>> GetMenus();
    }
}
