﻿namespace CassPort.Core.Services
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CassPort.Core.Models;

    /// <summary>
    /// Menu Service Interface.
    /// </summary>
    public interface IMenuService
    {
        /// <summary>
        /// Get Menu Items for the logged in user.
        /// </summary>
        /// <returns>list of menu items.</returns>
        Task<List<Menu>> GetMenus();
    }
}