﻿namespace CassPort.Core.Services
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CassPort.Core.Common;
    using CassPort.Core.Models;
    using CassPort.Core.Repositories;

    /// <summary>
    /// Menu Service.
    /// </summary>
    public class MenuService : IMenuService
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MenuService"/> class.
        /// </summary>
        /// <param name="menurepository">Data menu repository to handle.</param>
        public MenuService(IMenuRepository menurepository)
        {
            this.MenuRepository = menurepository;
        }

        private IMenuRepository MenuRepository { get; }

        /// <summary>
        /// Get All Menu Items.
        /// </summary>
        /// <returns>List of menu items.</returns>
        public async Task<List<Menu>> GetMenus()
        {
            // Get the menu nav items for the loggedin user
            List<MenuItemDetail> menuItems = await this.MenuRepository.GetMenus();
            if (menuItems.Count > 0)
            {
                // Add the flag to identify the url which call javascript method
                foreach (MenuItemDetail item in menuItems)
                {
                    item.IsScriptMenu = item.LinkUrl.Contains(Constants.UrlType);
                }

                // Group the main menu items based on the groupnames available in the table
                List<Menu> cassMenu = menuItems.ToLookup(m => m.MenuGroup)
                                .Select(item => new Menu { Name = item.Key }).ToList();
                List<Menu> cassMenuIcon = menuItems.ToLookup(m => m.MenuIcon)
                                .Select(item => new Menu { MenuIcon = item.Key }).ToList();

                // Add group icon to the corresponding groupname
                for (int i = 0; i < cassMenuIcon.Count; i++)
                {
                    cassMenu[i].MenuIcon = cassMenuIcon[i].MenuIcon;
                }

                // Add sub group to the Main group along with menu items that are related to the group
                foreach (Menu menu in cassMenu)
                {
                    menu.MenuGroup = menuItems.Where(item => item.MenuGroup == menu.Name).ToLookup(mg => mg.GroupName)
                                       .Select(item => new MenuGroup { GroupName = item.Key }).ToList();
                    foreach (MenuGroup menuGroup in menu.MenuGroup)
                    {
                        menuGroup.MenuItems = menuItems.Where(item => item.MenuGroup == menu.Name && item.GroupName == menuGroup.GroupName && item.Text != menuGroup.GroupName).ToList();

                        if (menuGroup.MenuItems.Count == 0)
                        {
                            MenuItemDetail parentUrl = menuItems.FirstOrDefault(item => item.MenuGroup == menu.Name && item.GroupName == menuGroup.GroupName);
                            menuGroup.LinkUrl = parentUrl?.LinkUrl;
                        }
                    }
                }

                return cassMenu;
            }

            return null;
        }
    }
}