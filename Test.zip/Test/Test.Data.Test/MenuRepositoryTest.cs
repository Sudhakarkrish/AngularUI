using AutoMapper;
using CassPort.Core.Models;
using CassPort.Core.Repositories;
using CassPort.Data.Context;
using CassPort.Data.Entities;
using CassPort.Data.Repositories;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CassPort.Data.Test
{
    public class MenuRepositoryTest
    {
        private UserProfile mockUserProfile;
        private CassPortContext mockContext;
        protected IMapper _mapper;
        private readonly UserProfile userProfile;

        public MenuRepositoryTest(UserProfile userProfile)
        {
            this.userProfile = userProfile;
        }

        private IMenuRepository MenuRepository { get; }

        [SetUp]
        public void Setup()
        {
            var mapperConfiguration = new MapperConfiguration(cfg =>
            {
               
            });            
            _mapper = mapperConfiguration.CreateMapper();

            mockContext = this.GetMockContext();
            mockUserProfile = this.GetMockUserProfile();
        }

        //[Test]
        public async Task GetMenusTest()
        {
            DbContextOptions<CassPortContext> options;
            var builder = new DbContextOptionsBuilder<CassPortContext>();
            builder.UseSqlServer("DummyDatabase");
            options = builder.Options;
            var context = new CassPortContext(options, null, null);
            var mockProvider = new Mock<IQueryProvider>();
            mockProvider.Setup(s => s.CreateQuery(It.IsAny<MethodCallExpression>()))
                .Returns(null as IQueryable);
            var mockDbSet = new Mock<DbSet<CassportNavItem>>();
            mockDbSet.As<IQueryable<CassportNavItem>>()
                .Setup(s => s.Provider)
                .Returns(mockProvider.Object);
            var t = mockDbSet.Object;
            context.CassportNavItem = mockDbSet.Object;

            var menuRepository = new MenuRepository(context, _mapper, mockUserProfile);

            var response = await menuRepository.GetMenus();
            Assert.IsNotNull(response);
            Assert.AreEqual(response.Count, 3);
        }

        private CassPortContext GetMockContext()
        {
            DbContextOptions<CassPortContext> options;
            var builder = new DbContextOptionsBuilder<CassPortContext>();
            builder.UseSqlServer("DummyDatabase");
            options = builder.Options;
            var context = new CassPortContext(options, null, null);

            context.CassportNavItem.Add(new CassportNavItem
            {
                CassportNavItemId=1,
                ExplicitSortOrder =1,
                GroupName ="Client",
                IsEnabled = true,
                MenuGroup ="Group1",
                Text ="Inquiry"
            });

            context.CassportNavItem.Add(new CassportNavItem
            {
                CassportNavItemId = 2,
                ExplicitSortOrder = 1,
                GroupName = "Carrier",
                IsEnabled = true,
                MenuGroup = "Group1",
                Text = "Inquiry"
            });

            context.CassportNavItem.Add(new CassportNavItem
            {
                CassportNavItemId = 3,
                ExplicitSortOrder = 1,
                GroupName = "Admin",
                IsEnabled = true,
                MenuGroup = "Group1",
                Text = "Inquiry"
            });

            context.SaveChanges();

            return context;
        }


        private UserProfile GetMockUserProfile()
        {
            this.userProfile.UserId = 9271;
            this.userProfile.UserName = "SRajendran";
           
            return this.userProfile;
        }
    }
}