﻿namespace CassPort.Data.Context
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CassPort.Data.Common;
    using CassPort.Data.ReportModels;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.SqlServer.Infrastructure.Internal;

    /// <summary>
    /// Profile Context
    /// </summary>
    public class ReportProfileContext : REPORT_CONTROLContext
    {
        private readonly string connectionString;

        /// <summary>
        /// Initializes a new instance of the <see cref="ReportProfileContext"/> class.
        /// ProfileContext Constructor
        /// </summary>
        public ReportProfileContext()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ReportProfileContext"/> class.
        /// ProfileContext Constructor
        /// </summary>
        /// <param name="options">DB Context Options</param>
        public ReportProfileContext(DbContextOptions<REPORT_CONTROLContext> options)
            : base(options)
        {
            var sqlExt = options.Extensions.FirstOrDefault(e => e is SqlServerOptionsExtension);

            this.connectionString = ((SqlServerOptionsExtension)sqlExt).ConnectionString;

            if (this.connectionString == null)
            {
                throw new Exception("Failed to retrieve SQL connection string for base Context");
            }
        }

        public async Task<List<Core.Models.ExportSession>> GetExportSessionMessage(int userId)
        {
            return await this.Query<Core.Models.ExportSession>().FromSqlRaw(DbConstants.SpGetUserExportSessions, userId).ToListAsync();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(this.connectionString);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Query<Core.Models.ExportSession>();
        }
    }
}