﻿namespace CassPort.Data.Context
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CassPort.Core.Common;
    using CassPort.Core.Models;
    using CassPort.Data.Common;
    using CassPort.Data.Entities;
    using Microsoft.Data.SqlClient;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.SqlServer.Infrastructure.Internal;
    using Microsoft.Extensions.Options;
    using Newtonsoft.Json;
    using DashboardCategory = Core.Models.DashboardCategory;

    /// <summary>
    /// Profile Context
    /// </summary>
    public class CassPortContext : CISFBSYSContext
    {
        private readonly string connectionString;

        /// <summary>
        /// Initializes a new instance of the <see cref="CassPortContext"/> class.
        /// ProfileContext Constructor
        /// </summary>
        public CassPortContext()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CassPortContext"/> class.
        /// ProfileContext Constructor
        /// </summary>
        /// <param name="options">DB Context Options</param>
        /// <param name="conString">DB Environment for connection string</param>
        /// <param name="userProfile">user profile</param>
        public CassPortContext(DbContextOptions<CassPortContext> options, UserProfile userProfile, IOptions<DBEnvironments> conString = null)
             : base(options)
        {
            var sqlExt = options.Extensions.FirstOrDefault(e => e is SqlServerOptionsExtension);

            this.connectionString = conString == null ? ((SqlServerOptionsExtension)sqlExt).ConnectionString : conString.Value.CassPortConnection;

            if (this.connectionString == null)
            {
                throw new Exception("Failed to retrieve SQL connection string for base Context");
            }

            this.UserProfile = userProfile;
        }

        public UserProfile UserProfile { get; }

        /// <summary>
        /// Verify is user locked.
        /// </summary>
        /// <param name="userId">pass user id.</param>
        /// <param name="editorId">pass editor id.</param>
        /// <returns>return lock count.</returns>
        public virtual async Task<UserIsLockedByEditingUserCount> VerifyUserIsLockedByEditingUser(int userId, int editorId)
        {
            var editingUserCount = new UserIsLockedByEditingUserCount();
            var count = await Task.FromResult(this.Set<UserIsLockedByEditingUserCount>()
                                              .FromSqlRaw(DbConstants.SpVerifyUserIsLockedByEditingUser, userId, editorId)
                                              .AsEnumerable()
                                              .FirstOrDefault());
            editingUserCount.LOCK_COUNT = count.LOCK_COUNT;

            return editingUserCount;
        }

        public virtual async Task<List<Messages>> GetMyMessagesList(int userId, int iType, int page, int pageSize)
        {
            return await Task.FromResult(this.Set<Messages>()
                                        .FromSqlRaw(DbConstants.SpGetMyMessages, userId, iType, page, pageSize)
                                        .AsEnumerable()
                                        .ToList());
        }

        public virtual async Task<List<HeaderMessages>> GetMyMessagesListForHeader(int userId, int iType)
        {
            return await Task.FromResult(this.Set<HeaderMessages>()
                                        .FromSqlRaw(DbConstants.SpGetMyMessagesForHeader, userId, iType)
                                        .AsEnumerable()
                                        .ToList());
        }

        public virtual async Task<List<ChangePassword>> GetPasswordHistory(int userId, string email)
        {
            return await Task.FromResult(this.Set<ChangePassword>()
                                        .FromSqlRaw(DbConstants.SpGetUserPasswordHistory, null, email, userId)
                                        .AsEnumerable()
                                        .ToList());
        }

        public virtual async Task<ResetPasswordHistory> GetPasswordExpirationDate(string userId, string email, string token)
        {
            return await Task.FromResult(this.Set<ResetPasswordHistory>()
                                        .FromSqlRaw(DbConstants.SpVerifyUserToken, userId, email, token)
                                        .AsEnumerable()
                                        .FirstOrDefault());
        }

        public virtual async Task<List<Core.Models.Carrier>> GetCarriersBySearch(string searchText, string companyType)
        {
            return await Task.FromResult(this.Set<Core.Models.Carrier>()
                                        .FromSqlRaw(DbConstants.SpGetCarriersOrShippers, searchText, companyType)
                                        .AsEnumerable()
                                        .ToList());
        }

        public virtual async Task<List<Core.Models.Carrier>> GetUserCarriers(int userId, bool isStaging = false)
        {
            var spName = isStaging ? DbConstants.SpGetUserStagingCarriers : DbConstants.SpGetUserCarriers;

            return await Task.FromResult(this.Set<Core.Models.Carrier>()
                                        .FromSqlRaw(spName, userId)
                                        .AsEnumerable()
                                        .ToList());
        }

        public virtual async Task<List<Core.Models.Country>> GetCountries()
        {
            return await Task.FromResult(this.Set<Core.Models.Country>()
                                        .FromSqlRaw(DbConstants.SpGetCountries)
                                        .AsEnumerable()
                                        .ToList());
        }

        public virtual async Task<List<Core.Models.State>> GetStates(string countryCode)
        {
            var stateList = await Task.FromResult(this.Set<State>()
                                                 .FromSqlRaw(DbConstants.SpGetStates)
                                                 .AsEnumerable()
                                                 .ToList());
            var stateListBasedOnCountryCode = stateList.Where(o => o.Country_Code == countryCode).Select(s => s).ToList();

            return stateListBasedOnCountryCode;
        }

        public virtual async Task<Core.Models.EditProfile> GetUserAccount(int userId)
        {
            return await Task.FromResult(this.Set<EditProfile>()
                                        .FromSqlRaw(DbConstants.SpGetUserAccount, userId)
                                        .AsEnumerable()
                                        .FirstOrDefault());
        }

        public virtual async Task<List<MyReport>> GetMyReportsList(int userId, int loginLevel)
        {
            return await Task.FromResult(this.Set<MyReport>()
                                        .FromSqlRaw(DbConstants.SpGetUserReports, userId, loginLevel)
                                        .AsEnumerable()
                                        .ToList());
        }

        public virtual async Task<List<MyReport>> GetUserReportBySearch(int userId, int loginLevel, string searchValue)
        {
            return await Task.FromResult(this.Set<MyReport>()
                                        .FromSqlRaw(DbConstants.SpGetUserReportsBySearchValue, userId, loginLevel, searchValue)
                                        .AsEnumerable()
                                        .ToList());
        }

        public virtual async Task<List<Core.Models.ReportInstance>> GetReportInstanceById(int reportId, bool includeExpiration)
        {
            return await Task.FromResult(this.Set<Core.Models.ReportInstance>()
                                        .FromSqlRaw(DbConstants.SpGetReportInstance, reportId, includeExpiration)
                                        .AsEnumerable()
                                        .ToList());
        }

        public virtual async Task<List<Core.Models.ReportInstance>> GetReportInstanceBySearchValue(int reportId, bool includeExpiration, string fromDate, string toDate)
        {
            return await Task.FromResult(this.Set<Core.Models.ReportInstance>()
                                        .FromSqlRaw(DbConstants.SpGetReportInstanceBySearchValue, reportId, includeExpiration, fromDate, toDate)
                                        .AsEnumerable()
                                        .ToList());
        }

        public virtual async Task<List<Core.Models.Shipper>> GetShippersBySearch(string searchText, string companyType)
        {
            return await Task.FromResult(this.Set<Core.Models.Shipper>()
                                        .FromSqlRaw(DbConstants.SpGetCarriersOrShippers, searchText, companyType)
                                        .AsEnumerable()
                                        .ToList());
        }

        public virtual async Task<List<Core.Models.MetricShipper>> GetMetricShippers(int userId)
        {
            return await Task.FromResult(this.Set<MetricShipper>()
                                        .FromSqlRaw(DbConstants.SpGetMetricShippers, userId)
                                        .AsEnumerable()
                                        .ToList());
        }

        public virtual async Task<List<Core.Models.Shipper>> GetUserShippers(int userId, bool isStaging = false)
        {
            var spName = isStaging ? DbConstants.SpGetUserStagingShippers : DbConstants.SpGetUserShippers;
            return await Task.FromResult(this.Set<Core.Models.Shipper>()
                                        .FromSqlRaw(spName, userId)
                                        .AsEnumerable()
                                        .ToList());
        }

        public virtual async Task<List<UserAdministration>> ListUsers(string companyType, string listType, string filterCriteria, string authorizedFilter, string loginLevelCeiling, string loginLevelFloor, string userId, string overdueDays, int page, int pagesize, string sortCol, string sortDir)
        {
            return await Task.FromResult(this.Set<UserAdministration>()
                         .FromSqlRaw(DbConstants.SpListCassportUsersforAdmin, companyType, listType, filterCriteria, overdueDays, authorizedFilter, loginLevelCeiling, loginLevelFloor, userId, page, pagesize, sortCol, sortDir)
                         .AsEnumerable()
                         .ToList());
        }

        /// <summary>
        /// Gets user count.
        /// </summary>
        /// <param name="companyType">Company type.</param>
        /// <param name="listType">list Type.</param>
        /// <param name="filterCriteria">filter Criteria.</param>
        /// <param name="authorizedFilter">authorized Filter.</param>
        /// <param name="loginLevelCeiling">login Level Ceiling.</param>
        /// <param name="loginLevelFloor">loginLevel Floor.</param>
        /// <param name="userId">user Id.</param>
        /// <param name="overdueDays">overdue Days.</param>
        /// <returns>returns users count.</returns>
        public virtual async Task<UserAdministrationCount> ListUsersCount(string companyType, string listType, string filterCriteria, string authorizedFilter, string loginLevelCeiling, string loginLevelFloor, string userId, string overdueDays)
        {
            var userAdministrationCount = new UserAdministrationCount();
            var count = await Task.FromResult(this.Set<UserAdministrationCount>()
                        .FromSqlRaw(DbConstants.SpListCassportUsersforAdminCount, companyType, listType, filterCriteria, overdueDays, authorizedFilter, loginLevelCeiling, loginLevelFloor, userId)
                        .AsEnumerable()
                        .FirstOrDefault());
            userAdministrationCount.TotalCount = count.TotalCount;
            return userAdministrationCount;
        }

        public virtual async Task<UserAdministrationCount> ListAllUsersCount(string filterCriteria, string allValue, int flag, string overdueDays, string name)
        {
            var userAdministrationCount = new UserAdministrationCount();
            var count = this.Set<UserAdministrationCount>()
                            .FromSqlRaw(DbConstants.SpListCassportAllUsersforAdminCount, filterCriteria, allValue, flag, overdueDays, name)
                            .AsEnumerable()
                            .FirstOrDefault();
            userAdministrationCount.TotalCount = count.TotalCount;

            return userAdministrationCount;
        }

        public virtual async Task<List<UserAdministration>> ListAllUsers(string filterCriteria, string allValue, int flag, string overdueDays, int page, int pagesize, string sortCol, string sortDir, string name)
        {
            return await Task.FromResult(this.Set<UserAdministration>()
                         .FromSqlRaw(DbConstants.SpListCassportAllUsersforAdmin, filterCriteria, allValue, flag, overdueDays, page, pagesize, sortCol, sortDir, name)
                         .AsEnumerable()
                         .ToList());
        }

        public async Task<List<UserAdministration>> DisableListUsers(string companyType, string listType, string filterCriteria, string authorizedFilter, string loginLevelCeiling, string loginLevelFloor, string userId, string overdueDays, int page, int pagesize, string sortCol, string sortDir, bool accountEnable)
        {
            return await Task.FromResult(this.Set<UserAdministration>()
                         .FromSqlRaw(DbConstants.SpListCassportDisableUsersforAdmin, companyType, listType, filterCriteria, overdueDays, authorizedFilter, loginLevelCeiling, loginLevelFloor, userId, page, pagesize, sortCol, sortDir, accountEnable)
                         .AsEnumerable()
                         .ToList());
        }

        public async Task<UserAdministrationCount> DisableListUsersCount(string companyType, string listType, string filterCriteria, string authorizedFilter, string loginLevelCeiling, string loginLevelFloor, string userId, string overdueDays, bool accountEnable)
        {
            var userAdministrationCount = new UserAdministrationCount();
            var count = await Task.FromResult(this.Set<UserAdministrationCount>()
                              .FromSqlRaw(DbConstants.SpListCassportDisableUsersforAdminCount, companyType, listType, filterCriteria, overdueDays, authorizedFilter, loginLevelCeiling, loginLevelFloor, userId, accountEnable)
                              .AsEnumerable()
                              .FirstOrDefault());
            userAdministrationCount.TotalCount = count.TotalCount;

            return userAdministrationCount;
        }

        public virtual async Task<List<Core.Models.UserPrivilege>> GetUserPrivilledge(int userId, bool isInternal, string userType)
        {
            return await Task.FromResult(this.Set<Core.Models.UserPrivilege>()
                                        .FromSqlRaw(DbConstants.SpGetUserPrivilegeLimited, userId, isInternal, userType)
                                        .AsEnumerable()
                                        .ToList());
        }

        public virtual async Task<List<ExternalAuthenticator>> GetExternalAuthenticators()
        {
            return await Task.FromResult(this.Set<ExternalAuthenticator>()
                                        .FromSqlRaw(DbConstants.SpGetExternalAuthenticatorIdsAndNames)
                                        .AsEnumerable()
                                        .ToList());
        }

        public virtual async Task<List<ExternalProviderMapping>> GetExternalAuthenticationProviderMappings(int id)
        {
            var mappingJson = await Task.FromResult(this.Set<ExternalProviderMappingJson>()
                                                   .FromSqlRaw(DbConstants.SpGetExternalAuthenticationProviderMappings, id)
                                                   .AsEnumerable()
                                                   .FirstOrDefault());

            return JsonConvert.DeserializeObject<List<ExternalProviderMapping>>(mappingJson.Mapping_Json);
        }

        public virtual async Task<List<PrivilegeGroupList>> GetUserPrivilegeGroups(int userId, bool isInternal, string userType)
        {
            return await Task.FromResult(this.Set<PrivilegeGroupList>()
                                        .FromSqlRaw(DbConstants.SpGetUserPrivilegeGroupsModernized, userId, isInternal, userType)
                                        .AsEnumerable().ToList());
        }

        public virtual async Task<List<UserPrivilege>> GetUserPrivilledgeByGroup(int userId, bool isInternal, string userType)
        {
            return await Task.FromResult(this.Set<UserPrivilege>()
                                        .FromSqlRaw(DbConstants.SpGetUserPrivilegeGroup, userId, isInternal, userType)
                                        .AsEnumerable()
                                        .ToList());
        }

        public virtual async Task<List<UserPrivilege>> GetAllUserPreviledge(int userId)
        {
            return await Task.FromResult(this.Set<UserPrivilege>()
                                        .FromSqlRaw(DbConstants.SpGetUserPrivilege, userId)
                                        .AsEnumerable()
                                        .ToList());
        }

        public virtual async Task<List<Core.Models.UserPrivilege>> GetAddtionalUserPrivileges(string privId, int userId, bool isInternal, string userType)
        {
            return await Task.FromResult(this.Set<UserPrivilege>()
                                        .FromSqlRaw(DbConstants.SpGetEditorUserPrivilege, privId, userId, isInternal, userType)
                                        .AsEnumerable()
                                        .ToList());
        }

        public virtual async Task<ShipPointCount> GetShipPointCount(int userId)
        {
            return await Task.FromResult(this.Set<ShipPointCount>()
                                        .FromSqlRaw(DbConstants.SpGetShipPointCount, userId)
                                        .AsEnumerable()
                                        .FirstOrDefault());
        }

        public virtual async Task<List<ShipPoint>> GetUserShipPoints(int userId, string client)
        {
            string spName = string.Empty;
            switch (client)
            {
                case Constants.CONSTCLIENTDUPONT:
                    spName = DbConstants.SpGetDupontUserShipPoints;
                    break;

                case Constants.CONSTCLIENTCHEMOURS:
                    spName = DbConstants.SpGetChemoursUserShipPoints;
                    break;

                case Constants.CONSTCLIENTVEOLIA:
                    spName = DbConstants.SpGetVeoliaUserShipPoints;
                    break;

                case Constants.CONSTSFRCLIENT4:
                    spName = DbConstants.SpGetSFRClient4UserShipPoints;
                    break;

                case Constants.CONSTSFRCLIENT5:
                    spName = DbConstants.SpGetSFRClient5UserShipPoints;
                    break;

                default:
                    throw new InvalidOperationException("Unknown Ship Point Company Code " + client);
            }

            return await Task.FromResult(this.Set<ShipPoint>().FromSqlRaw(spName, userId).AsEnumerable().ToList());
        }

        public virtual async Task<List<ShipPointData>> GetClientShipPoints(string searchVal, string client)
        {
            string spName = string.Empty;
            switch (client)
            {
                case Constants.CONSTCLIENTDUPONT:
                    spName = DbConstants.SpGetDupontShipPoints;
                    break;

                case Constants.CONSTCLIENTCHEMOURS:
                    spName = DbConstants.SpGetChemoursShipPoints;
                    break;

                case Constants.CONSTCLIENTVEOLIA:
                    spName = DbConstants.SpGetVeoliaShipPoints;
                    break;

                case Constants.CONSTSFRCLIENT4:
                    spName = DbConstants.SpGetSFRClient4ShipPoints;
                    break;

                case Constants.CONSTSFRCLIENT5:
                    spName = DbConstants.SpGetSFRClient5ShipPoints;
                    break;

                default:
                    throw new InvalidOperationException("Unknown Ship Point Company Code " + client);
            }

            return await Task.FromResult(this.Set<ShipPointData>().FromSqlRaw(spName, searchVal).AsEnumerable().ToList());
        }

        public virtual ISEmailAvailable IsExternalEmailAvailable(int userId, string email, int providerId)
        {
            var emailcount = new ISEmailAvailable();
            var count = this.Set<ISEmailAvailable>().FromSqlRaw(DbConstants.SpIsExternalEmailAvailable, userId, email, providerId).AsEnumerable().FirstOrDefault();
            emailcount.IS_AVAILABLE = count.IS_AVAILABLE;

            return emailcount;
        }

        public virtual Core.Models.Letter GetLetterText(string letterName)
        {
            var letter = new Core.Models.Letter();
            var count = this.Set<Core.Models.Letter>().FromSqlRaw(DbConstants.SpGetLetterText, letterName).AsEnumerable().FirstOrDefault();
            letter.LETTER_TEXT = count.LETTER_TEXT;

            return letter;
        }

        public DolCodeCount CheckUniqueDolCode(string spName, string dolCode, int userId)
        {
            var dolcode = new DolCodeCount();
            var count = this.Set<DolCodeCount>().FromSqlRaw(spName, dolCode, userId).AsEnumerable().FirstOrDefault();
            dolcode.Value_Count = count.Value_Count;

            return dolcode;
        }

        public virtual AccountID VerifyAdminCanEditUser(int userId, int editorId)
        {
            var user = new AccountID();
            var count = this.Set<AccountID>().FromSqlRaw(DbConstants.SpVerifyAdminCanEditUser, userId, editorId).AsEnumerable().FirstOrDefault();
            user.USER_ACCOUNT_ID = count.USER_ACCOUNT_ID;

            return user;
        }

        public virtual ActiveDirectory VerifyUserInAD(string email)
        {
            var active = new Core.Models.ActiveDirectory();
            var activeDirectory = this.Set<ActiveDirectory>().FromSqlRaw(DbConstants.SpVerifyUserInAD, email).AsEnumerable().FirstOrDefault();
            if (activeDirectory != null)
            {
                active.NT_USER_NAME = Convert.ToString(activeDirectory.NT_USER_NAME);
            }
            else
            {
                active.NT_USER_NAME = null;
            }

            return active;
        }

        public virtual int CreateDashboard(CreateDashboard model)
        {
            SqlParameter dashboardId = new SqlParameter("@DashboardId", model.DashboardId);
            SqlParameter dashboardName = new SqlParameter("@DashboardName", model.DashboardName);
            SqlParameter dashboardDisplayName = new SqlParameter("@DashboardDisplayName", model.DashboardDisplayName);
            SqlParameter dashboardUrl = new SqlParameter("@DashboardUrl", model.DashboardUrl);
            SqlParameter dashboardType = new SqlParameter("@DashboardType", model.DashboardType);
            SqlParameter dashboardCategory = new SqlParameter("@DashboardCategory", model.DashboardCategory);
            SqlParameter isInternal = new SqlParameter("@IsInternal", model.IsInternal);
            SqlParameter isDeleted = new SqlParameter("@IsDeleted", model.IsDeleted);
            SqlParameter isPremiumDashboard = new SqlParameter("@IsPremiumDashboard", model.IsPremiumDashboard);
            SqlParameter isAssignAlluser = new SqlParameter("@IsAssignAlluser", model.IsAssignAlluser);
            string sqlQuery = DbConstants.SPCreateTableauDashboard +
                                "@DashboardId,@DashboardName,@DashboardDisplayName,@DashboardUrl,@DashboardType,@DashboardCategory, @IsInternal, @IsDeleted,@IsPremiumDashboard,@IsAssignAlluser";

            var status = this.Database.ExecuteSqlRawAsync(sqlQuery, dashboardId, dashboardName, dashboardDisplayName, dashboardUrl, dashboardType, dashboardCategory, isInternal, isDeleted, isPremiumDashboard, isAssignAlluser);
            return status.Result;
        }

        public virtual async Task<List<TableauUserAdmin>> GetCustomDashboard(string filterValue, int userId, int type, int page, int pagesize, string sortCol, string sortDir)
        {
            return await Task.FromResult(this.Set<TableauUserAdmin>()
                                        .FromSqlRaw(DbConstants.SpGetCustomDashboard, filterValue, page, pagesize, sortCol, sortDir, userId, type)
                                        .AsEnumerable()
                                        .ToList());
        }

        public virtual async Task<List<Core.Models.TableauUserAccount>> GetSearchUser(string userId, string firstName, string lastName, string companyName, string companyType, int loginLvl, int page, int pagesize, string sortCol, string sortDir)
        {
            return await Task.FromResult(this.Set<Core.Models.TableauUserAccount>()
                         .FromSqlRaw(DbConstants.SpSearchUsers, firstName, lastName, userId, companyName, companyType, null, loginLvl, page, pagesize, sortCol, sortDir)
                         .AsEnumerable()
                         .ToList());
        }

        public virtual async Task<List<DashboardUserDetail>> GetUserDetailsForDashboard(int dashboardId)
        {
            return await Task.FromResult(this.Set<DashboardUserDetail>()
                                        .FromSqlRaw(DbConstants.SpGetUserDetailsForDashboard, dashboardId)
                                        .AsEnumerable()
                                        .ToList());
        }

        public virtual int InsertSelectedUserToDashboard(InsertDashboardUsers model)
        {
            SqlParameter dashboardId = new SqlParameter("@DashboardId", model.DashboardId);
            SqlParameter userId = new SqlParameter("@UserId", model.UserAccountId);
            string sqlQuery = DbConstants.SpAssignUsersToDashboard + " @DashboardId, @UserId";

            var status = this.Database.ExecuteSqlRawAsync(sqlQuery, dashboardId, userId);
            return status.Result;
        }

        public virtual int RemoveAssignedUser(int userAccountId)
        {
            SqlParameter userId = new SqlParameter("@UserId", userAccountId);
            string sqlQuery = DbConstants.SpRemoveAssignedUser + " @UserId";

            var status = this.Database.ExecuteSqlRawAsync(sqlQuery, userId);
            return status.Result;
        }

        public virtual async Task<List<Core.Models.DashboardType>> GetDashboardType()
        {
            return await Task.FromResult(this.Set<Core.Models.DashboardType>().FromSqlRaw(DbConstants.SpGetDashboardType).AsEnumerable().ToList());
        }

        public virtual async Task<List<Core.Models.DashboardCategory>> GetDashboardCategory()
        {
            return await Task.FromResult(this.Set<DashboardCategory>().FromSqlRaw(DbConstants.SpGetDashboardCategory).AsEnumerable().ToList());
        }

        public virtual async Task<List<TableauUserAdmin>> GetManageDashboardByUsers(string filterValue, int userId, int type, int loginLevel, int page, int pagesize, string sortCol, string sortDir)
        {
            return await Task.FromResult(this.Set<TableauUserAdmin>()
                                        .FromSqlRaw(DbConstants.SpGetManageAllUserDashboards, filterValue, page, pagesize, sortCol, sortDir, userId, type, loginLevel)
                                        .AsEnumerable()
                                        .ToList());
        }

        public virtual async Task<List<Core.Models.DashboardDetail>> GetDashboardDetails(int userId, string categoryName)
        {
            return await Task.FromResult(this.Set<Core.Models.DashboardDetail>()
                                        .FromSqlRaw(DbConstants.SpGetDashboardDetailsByCategory, userId, categoryName)
                                        .AsEnumerable()
                                        .ToList());
        }

        public virtual async Task<List<AdministrationAdvanceSearch>> GetAdvanceSearch(string code, string type, int flag, int page, int pagesize, string sortCol, string sortDir)
        {
            return await Task.FromResult(this.Set<AdministrationAdvanceSearch>()
                                        .FromSqlRaw(DbConstants.SpAdvanceUserSearch, type, code, flag, page, pagesize, sortCol, sortDir)
                                        .AsEnumerable()
                                        .ToList());
        }

        public override int SaveChanges()
        {
            var result = 0;
            var auditEntries = this.OnBeforeSaveChanges();
            result = base.SaveChanges();
            this.OnAfterSaveChanges(auditEntries);
            return result;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(this.connectionString);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Messages>().HasNoKey();
            modelBuilder.Entity<HeaderMessages>().HasNoKey();
            modelBuilder.Entity<ChangePassword>().HasNoKey();
            modelBuilder.Entity<ResetPasswordHistory>().HasNoKey();
            modelBuilder.Entity<Core.Models.Carrier>().HasNoKey();
            modelBuilder.Entity<MyReport>().HasNoKey();
            modelBuilder.Entity<Core.Models.ReportInstance>().HasNoKey();
            modelBuilder.Entity<Core.Models.Country>().HasNoKey();
            modelBuilder.Entity<State>().HasNoKey();
            modelBuilder.Entity<Core.Models.Shipper>().HasNoKey();
            modelBuilder.Entity<UserAdministration>().HasNoKey();
            modelBuilder.Entity<UserAdministrationCount>().HasNoKey();
            modelBuilder.Entity<UserPrivilege>().HasNoKey();
            modelBuilder.Entity<EditProfile>().HasNoKey();
            modelBuilder.Entity<ExternalAuthenticator>().HasNoKey();
            modelBuilder.Entity<ExternalProviderMappingJson>().HasNoKey();
            modelBuilder.Entity<PrivilegeGroupList>().HasNoKey();
            modelBuilder.Entity<ShipPoint>().HasNoKey();
            modelBuilder.Entity<UserIsLockedByEditingUserCount>().HasNoKey();
            modelBuilder.Entity<ISEmailAvailable>().HasNoKey();
            modelBuilder.Entity<Core.Models.Letter>().HasNoKey();
            modelBuilder.Entity<AccountID>().HasNoKey();
            modelBuilder.Entity<DolCodeCount>().HasNoKey();
            modelBuilder.Entity<ActiveDirectory>().HasNoKey();
            modelBuilder.Entity<CreateDashboard>().HasNoKey();
            modelBuilder.Entity<TableauUserAdmin>().HasNoKey();
            modelBuilder.Entity<Core.Models.TableauUserAccount>().HasNoKey();
            modelBuilder.Entity<DashboardUserDetail>().HasNoKey();
            modelBuilder.Entity<InsertDashboardUsers>().HasNoKey();
            modelBuilder.Entity<Core.Models.DashboardDetail>().HasNoKey();
            modelBuilder.Entity<AdministrationAdvanceSearch>().HasNoKey();
            modelBuilder.Entity<ShipPointData>().HasNoKey();
            modelBuilder.Entity<ShipPointCount>().HasNoKey();
            modelBuilder.Entity<MetricShipper>().HasNoKey();
        }

        private List<AuditEntry> OnBeforeSaveChanges()
        {
            this.ChangeTracker.DetectChanges();
            var auditEntries = new List<AuditEntry>();
            foreach (var entry in this.ChangeTracker.Entries())
            {
                if (entry.Entity is AuditLog || entry.State == EntityState.Detached || entry.State == EntityState.Unchanged)
                {
                    continue;
                }

                var auditEntry = new AuditEntry(entry, this.UserProfile)
                {
                    TableName = entry.Metadata.ClrType.Name,
                };
                auditEntries.Add(auditEntry);

                foreach (var property in entry.Properties)
                {
                    string propertyName = property.Metadata.Name;

                    if (property.IsTemporary)
                    {
                        // value will be generated by the database, get the value after saving
                        auditEntry.TemporaryProperties.Add(property);
                        continue;
                    }

                    if (auditEntry.TableName != "USER_PRIVILEDGE")
                    {
                        if (property.Metadata.IsPrimaryKey())
                        {
                            auditEntry.KeyValues[propertyName] = property.CurrentValue;
                            continue;
                        }
                    }
                    else
                    {
                        auditEntry.KeyValues[propertyName] = property.CurrentValue;
                    }

                    auditEntry.Columns.Add(propertyName);
                    switch (entry.State)
                    {
                        case EntityState.Added:
                            auditEntry.AuditType = "I";
                            auditEntry.NewValues[propertyName] = property.CurrentValue;
                            break;

                        case EntityState.Deleted:
                            auditEntry.AuditType = "D";
                            auditEntry.OldValues[propertyName] = property.OriginalValue;
                            break;

                        case EntityState.Modified:

                            if (property.IsModified)
                            {
                                auditEntry.AuditType = "U";
                                auditEntry.OldValues[propertyName] = property.OriginalValue;
                                auditEntry.NewValues[propertyName] = property.CurrentValue;
                            }

                            break;
                    }
                }
            }

            // Save audit entities that have all the modifications
            foreach (var auditEntry in auditEntries.Where(_ => !_.HasTemporaryProperties))
            {
                this.AuditLog.AddRange(auditEntry.ToAuditLogs());
            }

            // keep a list of entries where the value of some properties are unknown at this step
            return auditEntries.Where(_ => _.HasTemporaryProperties).ToList();
        }

        private int OnAfterSaveChanges(List<AuditEntry> auditEntries)
        {
            if (auditEntries == null || auditEntries.Count == 0)
            {
                return 0;
            }

            foreach (var auditEntry in auditEntries)
            {
                // Get the final value of the temporary properties
                foreach (var prop in auditEntry.TemporaryProperties)
                {
                    string propname = prop.Metadata.Name;
                    auditEntry.Columns.Add(propname);
                    if (prop.Metadata.IsPrimaryKey())
                    {
                        if (prop.Metadata.IsPrimaryKey())
                        {
                            auditEntry.KeyValues[propname] = prop.CurrentValue;
                        }
                        else
                        {
                            auditEntry.NewValues[propname] = prop.CurrentValue;
                        }
                    }
                }

                // Save the Audit entry
                this.AuditLog.AddRange(auditEntry.ToAuditLogs());
            }

            return this.SaveChanges();
        }
    }
}