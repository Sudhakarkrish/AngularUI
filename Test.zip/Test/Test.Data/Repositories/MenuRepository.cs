﻿namespace CassPort.Data.Repositories
{
    using AutoMapper;
    using CassPort.Core.Models;
    using CassPort.Core.Repositories;
    using CassPort.Data.Common;
    using CassPort.Data.Context;
    using CassPort.Data.Entities;
    using Microsoft.EntityFrameworkCore;
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    /// <summary>
    /// Configuration Repository
    /// </summary>
    public class MenuRepository : IMenuRepository
    {
        private readonly UserProfile userProfile;

        /// <summary>
        /// Initializes a new instance of the <see cref="MenuRepository"/> class.
        /// </summary>
        /// <param name="context">Context</param>
        /// <param name="mapper">mapper</param>
        /// <param name="userProfile">userProfile</param>
        public MenuRepository(CassPortContext context, IMapper mapper, UserProfile userProfile)
        {
            this.Context = context;
            this.Mapper = mapper;
            this.userProfile = userProfile;
        }

        public CassPortContext Context { get; }

        public IMapper Mapper { get; }

        /// <summary>
        /// Get All Menu Items
        /// </summary>
        /// <returns>List of menu items</returns>
        public async Task<List<MenuItemDetail>> GetMenus()
        {
            List<CassportNavItem> menuItems = await this.Context.CassportNavItem.FromSqlRaw(DbConstants.SpGetUserMenus, Convert.ToInt16(this.userProfile.UserId)).ToListAsync();         
            return this.Mapper.Map<List<MenuItemDetail>>(menuItems);
        }
    }
}
