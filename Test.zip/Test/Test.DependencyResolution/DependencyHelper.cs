﻿namespace CassPort.DependencyResolution
{
    using System.IO;
    using System.Reflection;
    using AutoMapper;
    using CassPort.Core.Models;
    using CassPort.Core.Repositories;
    using CassPort.Core.Services;
    using CassPort.Core.Services.Interfaces;
    using CassPort.Data.Context;
    using CassPort.Data.Repositories;
    using CassPort.Infrastructure.Middleware;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Mvc.ApiExplorer;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Hosting;
    using Serilog;

    /// <summary>
    /// Registarar Dependency
    /// </summary>
    public static class DependencyHelper
    {
        public static void CreateLogger(this IConfiguration configuration)
        {
            configuration.CreateSerilogLogger();
        }

        /// <summary>
        /// Register startup components
        /// </summary>
        /// <param name="services">Services to handle.</param>
        /// <param name="configuration">Configurations to handle.</param>
        /// <param name="assembly">assembly info to handle.</param>
        public static void RegisterDependencies(
            this IServiceCollection services,
            IConfiguration configuration,
            Assembly assembly)
        {
            services.AddLogging((builder) =>
            {
                builder.AddSerilog(dispose: true);
            });

            services.AddDbContext<CassPortContext>(options =>
            {
                options.UseSqlServer(configuration["ConnectionStrings:CassPortConnection"]);
            });

            services.AddDbContext<ReportProfileContext>(options =>
            {
                options.UseSqlServer(configuration["ConnectionStrings:CassPortReportConnection"]);
            });

            services.AddSwaggerGen(
            options =>
            {
                // Resolve the temprary IApiVersionDescriptionProvider service.
                var provider = services.BuildServiceProvider().GetRequiredService<IApiVersionDescriptionProvider>();

                // Add a swagger document for each discovered API version.
                foreach (var description in provider.ApiVersionDescriptions)
                {
                    options.SwaggerDoc(description.GroupName, new Microsoft.OpenApi.Models.OpenApiInfo()
                    {
                        Title = $"{assembly.GetCustomAttribute<AssemblyProductAttribute>().Product} {description.ApiVersion}",
                        Version = description.ApiVersion.ToString(),
                        Description = description.IsDeprecated ? $"{assembly.GetCustomAttribute<AssemblyDescriptionAttribute>().Description} - DEPRECATED" : assembly.GetCustomAttribute<AssemblyDescriptionAttribute>().Description,
                    });
                }

                // Add a custom filter for settint the default values
                options.OperationFilter<SwaggerDefaultValues>();

                // Tells swagger to pick up the output XML document file
                options.IncludeXmlComments(Path.Combine(
                    Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), $"{assembly.GetName().Name}.xml"));
            });

            services.AddAutoMapper(typeof(StartupBase));
            services.AddScoped<UserProfile>();
            services.AddTransient<IMessageRepository, MessageRepository>();
            services.AddTransient<IMessageService, MessageService>();
            services.AddTransient<ITableauService, TableauService>();
            services.AddTransient<IUserClaimsService, UserClaimsService>();
            services.AddTransient<IUserClaimsRepository, UserClaimsRepository>();
            services.AddTransient<IMenuRepository, MenuRepository>();
            services.AddTransient<IMenuService, MenuService>();
            services.AddTransient<IDashboardRepository, DashboardRepository>();
            services.AddTransient<IDashboardService, DashboardService>();
            services.AddTransient<IForgotPasswordRepository, ForgotPasswordRepository>();
            services.AddTransient<IForgotPasswordService, ForgotPasswordService>();
            services.AddTransient<IChangePasswordRepository, ChangePasswordRepository>();
            services.AddTransient<IChangePasswordService, ChangePasswordService>();
            services.AddTransient<IResetPasswordRepository, ResetPasswordRepository>();
            services.AddTransient<IResetPasswordService, ResetPasswordService>();
            services.AddTransient<ICarrierRepository, CarrierRepository>();
            services.AddTransient<ICarrierService, CarrierService>();
            services.AddTransient<IUserProfileRepository, UserProfileRepository>();
            services.AddTransient<IUserProfileService, UserProfileService>();
            services.AddTransient<IReportRepository, ReportRepository>();
            services.AddTransient<IReportService, ReportService>();
            services.AddTransient<IShipperRepository, ShipperRepository>();
            services.AddTransient<IShipperService, ShipperService>();
            services.AddTransient<IUserAdministrationRepository, UserAdministrationRepository>();
            services.AddTransient<IUserAdministrationService, UserAdministrationService>();
            services.AddTransient<IUserPermissionRepository, UserPermissionRepository>();
            services.AddTransient<IUserPermissionService, UserPermissionService>();
            services.AddTransient<IShipPointRepository, ShipPointRepository>();
            services.AddTransient<IShipPointService, ShipPointService>();
            services.AddTransient<ITableauUserAdminRepository, TableauUserAdminRepository>();
            services.AddTransient<ITableauUserAdminService, TableauUserAdminService>();
        }

        /// <summary>
        /// Register middleware.
        /// </summary>
        /// <param name="app">Application variable.</param>
        /// <param name="provider">Get api version.</param>
        /// <param name="env">Hosting Environment.</param>
        public static void RegisterMiddlewares(
                this IApplicationBuilder app,
                IApiVersionDescriptionProvider provider,
                IWebHostEnvironment env)
        {
            app.UseSwagger();
            if (env.IsDevelopment())
            {
                app.UseSwaggerUI(
                options =>
                {
                // Build a swagger endpoint for each discovered API version.
                foreach (var description in provider.ApiVersionDescriptions)
                    {
                        options.SwaggerEndpoint($"/swagger/{description.GroupName}/swagger.json", description.GroupName.ToUpperInvariant());
                    }
                });
            }

            app.UseResponseWrapperMiddleware();
            app.UseScopedLoggingMiddleware();
            app.UseExceptionMiddleware();

            var mapperConfiguration = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile(new MapperProfile());
            });
        }
    }
}
