﻿namespace CassPort.DependencyResolution
{
    using AutoMapper;
    using CassPort.Core.Models;
    using CassPort.Data.Entities;

    public class MapperProfile : Profile
    {
        public MapperProfile()
        {
            this.CreateMap<UserAccount, UserProfile>().ReverseMap();
            this.CreateMap<CassportNavItem, MenuItemDetail>().ReverseMap();
            this.CreateMap<Data.Entities.DashboardCategory, Core.Models.DashboardCategory>().ReverseMap();
        }
    }
}
