﻿namespace CassPort.Infrastructure.Middleware
{
    using System;
    using System.Net;

    public class ApiResponse
    {
        protected ApiResponse(HttpStatusCode statusCode, object result = null, string errorMessage = null)
        {
            this.RequestId = Guid.NewGuid().ToString();
            this.StatusCode = (int)statusCode;
            this.Result = result;
            this.ErrorMessage = errorMessage;
        }

        public int StatusCode { get; set; }

        public string RequestId { get; }

        public string ErrorMessage { get; set; }

        public object Result { get; set; }

        public static ApiResponse Create(HttpStatusCode statusCode, object result = null, string errorMessage = null)
        {
            return new ApiResponse(statusCode, result, errorMessage);
        }
    }
}
