﻿namespace CassPort.Infrastructure.Middleware
{
    using System;
    using System.Linq;
    using System.Net;
    using System.Threading.Tasks;
    using CassPort.Core.Exception;
    using CassPort.Core.Models;
    using Microsoft.AspNetCore.Http;
    using Newtonsoft.Json;
    using Serilog;

    // You may need to install the Microsoft.AspNetCore.Http.Abstractions package into your project
    public class ExceptionMiddleware
    {
        private const string MessageTemplate =
          "HTTP {RequestMethod} {RequestPath} responded {StatusCode} in {Elapsed:0.0000} ms";

        private static readonly ILogger Log = Serilog.Log.ForContext<ExceptionMiddleware>();

        private readonly RequestDelegate next;

        public ExceptionMiddleware(RequestDelegate next)
        {
            this.next = next;
        }

        public async Task Invoke(HttpContext httpContext, UserProfile userProfile)
        {
            try
            {
                await this.next.Invoke(httpContext);
            }
            catch (Exception ex)
            {
                await this.HandleExceptionAsync(httpContext, ex, userProfile);
            }
        }

        private static bool LogException(HttpContext httpContext, Exception ex, UserProfile userProfile)
        {
            LogForErrorContext(httpContext, userProfile)
                .Error(ex, MessageTemplate, httpContext.Request.Method, httpContext.Request.Path, 500, 0);

            return true;
        }

        private static ILogger LogForErrorContext(HttpContext httpContext, UserProfile userProfile)
        {
            var request = httpContext.Request;

            var result = Log
                .ForContext("RequestHeaders", request.Headers.ToDictionary(h => h.Key, h => h.Value.ToString()), destructureObjects: true)
                .ForContext("RequestHost", request.Host)
                .ForContext("RequestProtocol", request.Protocol)
                .ForContext("CorrelationID", userProfile.RequestId)
                .ForContext("USER", userProfile.UserName)
                .ForContext("CLIENT_MACHINE_NAME", userProfile.ClientMachineName)
                .ForContext("CLIENT_APP_VERSION", userProfile.ClientAppVersion)
                .ForContext("LOGGING_SERVER_NAME", userProfile.LoggingServerName)
                .ForContext("LOGGING_SERVER_APP_VERSION", userProfile.LoggingServerAppVersion)
                .ForContext("USER_ID", userProfile.UserId)
                .ForContext("SOURCE", userProfile.Source);

            if (request.HasFormContentType)
            {
                result = result.ForContext("RequestForm", request.Form.ToDictionary(v => v.Key, v => v.Value.ToString()));
            }

            return result;
        }

        private async Task HandleExceptionAsync(HttpContext context, Exception exception, UserProfile userProfile)
        {
            var response = context.Response;
            var customException = exception as CustomException;
            var statusCode = (int)HttpStatusCode.InternalServerError;
            var message = "Unexpected error";
            var description = "Unexpected error";

            if (customException != null)
            {
                message = customException.Message;
                description = customException.Description;
                statusCode = customException.Code;
            }

            response.ContentType = "application/json";
            response.StatusCode = statusCode;
            await response.WriteAsync(JsonConvert.SerializeObject(new ErrorResponse
            {
                Message = message,
                Description = description
            }));

            LogException(context, exception, userProfile);
        }
    }
}
