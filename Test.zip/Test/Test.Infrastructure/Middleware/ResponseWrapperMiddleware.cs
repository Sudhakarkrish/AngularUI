﻿namespace CassPort.Infrastructure.Middleware
{
    using System.IO;
    using System.Net;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Http;
    using Newtonsoft.Json;

    // You may need to install the Microsoft.AspNetCore.Http.Abstractions package into your project
    public class ResponseWrapperMiddleware
    {
        private readonly RequestDelegate next;

        public ResponseWrapperMiddleware(RequestDelegate next)
        {
            this.next = next;
        }

        public async Task Invoke(HttpContext httpContext)
        {
            var currentBody = httpContext.Response.Body;

            using (var memoryStream = new MemoryStream())
            {
                // set the current response to the memorystream.
                httpContext.Response.Body = memoryStream;

                await this.next(httpContext);

                // reset the body
                httpContext.Response.Body = currentBody;
                memoryStream.Seek(0, SeekOrigin.Begin);

                var readToEnd = new StreamReader(memoryStream).ReadToEnd();
                var objResult = JsonConvert.DeserializeObject(readToEnd);
                var result = ApiResponse.Create((HttpStatusCode)httpContext.Response.StatusCode, objResult, null);
                await httpContext.Response.WriteAsync(JsonConvert.SerializeObject(result));
            }
        }
    }
}
