﻿namespace CassPort.Infrastructure.Middleware
{
    using System;
    using System.Threading.Tasks;
    using CassPort.Core.Models;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Logging;
    using Serilog.Context;

    /// <summary>
    /// Serilog LoggingMiddleware
    /// </summary>
    public class SerilogLoggingMiddleware
    {
        private const string CORRELATIONIDHEADERNAME = "CorrelationID";
        private const string USERHEADERNAME = "USER";
        private const string CLIENTMACHINENAME = "CLIENT_MACHINE_NAME";
        private const string CLIENTAPPVERSION = "CLIENT_APP_VERSION";
        private const string LOGGINGSERVERNAME = "LOGGING_SERVER_NAME";
        private const string LOGGINGSERVERAPPVERSION = "LOGGING_SERVER_APP_VERSION";
        private const string USERID = "USER_ID";
        private const string SOURCE = "SOURCE";
        private readonly RequestDelegate next;
        private readonly ILogger<SerilogLoggingMiddleware> logger;

        public SerilogLoggingMiddleware(RequestDelegate next, ILogger<SerilogLoggingMiddleware> logger)
        {
            this.next = next ?? throw new System.ArgumentNullException(nameof(next));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task Invoke(HttpContext context, UserProfile user)
        {
            if (context == null)
            {
                throw new System.ArgumentNullException(nameof(context));
            }

            try
            {
                using (LogContext.PushProperty(CORRELATIONIDHEADERNAME, user.RequestId, true))
                {
                    using (LogContext.PushProperty(USERHEADERNAME, user.UserName, true))
                    {
                        using (LogContext.PushProperty(CLIENTMACHINENAME, user.ClientMachineName, true))
                        {
                            using (LogContext.PushProperty(CLIENTAPPVERSION, user.ClientAppVersion, true))
                            {
                                using (LogContext.PushProperty(LOGGINGSERVERNAME, user.LoggingServerName, true))
                                {
                                    using (LogContext.PushProperty(LOGGINGSERVERAPPVERSION, user.LoggingServerAppVersion, true))
                                    {
                                        using (LogContext.PushProperty(USERID, user.UserId, true))
                                        {
                                            using (LogContext.PushProperty(SOURCE, user.Source, true))
                                            {
                                                await this.next.Invoke(context);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex) when (this.LogOnUnexpectedError(ex))
            {
                return;
            }
        }

        private bool LogOnUnexpectedError(Exception ex)
        {
            this.logger.LogError(ex, "An unexpected exception occured!");
            return true;
        }
    }
}
