﻿using CassPort.Core.Models;
using CassPort.Core.Repositories;
using CassPort.Core.Services;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CassPort.Core.Test
{
    public class CarrierServiceTest
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public async Task GetCarriersBySearchTest()
        {
            var mockResponse = new List<Carrier>();
            var carrierRepository = new Mock<ICarrierRepository>();

            carrierRepository.Setup(context => context.GetCarriersBySearch("hello")).ReturnsAsync(mockResponse);
            var carrierService = new CarrierService(carrierRepository.Object);

            var response = await carrierService.GetCarriersBySearch("hello");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUserCarriersTest()
        {
            var mockResponse = new List<Carrier>();
            var carrierRepository = new Mock<ICarrierRepository>();

            carrierRepository.Setup(context => context.GetUserCarriers(true)).ReturnsAsync(mockResponse);
            var carrierService = new CarrierService(carrierRepository.Object);

            var response = await carrierService.GetUserCarriers(true);
            Assert.NotNull(response);
        }

        [Test]
        public async Task UpdateUserCarriersTest()
        {
            var mockResponse = new List<Carrier>();
            var carrierRepository = new Mock<ICarrierRepository>();

            carrierRepository.Setup(context => context.UpdateUserCarriers(It.IsAny<List<Carrier>>(), 1)).Returns(1);
            var carrierService = new CarrierService(carrierRepository.Object);

            var response = carrierService.UpdateUserCarriers(mockResponse, 1);
            Assert.NotNull(response);
        }

    }
}
