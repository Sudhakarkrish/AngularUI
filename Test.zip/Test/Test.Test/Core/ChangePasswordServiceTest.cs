﻿using CassPassword;
using CassPort.Core.Models;
using CassPort.Core.Repositories;
using CassPort.Core.Services;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CassPort.Core.Test
{
    public class ChangePasswordServiceTest
    {
        [SetUp]
        public void Setup()
        {

        }
        /// <summary>
        /// Yet to Update
        /// </summary>
        /// <returns></returns>
       // [Test]
        public async Task IsPasswordValidTest()
        {
            var mockUserPasswordHistory = new List<UserPasswordHistory>();
            var mockUserProfile = new UserProfile();
            var mockManagePassword = new ManagePassword();
            mockManagePassword.Password = "test";
            var changePasswordRepository = new Mock<IChangePasswordRepository>();

            changePasswordRepository.Setup(context => context.GetUserPasswordHistory()).ReturnsAsync(mockUserPasswordHistory);
            var changePasswordService = new ChangePasswordService(changePasswordRepository.Object, mockUserProfile);

            var response = await changePasswordService.IsPasswordValid(mockManagePassword);
            Assert.NotNull(response);
        }

        [Test]
        public async Task UpdateChangePasswordTest()
        {
            var mockUserProfile = new UserProfile();
            var mockManagePassword = new ManagePassword();
            mockManagePassword.Password = "test";
            var changePasswordRepository = new Mock<IChangePasswordRepository>();

            changePasswordRepository.Setup(context => context.UpdateUsersLoginPassword(mockManagePassword,It.IsAny<UserPassword>())).Returns(true);
            var changePasswordService = new ChangePasswordService(changePasswordRepository.Object, mockUserProfile);

            var response = changePasswordService.UpdateChangePassword(mockManagePassword);
            Assert.NotNull(response);
        }

        [Test]
        public async Task IsUserConfirmedTest()
        {
            var mockUserAccountDetail = new UserAccountDetail();
            var mockUserProfile = new UserProfile();
            var changePasswordRepository = new Mock<IChangePasswordRepository>();

            changePasswordRepository.Setup(context => context.GetUserPassword()).ReturnsAsync(mockUserAccountDetail);
            var changePasswordService = new ChangePasswordService(changePasswordRepository.Object, mockUserProfile);

            var response = changePasswordService.IsUserConfirmed("test");
            Assert.NotNull(response);
        }
        
        /// <summary>
        /// not a correct method
        /// </summary>
        /// <returns></returns>
        [Test]
        public async Task GetChangePasswordTest()
        {
            var mockManagePassword = new ManagePassword();
            mockManagePassword.CurrentPassword = "dXNlcm5hbWU6cGFzc3dvcmQ=";
            mockManagePassword.Password = "VGhpcyBpcyBteSBwYXNzd29yZC4=";
            mockManagePassword.ConfirmPassword = "VGhpcyBpcyBteSBwYXNzd29yZC4=";
            var mockUserProfile = new UserProfile();
            var changePasswordRepository = new Mock<IChangePasswordRepository>();

            var changePasswordService = new ChangePasswordService(changePasswordRepository.Object, mockUserProfile);

            var response = changePasswordService.GetChangePassword(mockManagePassword);
            Assert.NotNull(response);
        }

        /// <summary>
        /// Has to verify
        /// </summary>
        /// <returns></returns>
        [Test]
        public async Task ChangePasswordTest()
        {
            var mockManagePassword = new ManagePassword();
            var mockUserProfile = new UserProfile();           
            var changePasswordRepository = new Mock<IChangePasswordRepository>();

            var changePasswordService = new ChangePasswordService(changePasswordRepository.Object, mockUserProfile);

            var response = changePasswordService.ChangePassword(mockManagePassword);
            Assert.NotNull(response);
        }

        /// <summary>
        /// Has to verify
        /// </summary>
        /// <returns></returns>
        [Test]
        public async Task GetPasswordExpiredTest()
        {
            var mockUserProfile = new UserProfile();
            mockUserProfile.PasswordExpirationDays = 20;
            var changePasswordRepository = new Mock<IChangePasswordRepository>();

            var changePasswordService = new ChangePasswordService(changePasswordRepository.Object, mockUserProfile);

            var response = changePasswordService.GetPasswordExpired();
            Assert.NotNull(response);
        }


    }
}
