﻿using CassPort.Core.Models;
using CassPort.Core.Repositories;
using CassPort.Core.Services;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CassPort.Core.Test
{
    public class DashBoardServiceTest
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public async Task GetDashboardTest()
        {
            var mockResponse = new List<DashBoardDetail>();
            var dashBoardRepository = new Mock<IDashBoardRepository>();

            dashBoardRepository.Setup(context => context.GetDashboard("test")).ReturnsAsync(mockResponse);
            var dashBoardService = new DashBoardService(dashBoardRepository.Object);

            var response = await dashBoardService.GetDashboard("test");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetCategoryTest()
        {
            var mockResponse = new List<DashBoardCategory>();
            var dashBoardRepository = new Mock<IDashBoardRepository>();

            dashBoardRepository.Setup(context => context.GetCategory()).ReturnsAsync(mockResponse);
            var dashBoardService = new DashBoardService(dashBoardRepository.Object);

            var response = await dashBoardService.GetCategory();
            Assert.NotNull(response);
        }

        [Test]
        public async Task SaveDashBoardTest()
        {
            var mockResponse = new List<DashBoardDetail>();
            var dashBoardRepository = new Mock<IDashBoardRepository>();

            dashBoardRepository.Setup(context => context.SaveDashBoard(It.IsAny<List<DashBoardDetail>>())).Returns(1);
            var dashBoardService = new DashBoardService(dashBoardRepository.Object);

            var response = dashBoardService.SaveDashBoard(mockResponse);
            Assert.NotNull(response);
        }
    }
}
