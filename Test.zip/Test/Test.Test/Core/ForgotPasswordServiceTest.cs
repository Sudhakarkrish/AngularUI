﻿using CassPort.Core.Models;
using CassPort.Core.Repositories;
using CassPort.Core.Services;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CassPort.Core.Test
{
    public class ForgotPasswordServiceTest
    {
        [SetUp]
        public void Setup()
        {

        }
        [Test]
        public async Task IsEmailConfirmedTest()
        {
            var mockForgotPasswordViewModel = new ForgotPasswordViewModel();
            mockForgotPasswordViewModel.AccountEnabled = true;
            mockForgotPasswordViewModel.Confirmed = true;
            var forgotPasswordRepository = new Mock<IForgotPasswordRepository>();

            forgotPasswordRepository.Setup(context => context.IsEmailConfirmed(mockForgotPasswordViewModel)).Returns(mockForgotPasswordViewModel);
            forgotPasswordRepository.Setup(context => context.SaveUserConfirmationToken(mockForgotPasswordViewModel));
            var forgotPasswordService = new ForgotPasswordService(forgotPasswordRepository.Object);

            var response = forgotPasswordService.IsEmailConfirmed(mockForgotPasswordViewModel);
            Assert.NotNull(response);
        }

    } 
}    
