﻿using CassPort.Core.Models;
using CassPort.Core.Repositories;
using CassPort.Core.Services;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CassPort.Core.Test
{
    public class MessageServiceTest
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public async Task GetActiveWhatsNewExportsMessagesTest()
        {
            var mockResponse = new List<Messages>();
            var messageRepository = new Mock<IMessageRepository>();

            messageRepository.Setup(context => context.GetActiveWhatsNewExportsMessages(1, 10)).ReturnsAsync(mockResponse);
            var messageService = new MessageService(messageRepository.Object);

            var response = await messageService.GetActiveWhatsNewExportsMessages(1, 10);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetMyMessagesTest()
        {
            var mockResponse = new List<Messages>();
            var messageRepository = new Mock<IMessageRepository>();

            messageRepository.Setup(context => context.GetMyMessages(1, 10)).ReturnsAsync(mockResponse);
            var messageService = new MessageService(messageRepository.Object);

            var response = await messageService.GetMyMessages(1, 10);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetMyMessagesForHeaderTest()
        {
            var mockResponse = new List<Messages>();
            var messageRepository = new Mock<IMessageRepository>();

            messageRepository.Setup(context => context.GetMyMessagesForHeader()).ReturnsAsync(mockResponse);
            var messageService = new MessageService(messageRepository.Object);

            var response = await messageService.GetMyMessagesForHeader();
            Assert.NotNull(response);
        }

        [Test]
        public async Task UpdateMessageStatusTest()
        {
            var mockResponse = new List<Messages>();
            var messageRepository = new Mock<IMessageRepository>();

            messageRepository.Setup(context => context.UpdateMessageStatus(1, 1)).Returns(1);
            var messageService = new MessageService(messageRepository.Object);

            var response = messageService.UpdateMessageStatus(1, 1);
            Assert.NotNull(response);
        }
    }
}
