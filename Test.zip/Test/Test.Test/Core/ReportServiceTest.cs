﻿using CassPort.Core.Models;
using CassPort.Core.Repositories;
using CassPort.Core.Services;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CassPort.Core.Test
{
    public class ReportServiceTest
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public async Task GetUserReportTest()
        {
            var mockResponse = new List<MyReport>();
            var reportRepository = new Mock<IReportRepository>();

            reportRepository.Setup(context => context.GetUserReport()).ReturnsAsync(mockResponse);
            var reportService = new ReportService(reportRepository.Object);

            var response = await reportService.GetUserReport();
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetReportInstanceByIdTest()
        {
            var mockResponse = new List<ReportInstance>();
            var reportRepository = new Mock<IReportRepository>();

            reportRepository.Setup(context => context.GetReportInstanceById(22,true)).ReturnsAsync(mockResponse);
            var reportService = new ReportService(reportRepository.Object);

            var response = await reportService.GetReportInstanceById(22, true);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUserReportBySearchTest()
        {
            var mockResponse = new List<MyReport>();
            var reportRepository = new Mock<IReportRepository>();

            reportRepository.Setup(context => context.GetUserReportBySearch("searchValue")).ReturnsAsync(mockResponse);
            var reportService = new ReportService(reportRepository.Object);

            var response = await reportService.GetUserReportBySearch("searchValue");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetReportInstanceBySearchValueTest()
        {
            var mockResponse = new List<ReportInstance>();
            var reportRepository = new Mock<IReportRepository>();

            reportRepository.Setup(context => context.GetReportInstanceBySearchValue(22,true, "fromDate", "endDate")).ReturnsAsync(mockResponse);
            var reportService = new ReportService(reportRepository.Object);

            var response = await reportService.GetReportInstanceBySearchValue(22, true, "fromDate", "endDate");
            Assert.NotNull(response);
        }
    }
}
