﻿using CassPassword;
using CassPort.Core.Models;
using CassPort.Core.Repositories;
using CassPort.Core.Services;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CassPort.Core.Test
{
    public class ResetPasswordServiceTest
    {
        [SetUp]
        public void Setup()
        {

        }
       
        [Test]
        public async Task ResetPasswordTest()
        {
            var mockResetPassword = new ResetPassword();
            mockResetPassword.Password = "U2F0eWFtJDI0";
            mockResetPassword.ConfirmPassword = "U2F0eWFtJDI0";
            var resetPasswordRepository = new Mock<IResetPasswordRepository>();
     
            var resetPasswordService = new ResetPasswordService(resetPasswordRepository.Object, It.IsAny<UserProfile>());

            var response = await resetPasswordService.ResetPassword(mockResetPassword);
            Assert.NotNull(response);
        }


        [Test]
        public async Task IsTokenConfirmedTest()
        {
            var mockResetPassword = new ResetPassword();
            var resetPasswordRepository = new Mock<IResetPasswordRepository>();

            resetPasswordRepository.Setup(context => context.IsTokenConfirmed(mockResetPassword)).ReturnsAsync(true);
            var resetPasswordService = new ResetPasswordService(resetPasswordRepository.Object, It.IsAny<UserProfile>());

            var response = await resetPasswordService.IsTokenConfirmed(mockResetPassword);
            Assert.NotNull(response);
        }
        /// <summary>
        /// Yet to Update
        /// </summary>
        /// <returns></returns>
       // [Test]
        public async Task IsResetPasswordValidTest()
        {
            var mockResponse = new ResetPassword();
            var mockUserPasswordHistory = new List<UserPasswordHistory>();
            var resetPasswordRepository = new Mock<IResetPasswordRepository>();

            resetPasswordRepository.Setup(context => context.GetUserPasswordHistory()).ReturnsAsync(mockUserPasswordHistory);
            var resetPasswordService = new ResetPasswordService(resetPasswordRepository.Object, It.IsAny<UserProfile>());

            var response = await resetPasswordService.IsResetPasswordValid(mockResponse);
            Assert.NotNull(response);
        }

       
        [Test]
        public async Task UpdateResetPasswordTest()
        {
            var mockResetPassword = new ResetPassword();
            mockResetPassword.Password = "Satyam$3";
           // var objUserPassword = CassPassword.Password.HashPassword(mockResponse.Password, 1);
            var resetPasswordRepository = new Mock<IResetPasswordRepository>();

            resetPasswordRepository.Setup(context => context.UpdateUsersLoginPassword(mockResetPassword, It.IsAny<UserPassword>())).Returns(true);
            var resetPasswordService = new ResetPasswordService(resetPasswordRepository.Object, It.IsAny<UserProfile>());

            var response = resetPasswordService.UpdateResetPassword(mockResetPassword);
            Assert.NotNull(response);
        }

        /// <summary>
        /// Doubt
        /// </summary>
        /// <returns></returns>
        [Test]
        public async Task RevokeResetTokenTest()
        {
            var mockResetPassword = new ResetPassword();
            mockResetPassword.Token = "test";
            var resetPasswordRepository = new Mock<IResetPasswordRepository>();

            resetPasswordRepository.Setup(context => context.RevokeResetToken(mockResetPassword)).ReturnsAsync(true);
            var resetPasswordService = new ResetPasswordService(resetPasswordRepository.Object, It.IsAny<UserProfile>());

            var response = resetPasswordService.RevokeResetToken(mockResetPassword);
            Assert.NotNull(response);
        }

        [Test]
        public async Task RevokeResetTokenAsyncTest()
        {
            var mockModel = new ResetPassword();
            var resetPasswordRepository = new Mock<IResetPasswordRepository>();
          
            var resetPasswordService = new ResetPasswordService(resetPasswordRepository.Object, It.IsAny<UserProfile>());

            var response = resetPasswordService.RevokeResetTokenAsync(mockModel);
            Assert.NotNull(response);
        }

    }
}
