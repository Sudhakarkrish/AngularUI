﻿using CassPort.Core.Models;
using CassPort.Core.Repositories;
using CassPort.Core.Services;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CassPort.Core.Test
{
    public class ShipPointServiceTest
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public async Task GetUserShipPointsTest()
        {
            var mockResponse = new List<ShipPoint>();
            var shipPointRepository = new Mock<IShipPointRepository>();

            shipPointRepository.Setup(context => context.GetUserShipPoints("test", 1)).ReturnsAsync(mockResponse);
            var shipPointService = new ShipPointService(shipPointRepository.Object);

            var response = await shipPointService.GetUserShipPoints("test", 1);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetClientShipPointsTest()
        {
            var mockResponse = new List<ShipPoint>();
            var shipPointRepository = new Mock<IShipPointRepository>();

            shipPointRepository.Setup(context => context.GetClientShipPoints("test", "test")).ReturnsAsync(mockResponse);
            var shipPointService = new ShipPointService(shipPointRepository.Object);

            var response = await shipPointService.GetClientShipPoints("test", "test");
            Assert.NotNull(response);
        }
    }
}
