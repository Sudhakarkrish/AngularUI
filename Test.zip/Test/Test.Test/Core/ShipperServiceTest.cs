﻿using CassPort.Core.Models;
using CassPort.Core.Repositories;
using CassPort.Core.Services;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CassPort.Core.Test
{
    public class ShipperServiceTest
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public async Task GetShippersBySearchTest()
        {
            var mockResponse = new List<Shipper>();
            var shipperRepository = new Mock<IShipperRepository>();

            shipperRepository.Setup(context => context.GetShippersBySearch("hello")).ReturnsAsync(mockResponse);
            var shipperService = new ShipperService(shipperRepository.Object);

            var response = await shipperService.GetShippersBySearch("hello");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUserShippersTest()
        {
            var mockResponse = new List<Shipper>();
            var shipperRepository = new Mock<IShipperRepository>();

            shipperRepository.Setup(context => context.GetUserShippers(true)).ReturnsAsync(mockResponse);
            var shipperService = new ShipperService(shipperRepository.Object);

            var response = await shipperService.GetUserShippers(true);
            Assert.NotNull(response);
        }

        [Test]
        public async Task UpdateUserShippersTest()
        {
            var mockResponse = new List<Shipper>();
            var shipperRepository = new Mock<IShipperRepository>();

            shipperRepository.Setup(context => context.UpdateUserShippers(It.IsAny<List<Shipper>>(), 1)).Returns(1);
            var shipperService = new ShipperService(shipperRepository.Object);

            var response = shipperService.UpdateUserShippers(mockResponse, 1);
            Assert.NotNull(response);
        }
    }
}
