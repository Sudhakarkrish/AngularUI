﻿using CassPort.Core.Models;
using CassPort.Core.Repositories;
using CassPort.Core.Services;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CassPort.Core.Test
{
    public class TableauUserAdminServiceTest
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public async Task GetCustomDashboardTest()
        {
            var mockResponse = new List<TableauUserAdmin>();
            var tableauUserAdminRepository = new Mock<ITableauUserAdminRepository>();

            tableauUserAdminRepository.Setup(context => context.GetCustomDashboard("0", 0, 0, 1, 10, null, null)).ReturnsAsync(mockResponse);
            var tableauUserAdminService = new TableauUserAdminService(tableauUserAdminRepository.Object);

            var response = await tableauUserAdminService.GetCustomDashboard("0", 0, 0, 1, 10, null, null);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetSearchUserTest()
        {
            var mockResponse = new List<TableauUserAccount>();
            var tableauUserAdminRepository = new Mock<ITableauUserAdminRepository>();

            tableauUserAdminRepository.Setup(context => context.GetSearchUser("test", "test", "test", "test", 1, 10, null, null)).ReturnsAsync(mockResponse);
            var tableauUserAdminService = new TableauUserAdminService(tableauUserAdminRepository.Object);

            var response = await tableauUserAdminService.GetSearchUser("test", "test", "test", "test", 1, 10, null, null);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetManageDashboardByUsersTest()
        {
            var mockResponse = new List<TableauUserAdmin>();
            var tableauUserAdminRepository = new Mock<ITableauUserAdminRepository>();

            tableauUserAdminRepository.Setup(context => context.GetManageDashboardByUsers("0", 1, 0, 1, 10, null, null)).ReturnsAsync(mockResponse);
            var tableauUserAdminService = new TableauUserAdminService(tableauUserAdminRepository.Object);

            var response = await tableauUserAdminService.GetManageDashboardByUsers("0", 1, 0, 1, 10, null, null);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUserDetailsForDashboardTest()
        {
            var mockResponse = new List<DashboardUserDetail>();
            var tableauUserAdminRepository = new Mock<ITableauUserAdminRepository>();

            tableauUserAdminRepository.Setup(context => context.GetUserDetailsForDashboard(1)).ReturnsAsync(mockResponse);
            var tableauUserAdminService = new TableauUserAdminService(tableauUserAdminRepository.Object);

            var response = await tableauUserAdminService.GetUserDetailsForDashboard(1);
            Assert.NotNull(response);
        }

        [Test]
        public async Task RemoveAssignedUserTest()
        {
            var tableauUserAdminRepository = new Mock<ITableauUserAdminRepository>();

            tableauUserAdminRepository.Setup(context => context.RemoveAssignedUser(1, 1)).Returns(1);
            var tableauUserAdminService = new TableauUserAdminService(tableauUserAdminRepository.Object);

            var response = tableauUserAdminService.RemoveAssignedUser(1 , 1);
            Assert.NotNull(response);

        }

        [Test]
        public async Task InsertSelectedUserToDashboardTest()
        {
            var mockResponse = new List<InsertDashboardUsers>();
            var tableauUserAdminRepository = new Mock<ITableauUserAdminRepository>();

            tableauUserAdminRepository.Setup(context => context.InsertSelectedUserToDashboard(It.IsAny<List<InsertDashboardUsers>>())).Returns(1);
            var tableauUserAdminService = new TableauUserAdminService(tableauUserAdminRepository.Object);

            var response = tableauUserAdminService.InsertSelectedUserToDashboard(mockResponse);
            Assert.NotNull(response);
        }

        [Test]
        public async Task RemoveDashboardTest()
        {
            var tableauUserAdminRepository = new Mock<ITableauUserAdminRepository>();

            tableauUserAdminRepository.Setup(context => context.DeleteDashboard(1, 1)).Returns(1);
            var tableauUserAdminService = new TableauUserAdminService(tableauUserAdminRepository.Object);

            var response = tableauUserAdminService.TryDeleteDashboard(1, 1);
            Assert.NotNull(response);
        }

        [Test]
        public async Task CreateDashboardTest()
        {
            var tableauUserAdminRepository = new Mock<ITableauUserAdminRepository>();

            tableauUserAdminRepository.Setup(context => context.CreateDashboard(It.IsAny<CreateDashboard>())).ReturnsAsync(1);
            var tableauUserAdminService = new TableauUserAdminService(tableauUserAdminRepository.Object);

            var response = await tableauUserAdminService.CreateDashboard(It.IsAny<CreateDashboard>());
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetDashboardTypeTest()
        {
            var mockResponse = new List<DashboardType>();
            var tableauUserAdminRepository = new Mock<ITableauUserAdminRepository>();

            tableauUserAdminRepository.Setup(context => context.GetDashboardType()).ReturnsAsync(mockResponse);
            var tableauUserAdminService = new TableauUserAdminService(tableauUserAdminRepository.Object);

            var response = await tableauUserAdminService.GetDashboardType();
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetDashboardCategoryTest()
        {
            var mockResponse = new List<DashBoardCategory>();
            var tableauUserAdminRepository = new Mock<ITableauUserAdminRepository>();

            tableauUserAdminRepository.Setup(context => context.GetDashboardCategory()).ReturnsAsync(mockResponse);
            var tableauUserAdminService = new TableauUserAdminService(tableauUserAdminRepository.Object);

            var response = await tableauUserAdminService.GetDashboardCategory();
            Assert.NotNull(response);
        }
    }
}
