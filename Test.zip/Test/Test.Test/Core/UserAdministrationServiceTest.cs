﻿using CassPort.Core.Models;
using CassPort.Core.Repositories;
using CassPort.Core.Services;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CassPort.Core.Test
{
    public class UserAdministrationServiceTest
    {
        [SetUp]
        [Test]
        public async Task HasAnyPrivilegeTest()
        {
            var mockUserProfile = new UserProfile()
            {
                PrivilegeIds = new List<int> { 2, 3, 4 }
            };
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = userAdministrationService.HasAnyPrivilege(2,3,4);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetRegisteredUsersTest()
        {
            var mockUserProfile = new UserProfile()
            {
                PrivilegeIds = new List<int> { 2, 3, 4, 17 },
                LoginLevel = 2
            };
            var mockMyUserAdministration = new MyUserAdministration();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.DisableListUsers("B", "D", "0", "aFilt", "lLevCeil", "lLevFloor", "uId", "2", 2, 5, "sCol", "sDir", false)).ReturnsAsync(mockMyUserAdministration);
            userAdministrationRepository.Setup(context => context.ListUsers(" ", " ", "0", "-1", "3", "0", "0", "2", 4, 22, "sCol", "sDir")).ReturnsAsync(mockMyUserAdministration);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.GetRegisteredUsers("undefined", 4, 22, "sCol", "sDir","s");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetRegisteredUsersValueTest()
        {
            var mockUserProfile = new UserProfile()
            {
                PrivilegeIds = new List<int> { 2, 3, 4, 17 },
                LoginLevel = 4
            };
            var mockMyUserAdministration = new MyUserAdministration();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.DisableListUsers("B", "D", "0", "aFilt", "lLevCeil", "lLevFloor", "uId", "2", 2, 5, "sCol", "sDir", false)).ReturnsAsync(mockMyUserAdministration);
            userAdministrationRepository.Setup(context => context.ListUsers(" ", " ", "undefined", "-1", "3", "0", "0", "2", 4, 22, "sCol", "sDir")).ReturnsAsync(mockMyUserAdministration);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.GetRegisteredUsersValue("s", "undefined", 4, 22, "sCol", "sDir");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetRegisteredUsersListTest()
        {
            var mockUserProfile = new UserProfile()
            {
                PrivilegeIds = new List<int> { 2, 3, 4, 17 },
                LoginLevel = 4
            };
            var mockMyUserAdministration = new MyUserAdministration();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.DisableListUsers("B", "D", "0", "aFilt", "lLevCeil", "lLevFloor", "uId", "2", 2, 5, "sCol", "sDir", false)).ReturnsAsync(mockMyUserAdministration);
            userAdministrationRepository.Setup(context => context.ListUsers("B", "Disable", "D", "-1", "3", "0", "0", "2", 2, 5, "sCol", "sDir")).ReturnsAsync(mockMyUserAdministration);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.GetRegisteredUsersList("Disable", "D", "B", 2, 5, "sCol", "sDir", "0");
            Assert.NotNull(response);
        }

        [Test]
        public async Task ListUsersTest()
        {
            var mockMyUserAdministration = new MyUserAdministration();
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.DisableListUsers("B", "D", "0", "aFilt", "lLevCeil", "lLevFloor", "uId", "2", 2, 5, "sCol", "sDir", false)).ReturnsAsync(mockMyUserAdministration);
            userAdministrationRepository.Setup(context => context.ListUsers("B", "D", "ALL", "aFilt", "lLevCeil", "lLevFloor", "uId", "2", 2, 5, "sCol", "sDir")).ReturnsAsync(mockMyUserAdministration);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object,mockUserProfile,userProfileRepository.Object,userPermissionRepository.Object,shipperRepository.Object,carrierRepository.Object,mocklogger.Object);

            var response = await userAdministrationService.ListUsers("B", "D", "Disable", "aFilt", "lLevCeil", "lLevFloor", "uId", 2, 5, "sCol", "sDir");
            Assert.NotNull(response);
        }

        [Test]
        public async Task DisableDeleteTest()
        {
            var listUserAdministration = new List<UserAdministration>()
            {
             new UserAdministration{USER_ACCOUNT_ID = 3 },
             new UserAdministration{USER_ACCOUNT_ID = 4 }
            };
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = userAdministrationService.DisableDelete(listUserAdministration, "Delete", "optSerLoc", "internals", true);
            Assert.NotNull(response);
        }

        [Test]
        public async Task RemoveForwardStagingTest()
        {
            var listDeleteDisableUser = new List<DeleteDisableUser>()
            {
             new DeleteDisableUser("uid1"),
             new DeleteDisableUser("uid2")
            };
            var mockDeleteDisable = new DeleteDisable()
            {
                EditorId = "test",
                Users = listDeleteDisableUser,
                ServiceLocation = "test",
                Command = "test",
                Staging = true
            };
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            int i = 0;
            userAdministrationRepository.Setup(context => context.RemoveForwardStaging(mockDeleteDisable.ServiceLocation, mockDeleteDisable.Command, mockDeleteDisable.EditorId, listDeleteDisableUser[i].UserId))
            .Returns(() => i)
            .Callback(() => i++);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = userAdministrationService.RemoveForwardStaging(mockDeleteDisable);
            Assert.NotNull(response);
        }

        [Test]
        public async Task DisableDeleteUsersTest()
        {
            var listDeleteDisableUser = new List<DeleteDisableUser>()
            {
             new DeleteDisableUser("uid1"),
             new DeleteDisableUser("uid2")
            };
            var mockDeleteDisable = new DeleteDisable()
            {
                EditorId = "test",
                Users = listDeleteDisableUser,
                ServiceLocation = "test",
                Command = "test",
                Staging = true
            };
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            int i = 0;
            userAdministrationRepository.Setup(context => context.DisableUser(mockDeleteDisable.ServiceLocation, mockDeleteDisable.Command, mockDeleteDisable.EditorId, listDeleteDisableUser[i].UserId))
            .Returns(() => i)
            .Callback(() => i++);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = userAdministrationService.DisableDeleteUsers(mockDeleteDisable);
            Assert.NotNull(response);
        }

        [Test]
        public async Task InternalUsersTest()
        {
            var mockUserProfile = new UserProfile()
            {
                PrivilegeIds = new List<int> { 2, 3, 4, 19 },
                LoginLevel = 2
            };
            var mockMyUserAdministration = new MyUserAdministration();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.DisableListUsers("B", "D", "0", "aFilt", "lLevCeil", "lLevFloor", "uId", "2", 2, 5, "sCol", "sDir", false)).ReturnsAsync(mockMyUserAdministration);
            userAdministrationRepository.Setup(context => context.ListUsers("B", "N", "0", "-1", "5", "2", "0", "2", 4, 22, "sCol", "sDir")).ReturnsAsync(mockMyUserAdministration);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.InternalUsers("undefined", 4, 22, "sCol", "sDir");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetInternalUsersTest()
        {
            var mockUserProfile = new UserProfile()
            {
                PrivilegeIds = new List<int> { 2, 3, 4, 19 },
                LoginLevel = 2
            };
            var mockMyUserAdministration = new MyUserAdministration();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.DisableListUsers("B", "D", "0", "aFilt", "lLevCeil", "lLevFloor", "uId", "2", 2, 5, "sCol", "sDir", false)).ReturnsAsync(mockMyUserAdministration);
            userAdministrationRepository.Setup(context => context.ListUsers("B", "N", "All", "-1", "5", "2", "0", "2", 4, 22, "sCol", "sDir")).ReturnsAsync(mockMyUserAdministration);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.GetInternalUsers("All", 4, 22, "sCol", "sDir");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetInternalUserListTest()
        {
            var mockUserProfile = new UserProfile()
            {
                PrivilegeIds = new List<int> { 2, 3, 4, 19 },
                LoginLevel = 2
            };
            var mockMyUserAdministration = new MyUserAdministration();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.DisableListUsers("B", "D", "0", "aFilt", "lLevCeil", "lLevFloor", "uId", "2", 2, 5, "sCol", "sDir", false)).ReturnsAsync(mockMyUserAdministration);
            userAdministrationRepository.Setup(context => context.ListUsers("B", "N", "All", "-1", "5", "2", "0", "2", 4, 22, "sCol", "sDir")).ReturnsAsync(mockMyUserAdministration);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.GetInternalUserList("All", 4, 22, "sCol", "sDir");
            Assert.NotNull(response);
        }

        [Test]
        public async Task UnregisteredUsersTest()
        {
            var mockUserProfile = new UserProfile()
            {
                PrivilegeIds = new List<int> { 2, 3, 4, 16 },
                LoginLevel = 2
            };
            var mockMyUserAdministration = new MyUserAdministration();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.DisableListUsers("B", "D", "0", "aFilt", "lLevCeil", "lLevFloor", "uId", "2", 2, 5, "sCol", "sDir", false)).ReturnsAsync(mockMyUserAdministration);
            userAdministrationRepository.Setup(context => context.ListUsers(" ", " ", "0", "0", "5", "0", "0", "2", 4, 22, "sCol", "sDir")).ReturnsAsync(mockMyUserAdministration);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.UnregisteredUsers("undefined", 4, 22, "sCol", "sDir");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUnregisteredUsersTest()
        {
            var mockUserProfile = new UserProfile()
            {
                PrivilegeIds = new List<int> { 2, 3, 4, 16 },
                LoginLevel = 2
            };
            var mockMyUserAdministration = new MyUserAdministration();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.DisableListUsers("B", "D", "0", "aFilt", "lLevCeil", "lLevFloor", "uId", "2", 2, 5, "sCol", "sDir", false)).ReturnsAsync(mockMyUserAdministration);
            userAdministrationRepository.Setup(context => context.ListUsers(" ", " ", "All", "0", "5", "0", "0", "2", 4, 22, "sCol", "sDir")).ReturnsAsync(mockMyUserAdministration);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.GetUnregisteredUsers("D","All",null,"0", 4, 22, "sCol", "sDir");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUnregisteredUsersListTest()
        {
            var mockUserProfile = new UserProfile()
            {
                PrivilegeIds = new List<int> { 2, 3, 4, 16 },
                LoginLevel = 2
            };
            var mockMyUserAdministration = new MyUserAdministration();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.DisableListUsers("B", "D", "0", "aFilt", "lLevCeil", "lLevFloor", "uId", "2", 2, 5, "sCol", "sDir", false)).ReturnsAsync(mockMyUserAdministration);
            userAdministrationRepository.Setup(context => context.ListUsers(" ", " ", "All", "0", "5", "0", "0", "2", 4, 22, "sCol", "sDir")).ReturnsAsync(mockMyUserAdministration);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.GetUnregisteredUsersList("D", "All", null, "0", 4, 22, "sCol", "sDir");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetAllUsersTest()
        {
            var mockMyUserAdministration = new MyUserAdministration();
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.AllListUsers("0", "2", 2, 5, "sCol", "sDir")).ReturnsAsync(mockMyUserAdministration);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.GetAllUsers("undefined", 2, 5, "sCol", "sDir");
            Assert.NotNull(response);
        }

        [Test]
        public async Task AllListUsersTest()
        {
            var mockMyUserAdministration = new MyUserAdministration();
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.AllListUsers("0", "2", 2, 5, "sCol", "sDir")).ReturnsAsync(mockMyUserAdministration);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.AllListUsers("Disable", 2, 5, "sCol", "sDir");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetExternalAuthenticatorsTest()
        {
            var mockExternalAuthenticator = new List<ExternalAuthenticator>();
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.GetExternalAuthenticators()).ReturnsAsync(mockExternalAuthenticator);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.GetExternalAuthenticators();
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetExternalAuthenticationProviderMappingsTest()
        {
            var mockExternalProviderMapping = new List<ExternalProviderMapping>();
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.GetExternalAuthenticationProviderMappings(2)).ReturnsAsync(mockExternalProviderMapping);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.GetExternalAuthenticationProviderMappings(2);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUserAccountStagingTest()
        {
            var mockUserAccountDetail = new UserAccountDetail();
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.GetUserAccountStaging(2)).ReturnsAsync(mockUserAccountDetail);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.GetUserAccountStaging(2);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUserCarriersTest()
        {
            var mockCarrier = new List<Carrier>();
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.GetUserStagingCarriers(2, true)).ReturnsAsync(mockCarrier);
            userAdministrationRepository.Setup(context => context.GetUserCarriers(2, true)).ReturnsAsync(mockCarrier);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.GetUserCarriers(2, true);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetAllUserCarriersTest()
        {
            var mockCarrier = new List<Carrier>();
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.GetUserStagingCarriers(2,false)).ReturnsAsync(mockCarrier);
            userAdministrationRepository.Setup(context => context.GetUserCarriers(2, false)).ReturnsAsync(mockCarrier);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.GetAllUserCarriers(2,false);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUserShippersTest()
        {
            var mockShipper = new List<Shipper>();
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.GetUserStagingShippers(2, false)).ReturnsAsync(mockShipper);
            userAdministrationRepository.Setup(context => context.GetUserShippers(2, false)).ReturnsAsync(mockShipper);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.GetUserShippers(2);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetAllUserShippersTest()
        {
            var mockShipper = new List<Shipper>();
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.GetUserStagingShippers(2, false)).ReturnsAsync(mockShipper);
            userAdministrationRepository.Setup(context => context.GetUserShippers(2, false)).ReturnsAsync(mockShipper);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.GetAllUserShippers(2);
            Assert.NotNull(response);
        }

        /// <summary>
        /// check once service method for exception to raise
        /// </summary>
        /// <returns></returns>
        [Test]
        public async Task GetUserAccountTest()
        {
            var mockEditProfile = new EditProfile();
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userProfileRepository.Setup(context => context.GetUserAccount(2)).ReturnsAsync(mockEditProfile);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.GetUserAccount(2);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUserPrivilegeTest()
        {
            var mockUserPriviledge = new List<UserPriviledge>();
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.GetUserPrivileges(2)).ReturnsAsync(mockUserPriviledge);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.GetUserPrivilege(2);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUserShipPointsTest()
        {
            var mockShipPoint = new List<ShipPoint>();
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.GetUserShipPoints(2, "cid")).ReturnsAsync(mockShipPoint);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.GetUserShipPoints(2, "cid");
            Assert.NotNull(response);
        }

        [Test]
        public async Task LockUserTest()
        {
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.LockUser(2, 3)).Returns(1);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = userAdministrationService.LockUser(2, 3);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUserPrivilegeLimitedTest()
        {
            var mockUserPriviledge = new List<UserPriviledge>();
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.GetUserPrivilegesLimited(2, true, "test")).ReturnsAsync(mockUserPriviledge);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.GetUserPrivilegeLimited(2, true, "test");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUserPrivilegeGroupsTest()
        {
            var mockPrivilegeGroupList = new List<PrivilegeGroupList>();
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.GetUserPrivilegeGroups(2, true, "test")).ReturnsAsync(mockPrivilegeGroupList);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.GetUserPrivilegeGroups(2, true, "test");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUserPermissionsTest()
        {
            var listUserPriviledge = new List<UserPriviledge>()
            {
             new UserPriviledge(){Priviledge_Id = 2,
                                 Priviledge_Name = "test",
                                 Priviledge_Sub_Group_Id = 3,                                
                                 Priviledge_Sub_Group_Name = "test",                                
                                 Sort_Order = 4,                                
                                 Priviledge_Group_Id = 5,                                
                                 Active = true,                               
                                 Priviledge_External = false,                             
                                 Company_Type = "s"},
             new UserPriviledge(){Priviledge_Id = 3,
                                  Priviledge_Name = "test",
                                  Priviledge_Sub_Group_Id = 3,
                                  Priviledge_Sub_Group_Name = "test",
                                  Sort_Order = 4,
                                  Priviledge_Group_Id = 5,
                                  Active = true,
                                  Priviledge_External = false,
                                  Company_Type = "s"}
            };        
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userPermissionRepository.Setup(context => context.GetUserPermissions(true, "test")).ReturnsAsync(listUserPriviledge);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.GetUserPermissions(true, "test");
            Assert.NotNull(response);
        }

        [Test]
        public async Task CheckUniqueTest()
        {
            var mockUserAccountDetail = new UserAccountDetail() {
                TestAccount = true,
                Email = "yash@cass.com",
                UserAccountId = 3,
                LoginName = "yash",
                DolCode = "Dcode",
                ChemoursDolCode = null,
                VeoliaDolCode = null,
                SfrClient4DolCode = null,
                SfrClient5DolCode = null,
                ExternalAuthenticationId = 3
            };
            var mockUserAdmin = new UserAdmin() { User = mockUserAccountDetail, NewUser = true };
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = userAdministrationService.CheckUnique(mockUserAdmin);
            Assert.NotNull(response);
        }

        [Test]
        public async Task VerifyIsUniqueTest()
        {
            var mockUniqueUserRequestModel = new UniqueUserRequestModel() {
                IsTestAccount = true,
                Email = "yash@cass.com",
                UserId = 3,
                LoginName = "yash",
                IsNewUser = true,
                DupontDol = "Dcode",
                ChemoursDol = null,
                VeoliaDol = null,
                SfrClient4Dol = null,
                SfrClient5Dol = null,
                ExternalAuthId = 3
            };
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = userAdministrationService.VerifyIsUnique(mockUniqueUserRequestModel);
            Assert.NotNull(response);
        }

        [Test]
        public async Task IsLoginNameUniqueTest()
        {
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.IsUnique("test", "L", 0)).Returns(false);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = userAdministrationService.IsLoginNameUnique("test", 2);
            Assert.NotNull(response);
        }

        [Test]
        public async Task IsExternalEmailUniqueTest()
        {
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.IsExternalEmailAvailable(2, "email@email.com", 3)).Returns(true);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = userAdministrationService.IsExternalEmailUnique(2, "email@email.com", 3);
            Assert.NotNull(response);
        }

        [Test]
        public async Task CheckUniqueDolCodeDupontTest()
        {
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.CheckUniqueDolCode("code", 2, "DUPOINT")).Returns(1);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = userAdministrationService.CheckUniqueDolCodeDupont("code", 2);
            Assert.NotNull(response);
        }

        [Test]
        public async Task CheckUniqueDolCodeChemoursTest()
        {
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.CheckUniqueDolCode("code", 2, "CHEMOURS")).Returns(1);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = userAdministrationService.CheckUniqueDolCodeChemours("code", 2);
            Assert.NotNull(response);
        }

        [Test]
        public async Task CheckUniqueDolCodeVeoliaTest()
        {
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.CheckUniqueDolCode("code", 2, "VEOLIA")).Returns(1);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = userAdministrationService.CheckUniqueDolCodeVeolia("code", 2);
            Assert.NotNull(response);
        }

        [Test]
        public async Task CheckUniqueDolCodeSFRClient4Test()
        {
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.CheckUniqueDolCode("code", 2, "SFRClient4")).Returns(1);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = userAdministrationService.CheckUniqueDolCodeSFRClient4("code", 2);
            Assert.NotNull(response);
        }

        [Test]
        public async Task CheckUniqueDolCodeSFRClient5Test()
        {
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.CheckUniqueDolCode("code", 2, "SFRClient5")).Returns(1);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = userAdministrationService.CheckUniqueDolCodeSFRClient5("code", 2);
            Assert.NotNull(response);
        }

        [Test]
        public async Task RegisterUserTest()
        {
            var mockUserAccountDetail = new UserAccountDetail() {
                ExternalAuthenticationId = 2
            };
            var mockExternalAuthenticator = new ExternalAuthenticator() {
                External_Authentication_Id = 3,
                Company_Name = "dupoint"
            };
            var mockUserAdmin = new UserAdmin() {
                User = mockUserAccountDetail
            };
            var mockUserProfile = new UserProfile() {
                ExternalAuth = mockExternalAuthenticator
            };
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.RegisterUser(mockUserAdmin);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GeneratePasswordTest()
        {
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = userAdministrationService.GeneratePassword(3);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetLetterTextTest()
        {
            string letterName = "Lname";
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.GetLetterText(" "+ letterName)).Returns(" "+ letterName);
            userAdministrationRepository.Setup(context => context.GetLetterText("AdminWarning")).Returns("AdminWarning");
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = userAdministrationService.GetLetterText("D", 2, letterName, "yash", "yash$1");
            Assert.NotNull(response);
        }       

        [Test]
        public async Task GetCheckPriviledgeTest()
        {
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = userAdministrationService.GetCheckPriviledge("AdminMenu");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetVerifyInternalUserTest()
        {
            var mockActiveDirectory = new ActiveDirectory();
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.VerifyUserInAD("email@email.com")).Returns(mockActiveDirectory);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = userAdministrationService.GetVerifyInternalUser("email@email.com");
            Assert.NotNull(response);
        }

        [Test]
        public async Task RequestDeleteUserTest()
        {
            var mockUserProfile = new UserProfile()
            {
                UserId = 3,
                PrivilegeIds = new List<int> { 15, 16, 17},
                LoginLevel = 4
            };
            var mockUserAdministration = new List<UserAdministration>() {
                new UserAdministration(){ USER_ACCOUNT_ID = 0},
                new UserAdministration(){ USER_ACCOUNT_ID = 2}
            };
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.RequestDeleteUser(mockUserAdministration);
            Assert.NotNull(response);
        }

        [Test]
        public async Task TryDeleteUserTest()
        {
            var mockUserProfile = new UserProfile() {
                LoginLevel = 4
            };
            var mockUserIsLockedByEditingUserCount = new UserIsLockedByEditingUserCount()
            {
                LOCK_COUNT = 1
            };            
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.VerifyUserIsLockedByEditingUser(2, 3)).ReturnsAsync(mockUserIsLockedByEditingUserCount);
            userAdministrationRepository.Setup(context => context.VerifyAdminCanEditUser(2, 3)).Returns(true);
            userAdministrationRepository.Setup(context => context.DeleteUser(2, 3)).Returns(1);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.TryDeleteUser(2, 3);
            Assert.NotNull(response);
        }

        [Test]
        public async Task DeleteUsersTest()
        {
            var mockUserIsLockedByEditingUserCount = new UserIsLockedByEditingUserCount()
            {
                LOCK_COUNT = 1
            };
            var mockUserProfile = new UserProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userPermissionRepository = new Mock<IUserPermissionRepository>();
            var shipperRepository = new Mock<IShipperRepository>();
            var carrierRepository = new Mock<ICarrierRepository>();
            var mocklogger = new Mock<ILogger<UserAdministrationService>>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userAdministrationRepository.Setup(context => context.VerifyUserIsLockedByEditingUser(2, 3)).ReturnsAsync(mockUserIsLockedByEditingUserCount);
            userAdministrationRepository.Setup(context => context.VerifyAdminCanEditUser(2, 3)).Returns(true);
            userAdministrationRepository.Setup(context => context.DeleteUser(2, 3)).Returns(1);
            var userAdministrationService = new UserAdministrationService(userAdministrationRepository.Object, mockUserProfile, userProfileRepository.Object, userPermissionRepository.Object, shipperRepository.Object, carrierRepository.Object, mocklogger.Object);

            var response = await userAdministrationService.DeleteUsers(2 , 3);
            Assert.NotNull(response);
        }
    }
}
