﻿using CassPort.Core.Models;
using CassPort.Core.Repositories;
using CassPort.Core.Services;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CassPort.Core.Test
{
    public class UserClaimsServiceTest
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public async Task GetUserProfileTest()
        {
            var mockResponse = new UserProfile();
            var userClaimsRepository = new Mock<IUserClaimsRepository>();

            userClaimsRepository.Setup(context => context.GetUserProfile(1)).ReturnsAsync(mockResponse);
            var userClaimsService = new UserClaimsService(userClaimsRepository.Object);

            var response = await userClaimsService.GetUserProfile(1);
            Assert.NotNull(response);
        }
    }
}
