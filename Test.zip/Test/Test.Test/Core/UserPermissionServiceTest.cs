﻿using CassPort.Core.Models;
using CassPort.Core.Repositories;
using CassPort.Core.Services;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CassPort.Core.Test
{
    public class UserPermissionServiceTest
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public async Task GetUserPermissionsTest()
        {
            var mockResponse = new List<UserPriviledge>();
            var userPermissionRRepository = new Mock<IUserPermissionRepository>();

            userPermissionRRepository.Setup(context => context.GetUserPermissions(true, "S")).ReturnsAsync(mockResponse);
            var userPermissionService = new UserPermissionService(userPermissionRRepository.Object);

            var response = await userPermissionService.GetUserPermissions(true, "S");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUserPrivilegeGroupsTest()
        {
            var mockResponse = new List<PrivilegeGroupList>();
            var userPermissionRRepository = new Mock<IUserPermissionRepository>();

            userPermissionRRepository.Setup(context => context.GetUserPrivilegeGroups(true, "S")).ReturnsAsync(mockResponse);
            var userPermissionService = new UserPermissionService(userPermissionRRepository.Object);

            var response = await userPermissionService.GetUserPrivilegeGroups(true, "S");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUserPermissionsByGroupTest()
        {
            var mockResponse = new List<UserPriviledge>();
            var userPermissionRRepository = new Mock<IUserPermissionRepository>();

            userPermissionRRepository.Setup(context => context.GetUserPermissionsByGroup(true, "S", "1", "")).ReturnsAsync(mockResponse);
            var userPermissionService = new UserPermissionService(userPermissionRRepository.Object);

            var response = await userPermissionService.GetUserPermissionsByGroup(true, "S", "1", "");
            Assert.NotNull(response);
        }
    }
}
