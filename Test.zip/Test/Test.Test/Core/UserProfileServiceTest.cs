﻿using CassPort.Core.Models;
using CassPort.Core.Repositories;
using CassPort.Core.Services;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CassPort.Core.Test
{
    public class UserProfileServiceTest
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public async Task GetUserDetailTest()
        {
            var mockUserRole = new UserRole();
            var mockUserProfile = new UserProfile
            {
                UserName = "yash",
                FirstName = "raj",
                LastName = "yash",
                LoginLevel = 1,
                CompanyType = "test",
                UserId = 2,
                PrivilegeIds = new List<int>() { 2, 3, 5, 7 }
            };
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            var userProfileService = new UserProfileService(userProfileRepository.Object, mockUserProfile, userAdministrationRepository.Object);

            var response = userProfileService.GetUserDetail();
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetCountriesTest()
        {
            var mockCountry = new List<Country>();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userProfileRepository.Setup(context => context.GetCountries()).ReturnsAsync(mockCountry);
            var userProfileService = new UserProfileService(userProfileRepository.Object, It.IsAny<UserProfile>(), userAdministrationRepository.Object);

            var response = await userProfileService.GetCountries();
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetStatesTest()
        {
            var mockResponse = new List<State>();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userProfileRepository.Setup(context => context.GetStates("US")).ReturnsAsync(mockResponse);
            var userProfileService = new UserProfileService(userProfileRepository.Object, It.IsAny<UserProfile>(), userAdministrationRepository.Object);

            var response = await userProfileService.GetStates("US");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUserAccountTest()
        {
            var mockResponse = new EditProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userProfileRepository.Setup(context => context.GetUserAccount(1)).ReturnsAsync(mockResponse);
            var userProfileService = new UserProfileService(userProfileRepository.Object, It.IsAny<UserProfile>(), userAdministrationRepository.Object);

            var response = await userProfileService.GetUserAccount(1);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetTableauUserAccountTest()
        {
            var mockResponse = new TableauUserAccountDetail();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userProfileRepository.Setup(context => context.GetTableauUserAccount(1)).ReturnsAsync(mockResponse);
            var userProfileService = new UserProfileService(userProfileRepository.Object, It.IsAny<UserProfile>(), userAdministrationRepository.Object);

            var response = await userProfileService.GetTableauUserAccount(1);
            Assert.NotNull(response);
        }

        /// <summary>
        /// Yet to Update
        /// </summary>
        /// <returns></returns>
        [Test]
        public async Task UpdateUserProfileTest()
        {
            var mockUserProfile = new UserProfile();
            mockUserProfile.UserId = 22;
            var mockUserIsLockedByEditingUserCount = new UserIsLockedByEditingUserCount();
            mockUserIsLockedByEditingUserCount.LOCK_COUNT = 2;
            var mockResponse = new EditProfile();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userProfileRepository.Setup(context => context.UpdateUserProfile(It.IsAny<EditProfile>())).Returns(true);
            userAdministrationRepository.Setup(context => context.VerifyUserIsLockedByEditingUser(mockUserProfile.UserId, mockUserProfile.UserId)).ReturnsAsync(mockUserIsLockedByEditingUserCount);
            var userProfileService = new UserProfileService(userProfileRepository.Object, mockUserProfile, userAdministrationRepository.Object);

            var response = userProfileService.UpdateUserProfile(mockResponse);
            Assert.NotNull(response);
        }

        [Test]
        public async Task RegisterUserProfileTest()
        {
            var mockResponse = new RegisterViewModel();
            var userProfileRepository = new Mock<IUserProfileRepository>();
            var userAdministrationRepository = new Mock<IUserAdministrationRepository>();

            userProfileRepository.Setup(context => context.RegisterUserProfile(It.IsAny<RegisterViewModel>())).Returns(true);
            var userProfileService = new UserProfileService(userProfileRepository.Object, It.IsAny<UserProfile>(), userAdministrationRepository.Object);

            var response = userProfileService.RegisterUserProfile(mockResponse);
            Assert.NotNull(response);
        }
    }
}
