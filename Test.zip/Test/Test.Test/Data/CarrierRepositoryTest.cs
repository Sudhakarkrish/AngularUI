﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CassPort.Core.Models;
using CassPort.Data.Context;
using CassPort.Data.Entities;
using CassPort.Data.Repositories;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;

namespace CassPort.Data.Test
{
    public class CarrierRepositoryTest
    {
        private ProfileContext mockContext;
        private UserProfile userProfile;
        protected IMapper _mapper;

        [SetUp]
        public void Setup()
        {
            if (_mapper == null)
            {
                Mapper.Reset();
                Mapper.Initialize(cfg =>
                {

                });
                _mapper = new Mapper(Mapper.Configuration);
            }

            FakeContext context = new FakeContext();
            mockContext = context.SetupMockContext();
        }

        [Test]
        public async Task GetCarriersBySearchTest()
        {
            try
            {
                var carrierList = BindCarriers();

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.GetCarriersBySearch("Test", "C")).ReturnsAsync(carrierList);

                var carrierRepository = new CarrierRepository(mockContext1.Object, _mapper, new UserProfile());
                var response = await carrierRepository.GetCarriersBySearch("Test");

                Assert.IsNotNull(response);
                Assert.AreEqual(response.Count, 2);
            }
            catch (Exception ex)
            { throw; }
        }

        [Test]
        public async Task GetUserCarriersTest()
        {
            try
            {
                var carrierList = BindCarriers();
                userProfile = new UserProfile();
                userProfile.UserId = 10291;                                

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.GetUserCarriers(userProfile.UserId, false)).ReturnsAsync(carrierList);

                var carrierRepository = new CarrierRepository(mockContext1.Object, _mapper, userProfile);
                var response = await carrierRepository.GetUserCarriers(false);

                Assert.IsNotNull(response);
                Assert.AreEqual(response.Count, 2);
            }
            catch (Exception ex)
            { throw; }
        }

        //[Test]
        public void UpdateUserCarriersTest()
        {
            var data = BindCarriers();
            var mockContext2 = new Mock<ProfileContext>();
            mockContext2.SetupGet(c => c.UserCarrier).Returns(GetMockUpdateCarrier().Object);

            var carrierRepository = new CarrierRepository(mockContext2.Object, _mapper, new UserProfile());
            var response = carrierRepository.UpdateUserCarriers(data, 1);

            Assert.IsNotNull(response);
        }

        private List<Core.Models.Carrier> BindCarriers()
        {
            var carrierList = new List<Core.Models.Carrier>();
            carrierList.Add(new Core.Models.Carrier
            {
                Carrier_Code = "000001",
                Carrier_Name = "Test"
            });
            carrierList.Add(new Core.Models.Carrier
            {
                Carrier_Code = "000002",
                Carrier_Name = "Test 2"
            });

            return carrierList;
        }

        private static Mock<DbSet<CassPort.Data.Entities.UserCarrier>> GetMockUpdateCarrier()
        {
            IQueryable<CassPort.Data.Entities.UserCarrier> userCarrier = new List<CassPort.Data.Entities.UserCarrier>
            {
               new CassPort.Data.Entities.UserCarrier { CarrierCode="Test",UserAccountId=1 },
               new CassPort.Data.Entities.UserCarrier { CarrierCode="Test1",UserAccountId= 2 }
            }.AsQueryable();

            return MockDbSetHelper.GetDbSet<CassPort.Data.Entities.UserCarrier>(userCarrier);
        }
    }
}
