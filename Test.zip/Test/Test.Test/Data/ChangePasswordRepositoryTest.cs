﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CassPort.Core.Models;
using CassPort.Data.Context;
using CassPort.Data.Entities;
using CassPort.Data.Repositories;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;

namespace CassPort.Data.Test
{
    public class ChangePasswordRepositoryTest
    {
        private ProfileContext mockContext;
        private UserProfile userProfile;
        protected IMapper _mapper;

        [SetUp]
        public void Setup()
        {
            if (_mapper == null)
            {
                Mapper.Reset();
                Mapper.Initialize(cfg =>
                {

                });
                _mapper = new Mapper(Mapper.Configuration);
            }

            FakeContext context = new FakeContext();
            mockContext = context.SetupMockContext();
        }

        [Test]
        public async Task GetUserPasswordHistoryTest()
        {
            try
            {
                var data = BindChangePassword();

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.GetPasswordHistory(0, null)).ReturnsAsync(data);

                var changePasswordRepository = new ChangePasswordRepository(mockContext1.Object, _mapper, new UserProfile());
                var response = await changePasswordRepository.GetUserPasswordHistory();

                Assert.IsNotNull(response);
                Assert.AreEqual(response.Count, 2);
            }
            catch (Exception ex)
            { throw; }
        }

        //[Test]
        //public async Task GetUserPasswordTest()
        //{
        //    try
        //    {
        //        var mockContext2 = new Mock<ProfileContext>();
        //        mockContext2.SetupGet(c => c.UserAccount).Returns(GetMockUserPassword().Object);

        //        var changePasswordRepository = new ChangePasswordRepository(mockContext2.Object, _mapper, new UserProfile());
        //        var response = await changePasswordRepository.GetUserPassword();

        //        Assert.IsNotNull(response);
        //    }
        //    catch (Exception ex)
        //    { throw; }
        //}

        private List<Core.Models.ChangePassword> BindChangePassword()
        {
            var changePasswordlist = new List<Core.Models.ChangePassword>();
            changePasswordlist.Add(new Core.Models.ChangePassword
            {
                USER_ACCOUNT_ID = 1,
                LOGIN_VERSION = 1
            });
            changePasswordlist.Add(new Core.Models.ChangePassword
            {
                USER_ACCOUNT_ID = 1,
                LOGIN_VERSION = 1
            });

            return changePasswordlist;
        }
    }
}
