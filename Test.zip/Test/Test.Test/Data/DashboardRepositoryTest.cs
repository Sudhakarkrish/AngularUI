﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CassPort.Core.Models;
using CassPort.Data.Context;
using CassPort.Data.Entities;
using CassPort.Data.Repositories;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;

namespace CassPort.Data.Test
{
    public class DashboardRepositoryTest
    {
        private ProfileContext mockContext;
        private UserProfile userProfile;
        protected IMapper _mapper;

        [SetUp]
        public void Setup()
        {
            if (_mapper == null)
            {
                Mapper.Reset();
                Mapper.Initialize(cfg =>
                {

                });
                _mapper = new Mapper(Mapper.Configuration);
            }

            FakeContext context = new FakeContext();
            mockContext = context.SetupMockContext();
        }

        [Test]
        public async Task GetDashboardTest()
        {
            try
            {
                var data = BindDashboard();

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.GetDashboardDetails(0, "All Categories")).ReturnsAsync(data);

                var dashBoardRepository = new DashBoardRepository(mockContext1.Object, _mapper, new UserProfile());
                var response = await dashBoardRepository.GetDashboard("All Categories");

                Assert.IsNotNull(response);
                Assert.AreEqual(response.Count, 2);
            }
            catch (Exception ex)
            { throw; }
        }

        [Test]
        public async Task GetCategoryTest()
        {
            try
            {
                var mockContext2 = new Mock<ProfileContext>();
                mockContext2.SetupGet(c => c.DashboardCategory).Returns(GetMockDashboardCategory().Object);

                var dashBoardRepository = new DashBoardRepository(mockContext2.Object, _mapper, new UserProfile());
                var response = await dashBoardRepository.GetCategory();

                Assert.IsNotNull(response);
            }
            catch (Exception ex)
            { throw; }
        }

        [Test]
        public void SaveDashBoardTest()
        {
            var data = BindDashboard();
            var mockContext2 = new Mock<ProfileContext>();
            mockContext2.SetupGet(c => c.UserSelectedDashboard).Returns(GetMockSaveDashBoard().Object);

            var dashBoardRepository = new DashBoardRepository(mockContext2.Object, _mapper, new UserProfile());
            var response = dashBoardRepository.SaveDashBoard(data);

            Assert.IsNotNull(response);
        }

        private List<Core.Models.DashBoardDetail> BindDashboard()
        {
            var dashBoardDetaillist = new List<Core.Models.DashBoardDetail>();
            dashBoardDetaillist.Add(new Core.Models.DashBoardDetail
            {
                DashBoardName = "test",
                DashBoardType  = 1
            });
            dashBoardDetaillist.Add(new Core.Models.DashBoardDetail
            {
                DashBoardName = "test1",
                DashBoardType = 2
            });

            return dashBoardDetaillist;
        }

        private static Mock<DbSet<CassPort.Data.Entities.DashboardCategory>> GetMockDashboardCategory()
        {
            IQueryable<CassPort.Data.Entities.DashboardCategory> dashboardCategory = new List<CassPort.Data.Entities.DashboardCategory>
            {
               new CassPort.Data.Entities.DashboardCategory {CategoryName = "Test" },
               new CassPort.Data.Entities.DashboardCategory { CategoryName = "Test1" }
            }.AsQueryable();

            return MockDbSetHelper.GetDbSet<CassPort.Data.Entities.DashboardCategory>(dashboardCategory);
        }

        private static Mock<DbSet<CassPort.Data.Entities.UserSelectedDashboard>> GetMockSaveDashBoard()
        {
            IQueryable<CassPort.Data.Entities.UserSelectedDashboard> userCarrier = new List<CassPort.Data.Entities.UserSelectedDashboard>
            {
               new CassPort.Data.Entities.UserSelectedDashboard { DashboardId=1,UserAccountId=1 },
               new CassPort.Data.Entities.UserSelectedDashboard { DashboardId=2,UserAccountId= 2 }
            }.AsQueryable();

            return MockDbSetHelper.GetDbSet<CassPort.Data.Entities.UserSelectedDashboard>(userCarrier);
        }
    }
}

