﻿using CassPort.Core.Models;
using CassPort.Data.Context;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CassPort.Data.Test
{
    public class FakeContext 
    {
        public ProfileContext GetMockContext()
        {
            DbContextOptions<ProfileContext> options;
            var builder = new DbContextOptionsBuilder<ProfileContext>();
            builder.UseSqlServer("DummyDatabase");
            options = builder.Options;
            var context = new ProfileContext(options, null, null);
            context.SaveChanges();
            return context;
        }

        public ProfileContext SetupMockContext()
        {
            var options = new DbContextOptionsBuilder<ProfileContext>()
                             .UseInMemoryDatabase(Guid.NewGuid().ToString())
                             .Options;

            IOptions<Core.Models.DBEnvironments> conString = Options.Create<Core.Models.DBEnvironments>(new DBEnvironments()
            {
                CassPortConnection = "Server=xxx;Database=xxx;Trusted_Connection=True;",
                CassPortReportConnection = "Server=xxx;Database=xxx;Trusted_Connection=True;"
            });

            var context = new ProfileContext(options, null, conString);
            context.SaveChanges();
            return context;
        }
    }
}

