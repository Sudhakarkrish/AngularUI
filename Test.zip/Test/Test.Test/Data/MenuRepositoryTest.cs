using CassPort.Core.Models;
using NUnit.Framework;
using System.Threading.Tasks;
using System.Collections.Generic;
using CassPort.Core.Services;
using Moq;
using CassPort.Core.Repositories;
using CassPort.Data.Entities;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using AutoMapper;
using System;
using CassPort.Data.Repositories;
using System.Linq.Expressions;
using CassPort.Data.Context;

namespace CassPort.Data.Test
{
    public class MenuRepositoryTest
    {
        private UserProfile mockUserProfile;
        private ProfileContext mockContext;
        protected IMapper _mapper;

        private IMenuRepository MenuRepository { get; }

        [SetUp]
        public void Setup()
        {
            Mapper.Initialize(cfg =>
            {

            });
            _mapper = new Mapper(Mapper.Configuration);

            mockContext = this.GetMockContext();
            mockUserProfile = this.GetMockUserProfile();
        }

        //[Test]
        public async Task GetMenusTest()
        {
            DbContextOptions<ProfileContext> options;
            var builder = new DbContextOptionsBuilder<ProfileContext>();
            builder.UseSqlServer("DummyDatabase");
            options = builder.Options;
            var context = new ProfileContext(options, null, null);
            var mockProvider = new Mock<IQueryProvider>();
            mockProvider.Setup(s => s.CreateQuery(It.IsAny<MethodCallExpression>()))
                .Returns(null as IQueryable);
            var mockDbSet = new Mock<DbSet<CassportNavItem>>();
            mockDbSet.As<IQueryable<CassportNavItem>>()
                .Setup(s => s.Provider)
                .Returns(mockProvider.Object);
            var t = mockDbSet.Object;
            context.CassportNavItem = mockDbSet.Object;

            var menuRepository = new MenuRepository(context, _mapper, mockUserProfile);

            //mockContext1.Setup(context => context.CassportNavItem.FromSql(It.IsAny<RawSqlString>(), It.IsAny<Object[]>()));//.ReturnsAsync(menuItems);//.ReturnsAsync(menuItems);

            var response = await menuRepository.GetMenus();
            Assert.IsNotNull(response);
            Assert.AreEqual(response.Count, 3);
        }

        private ProfileContext GetMockContext()
        {
            DbContextOptions<ProfileContext> options;
            var builder = new DbContextOptionsBuilder<ProfileContext>();
            builder.UseSqlServer("DummyDatabase");
            options = builder.Options;
            var context = new ProfileContext(options, null, null);

            context.CassportNavItem.Add(new CassportNavItem
            {
                CassportNavItemId=1,
                ExplicitSortOrder =1,
                GroupName ="Client",
                IsEnabled = true,
                MenuGroup ="Group1",
                Text ="Inquiry"
            });

            context.CassportNavItem.Add(new CassportNavItem
            {
                CassportNavItemId = 2,
                ExplicitSortOrder = 1,
                GroupName = "Carrier",
                IsEnabled = true,
                MenuGroup = "Group1",
                Text = "Inquiry"
            });

            context.CassportNavItem.Add(new CassportNavItem
            {
                CassportNavItemId = 3,
                ExplicitSortOrder = 1,
                GroupName = "Admin",
                IsEnabled = true,
                MenuGroup = "Group1",
                Text = "Inquiry"
            });

            context.SaveChanges();

            return context;
        }


        private UserProfile GetMockUserProfile()
        {
            var userProfile = (new UserProfile{
                UserId = 9271,
                UserName = "SRajendran"
            });
            return userProfile;
        }
    }
}