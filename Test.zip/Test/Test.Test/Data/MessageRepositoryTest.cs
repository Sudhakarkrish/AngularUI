﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using CassPort.Core.Models;
using CassPort.Data.Context;
using CassPort.Data.Repositories;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;

namespace CassPort.Data.Test
{
    public class MessageRepositoryTest
    {
        private ProfileContext mockContext;
        private UserProfile userProfile;
        protected IMapper _mapper;

        [SetUp]
        public void Setup()
        {
            if (_mapper == null)
            {
                Mapper.Reset();
                Mapper.Initialize(cfg =>
                {

                });
                _mapper = new Mapper(Mapper.Configuration);
            }

            FakeContext context = new FakeContext();
            mockContext = context.GetMockContext();
        }

        [Test]
        public async Task GetMyMessagesTest()
        {
            try
            {
                userProfile = new UserProfile();
                userProfile.UserId = 1001;
                userProfile.CompanyType = "C";

                int userType = 3;               

                var myMessages = new List<Messages>();
                myMessages.Add(new Messages
                {
                    NewMessageId = 101,
                    NewMessageName = "Message Test",
                    NewMessageText = "Text Test",
                    TotalCount = 2
                });
                myMessages.Add(new Messages
                {
                    NewMessageId = 102,
                    NewMessageName = "Message Test 2",
                    NewMessageText = "Text Test 2",
                    TotalCount =2
                });
                
                var msgcount = new MessagesCount();
                msgcount.TotalCount = 2;

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.GetMyMessagesList(userProfile.UserId, userType, 1, 10)).ReturnsAsync(myMessages);

                var messageRepository = new MessageRepository(_mapper, userProfile, new ReportProfileContext(), mockContext1.Object);
                var response = await messageRepository.GetMyMessages(1, 10);

                Assert.IsNotNull(response);
                Assert.AreEqual(response[0].TotalCount, 2);
                Assert.AreEqual(response[0].NewMessageId, 101);
            }
            catch (Exception ex)
            { throw; }
        }

        [Test]
        public async Task GetMyMessagesForHeaderTest()
        {
            try
            {
                userProfile = new UserProfile();
                userProfile.UserId = 1001;
                userProfile.CompanyType = "C";

                int userType = 3;

                var myMessages = new List<HeaderMessages>();
                myMessages.Add(new HeaderMessages
                {
                    NewMessageId = 101,
                    NewMessageName = "Message Test",
                    NewMessageText = "Text Test",
                });
                myMessages.Add(new HeaderMessages
                {
                    NewMessageId = 102,
                    NewMessageName = "Message Test 2",
                    NewMessageText = "Text Test 2",
                });

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.GetMyMessagesListForHeader(userProfile.UserId, userType)).ReturnsAsync(myMessages);

                var messageRepository = new MessageRepository(_mapper, userProfile, new ReportProfileContext(), mockContext1.Object);
                var response = await messageRepository.GetMyMessagesForHeader();

                Assert.IsNotNull(response);
                Assert.AreEqual(response.Count, 2);
            }
            catch (Exception ex)
            { throw; }
        }
    }
}
