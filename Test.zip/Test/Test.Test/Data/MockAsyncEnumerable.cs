﻿using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace CassPort.Data.Test
{
    // Async enumerable for unit testing
    internal class MockAsyncEnumerable<T> : EnumerableQuery<T>, IAsyncEnumerable<T>, IQueryable<T>
    {
        public MockAsyncEnumerable(IEnumerable<T> enumerable)
            : base(enumerable)
        { }

        public MockAsyncEnumerable(Expression expression)
            : base(expression)
        { }

        public IAsyncEnumerator<T> GetEnumerator()
        {
            return new TestAsyncEnumerator<T>(this.AsEnumerable().GetEnumerator());
        }

        IQueryProvider IQueryable.Provider
        {
            get { return new MockAsyncQueryProvider<T>(this); }
        }
    }
}