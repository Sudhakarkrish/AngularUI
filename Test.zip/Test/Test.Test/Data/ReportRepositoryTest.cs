﻿using AutoMapper;
using CassPort.Core.Models;
using CassPort.Data.Context;
using CassPort.Data.Repositories;
using CassPort.Data.Test;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CassPort.Core.Test
{
    public class ReportRepositoryTest
    {
        private ProfileContext mockContext;
        protected IMapper _mapper;

        [SetUp]
        public void Setup()
        {
            if (_mapper == null)
            {
                Mapper.Reset();
                Mapper.Initialize(cfg =>
                {

                });
                _mapper = new Mapper(Mapper.Configuration);
            }

            FakeContext context = new FakeContext();
            mockContext = context.GetMockContext();
        }

        [Test]
        public async Task GetUserReportTest()
        {
            var mockResponse = new List<Core.Models.MyReport>();
            mockResponse.Add(new Models.MyReport
            {
                Report_Id = 100,
                Report_Title = "ClientReport",
                Report_Description = "Description",
                Category_Name = "Parcel",
                Display_Subcategory = "Test",
                Instance_Count = 5,
                Sort_Order = 2,
                Shipper_Range = "Zero"
            });
            mockResponse.Add(new Models.MyReport
            {
                Report_Id = 200,
                Report_Title = "VendorReport",
                Report_Description = "Description",
                Category_Name = "Parcel",
                Display_Subcategory = "Test",
                Instance_Count = 5,
                Sort_Order = 2,
                Shipper_Range = "Zero"
            });

            var mockContext1 = new Mock<ProfileContext>();
            mockContext1.Setup(context => context.GetMyReportsList(0, 0)).ReturnsAsync(mockResponse);
            var reportRepository = new ReportRepository(mockContext1.Object, _mapper, new UserProfile());
            var response = await reportRepository.GetUserReport();
            Assert.IsNotNull(response);
        }

        [Test]
        public async Task GetReportInstanceByIdTest()
        {
            var mockResponse = new List<Core.Models.ReportInstance>();
            mockResponse.Add(new Models.ReportInstance
            {
                Report_Instance_Id = 100,
                Process_Date_Start = "26-06-2019",
                Process_Date_End = "26-06-2020",
                Report_Path = "test/test/test",
                Report_Extension = ".",
                Category_Name = "",
                Report_SubTitle = "",
                Report_Sequence = ""
            });
            mockResponse.Add(new Models.ReportInstance
            {
                Report_Instance_Id = 100,
                Process_Date_Start = "26-06-2019",
                Process_Date_End = "26-06-2020",
                Report_Path = "test/test/test",
                Report_Extension = ".",
                Category_Name = "",
                Report_SubTitle = "",
                Report_Sequence = ""
            });

            var mockContext1 = new Mock<ProfileContext>();
            mockContext1.Setup(context => context.GetReportInstanceById(0, true)).ReturnsAsync(mockResponse);
            var reportRepository = new ReportRepository(mockContext1.Object, _mapper, new UserProfile());
            var response = await reportRepository.GetReportInstanceById(0, true);
            Assert.IsNotNull(response);
        }

        [Test]
        public async Task GetReportInstanceBySearchValueTest()
        {
            var mockResponse = new List<Core.Models.ReportInstance>();
            mockResponse.Add(new Models.ReportInstance
            {
                Report_Instance_Id = 100,
                Process_Date_Start = "26-06-2019",
                Process_Date_End = "26-06-2020",
                Report_Path = "test/test/test",
                Report_Extension = ".",
                Category_Name = "",
                Report_SubTitle = "",
                Report_Sequence = ""
            });
            mockResponse.Add(new Models.ReportInstance
            {
                Report_Instance_Id = 100,
                Process_Date_Start = "26-06-2019",
                Process_Date_End = "26-06-2020",
                Report_Path = "test/test/test",
                Report_Extension = ".",
                Category_Name = "",
                Report_SubTitle = "",
                Report_Sequence = ""
            });

            var mockContext1 = new Mock<ProfileContext>();
            mockContext1.Setup(context => context.GetReportInstanceBySearchValue(0, true, "26-06-2019", "26-06-2020")).ReturnsAsync(mockResponse);
            var reportRepository = new ReportRepository(mockContext1.Object, _mapper, new UserProfile());
            var response = await reportRepository.GetReportInstanceBySearchValue(0, true, "26-06-2019", "26-06-2020");
            Assert.IsNotNull(response);
        }

        [Test]
        public async Task GetUserReportBySearchTest()
        {
            var mockResponse = new List<Core.Models.MyReport>();
            mockResponse.Add(new Models.MyReport
            {
                Report_Id = 100,
                Report_Title = "Custom Report",
                Report_Description = "",
                Category_Name = "Custom",
                Display_Subcategory = "",
                Instance_Count = 2,
                Sort_Order = 2,
                Shipper_Range = ""
            });
            mockResponse.Add(new Models.MyReport
            {
                Report_Id = 100,
                Report_Title = "Custom Report",
                Report_Description = "",
                Category_Name = "Custom",
                Display_Subcategory = "",
                Instance_Count = 2,
                Sort_Order = 2,
                Shipper_Range = ""
            });

            var mockContext1 = new Mock<ProfileContext>();
            mockContext1.Setup(context => context.GetUserReportBySearch(0, 0, "UserReport")).ReturnsAsync(mockResponse);
            var reportRepository = new ReportRepository(mockContext1.Object, _mapper, new UserProfile());
            var response = await reportRepository.GetUserReportBySearch("UserReport");
            Assert.IsNotNull(response);
        }
    }
}



