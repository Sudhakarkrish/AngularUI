﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CassPort.Core.Models;
using CassPort.Data.Context;
using CassPort.Data.Entities;
using CassPort.Data.Repositories;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;

namespace CassPort.Data.Test
{
    public class ResetPasswordRepositoryTest
    {
        private ProfileContext mockContext;
        private UserProfile userProfile;
        protected IMapper _mapper;

        [SetUp]
        public void Setup()
        {
            if (_mapper == null)
            {
                Mapper.Reset();
                Mapper.Initialize(cfg =>
                {

                });
                _mapper = new Mapper(Mapper.Configuration);
            }

            FakeContext context = new FakeContext();
            mockContext = context.SetupMockContext();
        }

        [Test]
        public async Task GetUserPasswordHistoryTest()
        {
            try
            {
                var data = BindUserPassword();

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.GetPasswordHistory(0, null)).ReturnsAsync(data);

                var resetPasswordRepository = new ResetPasswordRepository(mockContext1.Object, _mapper, new UserProfile());
                var response = await resetPasswordRepository.GetUserPasswordHistory();

                Assert.IsNotNull(response);
                Assert.AreEqual(response.Count, 2);
            }
            catch (Exception ex)
            { throw; }
        }

        [Test]
        public async Task IsTokenConfirmedTest()
        {
            try
            {
                var data = new ResetPasswordHistory ();
                var data1 = new ResetPassword { LoginId = "1", Password = "test", ConfirmPassword = "test", CurrentPassword = "test" };

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.GetPasswordExpirationDate("0", "test","test")).ReturnsAsync(data);

                var resetPasswordRepository = new ResetPasswordRepository(mockContext1.Object, _mapper, new UserProfile());
                var response = await resetPasswordRepository.IsTokenConfirmed(data1);

                Assert.IsNotNull(response);
            }
            catch (Exception ex)
            { throw; }
        }

        private List<Core.Models.ChangePassword> BindUserPassword()
        {
            var changePasswordlist = new List<Core.Models.ChangePassword>();
            changePasswordlist.Add(new Core.Models.ChangePassword
            {
                USER_ACCOUNT_ID = 1,
                LOGIN_VERSION = 1
            });
            changePasswordlist.Add(new Core.Models.ChangePassword
            {
                USER_ACCOUNT_ID = 2,
                LOGIN_VERSION = 2
            });

            return changePasswordlist;
        }
    }
}

