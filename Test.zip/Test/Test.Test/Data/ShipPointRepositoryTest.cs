﻿using AutoMapper;
using CassPort.Core.Models;
using CassPort.Data.Context;
using CassPort.Data.Entities;
using CassPort.Data.Repositories;
using CassPort.Data.Test;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CassPort.Core.Test
{
    public class ShipPointRepositoryTest
    {
        private ProfileContext mockContext;
        protected IMapper _mapper;

        [SetUp]
        public void Setup()
        {
            if (_mapper == null)
            {
                Mapper.Reset();
                Mapper.Initialize(cfg =>
                {

                });
                _mapper = new Mapper(Mapper.Configuration);
            }

            FakeContext context = new FakeContext();
            mockContext = context.SetupMockContext();
        }

        [Test]
        public async Task GetUserShipPointsTest()
        {
            var mockResponse = new List<Core.Models.ShipPoint>();
            mockResponse.Add(new Models.ShipPoint
            {                
                Ship_Point_Code = "FORD",
                Company_Name = "Ford-US",
                Street_Address = "East Street",
                Zip_Code = "876w5r",
                City = "Missur",
                State = "Canada",
                Tdloc = "",
                Terminal_Code = "s",
                Active = true
            });
            mockResponse.Add(new Models.ShipPoint
            {
                Ship_Point_Code = "BMW",
                Company_Name = "BMW-US",
                Street_Address = "East Street",
                Zip_Code = "876w5r",
                City = "Missur",
                State = "Canada",
                Tdloc = "",
                Terminal_Code = "s",
                Active = true
            });

            var mockContext1 = new Mock<ProfileContext>();
            mockContext1.Setup(context => context.GetUserShipPoints(0, "Ford")).ReturnsAsync(mockResponse);
            var shipPointRepository = new ShipPointRepository(mockContext1.Object, _mapper, new UserProfile());
            var response = await shipPointRepository.GetUserShipPoints("Ford",0);
            Assert.IsNotNull(response);            
        }

         [Test]
        public async Task GetClientShipPointsTest()
        {
            var mockResponse = new List<Core.Models.ShipPoint>();
            mockResponse.Add(new Models.ShipPoint
            {
                Ship_Point_Code = "FORD",
                Company_Name = "Ford-US",
                Street_Address = "East Street",
                Zip_Code = "876w5r",
                City = "Missur",
                State = "Canada",
                Tdloc = "",
                Terminal_Code = "s",
                Active = true
            });
            mockResponse.Add(new Models.ShipPoint
            {
                Ship_Point_Code = "BMW",
                Company_Name = "BMW-US",
                Street_Address = "East Street",
                Zip_Code = "876w5r",
                City = "Missur",
                State = "Canada",
                Tdloc = "",
                Terminal_Code = "s",
                Active = true
            });

            var mockContext1 = new Mock<ProfileContext>();
            mockContext1.Setup(context => context.GetClientShipPoints("Car", "Ford")).ReturnsAsync(mockResponse);
            var shipPointRepository = new ShipPointRepository(mockContext1.Object, _mapper, new UserProfile());
            var response = await shipPointRepository.GetClientShipPoints("Car","Ford");
            Assert.IsNotNull(response);            
        }
    }
}


