﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CassPort.Core.Models;
using CassPort.Data.Context;
using CassPort.Data.Entities;
using CassPort.Data.Repositories;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;

namespace CassPort.Data.Test
{
    public class ShipperRepositoryTest
    {
        private ProfileContext mockContext;
        private UserProfile userProfile;
        protected IMapper _mapper;

        [SetUp]
        public void Setup()
        {
            if (_mapper == null)
            {
                Mapper.Reset();
                Mapper.Initialize(cfg =>
                {

                });
                _mapper = new Mapper(Mapper.Configuration);
            }

            FakeContext context = new FakeContext();
            mockContext = context.SetupMockContext();
        }

        [Test]
        public async Task GetShippersBySearchTest()
        {
            try
            {
                var shipperList = BindShippers();

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.GetShippersBySearch("Test", "S")).ReturnsAsync(shipperList);

                var shipperRepository = new ShipperRepository(mockContext1.Object, _mapper, new UserProfile());
                var response = await shipperRepository.GetShippersBySearch("Test");

                Assert.IsNotNull(response);
                Assert.AreEqual(response.Count, 2);
            }
            catch(Exception ex)
            { throw; }
        }

        [Test]
        public async Task GetUserShippersTest()
        {
            try
            {
                var shipperList = BindShippers();
                userProfile = new UserProfile();
                userProfile.UserId = 10291;

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.GetUserShippers(userProfile.UserId, false)).ReturnsAsync(shipperList);

                var shipperRepository = new ShipperRepository(mockContext1.Object, _mapper, userProfile);
                var response = await shipperRepository.GetUserShippers(false);

                Assert.IsNotNull(response);
                Assert.AreEqual(response.Count, 2);
            }
            catch (Exception ex)
            { throw; }
        }

        //[Test]
        public void UpdateUserShippersTest()
        {
            var data = BindShippers();
            var mockContext2 = new Mock<ProfileContext>();
            mockContext2.SetupGet(c => c.UserShipper).Returns(GetMockUpdateShipper().Object);
            var shipperRepository = new ShipperRepository(mockContext2.Object, _mapper, userProfile);
            var response = shipperRepository.UpdateUserShippers(data,1);
            Assert.IsNotNull(response);
        }


        private List<Core.Models.Shipper> BindShippers()
        {
            var shipperList = new List<Core.Models.Shipper>();
            shipperList.Add(new Core.Models.Shipper
            {
                Shipper_Code = "000001",
                Shipper_Name = "Test"
            });
            shipperList.Add(new Core.Models.Shipper
            {
                Shipper_Code = "000002",
                Shipper_Name = "Test 2"
            });

            return shipperList;
        }

        private static Mock<DbSet<CassPort.Data.Entities.UserShipper>> GetMockUpdateShipper()
        {
            IQueryable<CassPort.Data.Entities.UserShipper> userShipper = new List<CassPort.Data.Entities.UserShipper>
            {
               new CassPort.Data.Entities.UserShipper { ShipperCode="Test",UserAccountId=1 },
               new CassPort.Data.Entities.UserShipper { ShipperCode="Test1",UserAccountId= 2 }
            }.AsQueryable();

            return MockDbSetHelper.GetDbSet<CassPort.Data.Entities.UserShipper>(userShipper);
        }
    }
}
