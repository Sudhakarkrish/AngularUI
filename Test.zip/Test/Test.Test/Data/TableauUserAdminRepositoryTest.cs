﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CassPort.Core.Models;
using CassPort.Data.Context;
using CassPort.Data.Entities;
using CassPort.Data.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Moq;
using NUnit.Framework;

namespace CassPort.Data.Test
{
    public class TableauUserAdminRepositoryTest
    {
        private ProfileContext mockContext;
        protected IMapper _mapper;

        public TableauUserAdminRepositoryTest()
        {
        }

        [SetUp]
        public void Setup()
        {
            if (_mapper == null)
            {
                Mapper.Reset();
                Mapper.Initialize(cfg =>
                {
                });
                _mapper = new Mapper(Mapper.Configuration);
            }
            FakeContext context = new FakeContext();
            context.SetupMockContext();
        }

        [Test]
        public async Task GetCustomDashboardTest()
        {
            var tableauAdminList = BindCustomDashboard();

            var mockContext1 = new Mock<ProfileContext>();
            mockContext1.Setup(context => context.GetCustomDashboard("0", 0, 0, 1, 10, null, null)).ReturnsAsync(tableauAdminList);

            var tableauUserAdminRepository = new TableauUserAdminRepository(mockContext1.Object, _mapper, new UserProfile());
            var response = await tableauUserAdminRepository.GetCustomDashboard("0", 0, 0, 1, 10, null, null);

            Assert.IsNotNull(response);
            Assert.AreEqual(2, response.Count);
        }

        [Test]
        public async Task GetSearchUserTest()
        {
            var userList = BindSearchUserData();

            var mockContext1 = new Mock<ProfileContext>();
            mockContext1.Setup(context => context.GetSearchUser("Test", "Test", "Test", "Test", null, 4, 1, 10, null, null)).ReturnsAsync(userList);

            var tableauUserAdminRepository = new TableauUserAdminRepository(mockContext1.Object, _mapper, new UserProfile());
            var response = await tableauUserAdminRepository.GetSearchUser("Test", "Test", "Test", "Test", 1, 10, null, null);

            Assert.IsNotNull(response);
            Assert.AreEqual(2, response.Count);
        }

        [Test]
        public async Task GetManageDashboardByUsersTest()
        {
            var tableauAdminList = BindCustomDashboard();

            var mockContext1 = new Mock<ProfileContext>();
            mockContext1.Setup(context => context.GetManageDashboardByUsers("0", 0, 0, 1, 10, null, null)).ReturnsAsync(tableauAdminList);

            var tableauUserAdminRepository = new TableauUserAdminRepository(mockContext1.Object, _mapper, new UserProfile());
            var response = await tableauUserAdminRepository.GetManageDashboardByUsers("0", 0, 0, 1, 10, null, null);

            Assert.IsNotNull(response);
            Assert.AreEqual(2, response.Count);
        }

        [Test]
        public async Task GetUserDetailsForDashboardTest()
        {
            var UserDetailsList = BindUserDetailsForDashboard();

            var mockContext1 = new Mock<ProfileContext>();
            mockContext1.Setup(context => context.GetUserDetailsForDashboard(1)).ReturnsAsync(UserDetailsList);

            var tableauUserAdminRepository = new TableauUserAdminRepository(mockContext1.Object, _mapper, new UserProfile());
            var response = await tableauUserAdminRepository.GetUserDetailsForDashboard(1);

            Assert.IsNotNull(response);
            Assert.AreEqual(2, response.Count);
        }

        //[Test]
        public void RemoveAssignedUserTest()
        {
            var mockContext1 = new Mock<ProfileContext>();
            mockContext1.Setup(context => context.RemoveAssignedUser(1)).Returns(1);

            var tableauUserAdminRepository = new TableauUserAdminRepository(mockContext1.Object, _mapper, new UserProfile());
            var response = tableauUserAdminRepository.RemoveAssignedUser(1, 1);

            Assert.IsNotNull(response);
        }

        //[Test]
        public void InsertSelectedUserToDashboardTest()
        {
            var data1 = new InsertDashboardUsers
            {
                UserAccountId = 1,
                DashboardId = 1,

            };
            var data = BindInsertUserData();
            var mockContext1 = new Mock<ProfileContext>();
            mockContext1.Setup(context => context.InsertSelectedUserToDashboard(data1)).Returns(1);

            var tableauUserAdminRepository = new TableauUserAdminRepository(mockContext1.Object, _mapper, new UserProfile());
            var response = tableauUserAdminRepository.InsertSelectedUserToDashboard(data);
            Assert.IsNotNull(response);
        }

        [Test]
        public void CreateDashboardTest()
        {
            var data1 = new CreateDashboard
            {
                DashboardCategory = 1,
                DashboardCategoryName = "parcel",
                DashboardName ="Test",
                DashboardType = 1,
                IsPremiumDashboard = true,
                IsAssignAlluser = true,
                IsDeleted = false,
                DashboardUrl="Test",
                IsInternal = true,
                DashboardDisplayName ="Test",
                DashboardId = 1

            };
            var mockContext1 = new Mock<ProfileContext>();
            mockContext1.Setup(context => context.CreateDashboard(data1)).Returns(1);

            var tableauUserAdminRepository = new TableauUserAdminRepository(mockContext1.Object, _mapper, new UserProfile());
            var response = tableauUserAdminRepository.CreateDashboard(data1);
            Assert.IsNotNull(response);
        }
       
        private List<Core.Models.TableauUserAdmin> BindCustomDashboard()
        {
            var tableauAdminList = new List<Core.Models.TableauUserAdmin>
            {
                new Core.Models.TableauUserAdmin
                {
                    Dashboard_Name = "Dashboard200",
                    Dashboard_Display_Name = "Dashboard200",
                    Dashboard_URL = "Dashboard200",
                    Dashboard_Type = 1,
                    Dashboard_Category = 1,
                    Is_Premium_Dashboard = true,
                    Is_Deleted = false,
                    Is_Assign_Alluser = true,
                    Is_Internal = true
                },
                new Core.Models.TableauUserAdmin
                {
                    Dashboard_Name = "Dashboard201",
                    Dashboard_Display_Name = "Dashboard201",
                    Dashboard_URL = "Dashboard201",
                    Dashboard_Type = 1,
                    Dashboard_Category = 1,
                    Is_Premium_Dashboard = true,
                    Is_Deleted = false,
                    Is_Assign_Alluser = true,
                    Is_Internal = true
                }
            };

            return tableauAdminList;
        }

        private List<Core.Models.DashboardUserDetail> BindUserDetailsForDashboard()
        {
            var UserDetailsList = new List<Core.Models.DashboardUserDetail>
            {
                new Core.Models.DashboardUserDetail
                {
                    Name = "test",
                    Email = "test@test.com",
                    IsAssigned = true,
                    UserAccountId = 1
                },
                new Core.Models.DashboardUserDetail
                {
                    Name = "test1",
                    Email = "test1@test1.com",
                    IsAssigned = false,
                    UserAccountId = 2
                }
            };

            return UserDetailsList;
        }

        private List<Core.Models.TableauUserAccount> BindSearchUserData()
        {
            var userList = new List<Core.Models.TableauUserAccount>
            {
                new Core.Models.TableauUserAccount
                {
                    LOGIN_NAME = "Test",
                    COMPANY_NAME = "Test",
                    COMPANY_TYPE = "Test",
                    SERVICE_LOCATION = "stl",
                    EMAIL = "test@test.com",
                    LOGIN_LEVEL = 1,
                    Name = "test",
                    USER_ACCOUNT_ID = 1,
                    TotalCount = 10,
                },
                new Core.Models.TableauUserAccount
                {
                    LOGIN_NAME = "Test1",
                    COMPANY_NAME = "Test1",
                    COMPANY_TYPE = "Test1",
                    SERVICE_LOCATION = "stl",
                    EMAIL = "test1@test.com",
                    LOGIN_LEVEL = 2,
                    Name = "test1",
                    USER_ACCOUNT_ID = 2,
                    TotalCount = 10,
                }
            };

            return userList;
        }

        private List<Core.Models.InsertDashboardUsers> BindInsertUserData()
        {
            var userList = new List<Core.Models.InsertDashboardUsers>
            {
                new Core.Models.InsertDashboardUsers
                {
                    UserAccountId = 1,
                    DashboardId = 1,
                   
                },
            };
            return userList;
        }

        [Test]
        public async Task GetDashboardCategoryTest()
        {
            var mockContext2 = new Mock<ProfileContext>();
            mockContext2.SetupGet(c => c.DashboardCategory).Returns(GetMockDashboardCategory().Object);

            var tableauUserAdminRepository = new TableauUserAdminRepository(mockContext2.Object, _mapper, new UserProfile());
            var response = await tableauUserAdminRepository.GetDashboardCategory();

            Assert.IsNotNull(response);
            Assert.AreEqual(2, response.Count);
        }

        [Test]
        public async Task GetDashboardTypeTest()
        {
            var mockContext2 = new Mock<ProfileContext>();
            mockContext2.SetupGet(c => c.DashboardType).Returns(GetMockDashboardType().Object);

            var tableauUserAdminRepository = new TableauUserAdminRepository(mockContext2.Object, _mapper, new UserProfile());
            var response = await tableauUserAdminRepository.GetDashboardType();

            Assert.IsNotNull(response);
            Assert.AreEqual(2, response.Count);
        }

        private static Mock<DbSet<DashboardCategory>> GetMockDashboardCategory()
        {
            IQueryable<DashboardCategory> dashboardCategories = new List<DashboardCategory>
            {
               new DashboardCategory { CategoryId = 1, CategoryName = "Test" },
               new DashboardCategory { CategoryId = 2, CategoryName = "Test1" }
            }.AsQueryable();

            return MockDbSetHelper.GetDbSet<DashboardCategory>(dashboardCategories);
        }

        private static Mock<DbSet<CassPort.Data.Entities.DashboardType>> GetMockDashboardType()
        {
            IQueryable<CassPort.Data.Entities.DashboardType> dashboardType = new List<CassPort.Data.Entities.DashboardType>
            {
               new CassPort.Data.Entities.DashboardType {DashboardTypeId = 1, DashboardTypeName = "Test" },
               new CassPort.Data.Entities.DashboardType { DashboardTypeId = 2, DashboardTypeName = "Test1" }
            }.AsQueryable();

            return MockDbSetHelper.GetDbSet<CassPort.Data.Entities.DashboardType>(dashboardType);
        }
    }
}