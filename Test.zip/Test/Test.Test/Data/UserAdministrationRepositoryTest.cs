﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using CassPort.Core.Models;
using CassPort.Data.Context;
using CassPort.Data.Repositories;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;

namespace CassPort.Data.Test
{
    public class UserAdministrationRepositoryTest
    {
        private ProfileContext mockContext;
        private UserProfile userProfile;
        protected IMapper _mapper;

        [SetUp]
        public void Setup()
        {
            if (_mapper == null)
            {
                Mapper.Reset();
                Mapper.Initialize(cfg =>
                {

                });
                _mapper = new Mapper(Mapper.Configuration);
            }

            FakeContext context = new FakeContext();
            mockContext = context.SetupMockContext();
        }

        [Test]
        public async Task GetExternalAuthenticatorsTest()
        {
            try
            {
                userProfile = new UserProfile();
                userProfile.UserId = 10291;

                var externalList = new List<ExternalAuthenticator>();
                externalList.Add(new ExternalAuthenticator
                {
                    External_Authentication_Id = 101,
                    Company_Name = "Test external"
                });
                externalList.Add(new ExternalAuthenticator
                {
                    External_Authentication_Id = 102,
                    Company_Name = "Test external 2"
                });

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.GetExternalAuthenticators()).ReturnsAsync(externalList);

                var userAdminRepository = new UserAdministrationRepository(mockContext1.Object, _mapper, userProfile);
                var response = await userAdminRepository.GetExternalAuthenticators();

                Assert.IsNotNull(response);
                Assert.AreEqual(response.Count, 2);
            }
            catch (Exception ex)
            { throw; }
        }

        [Test]
        public async Task GetExternalAuthenticationProviderMappingsTest()
        {
            try
            {
                userProfile = new UserProfile();
                userProfile.UserId = 10291;

                var externalProviderMapping = new List<ExternalProviderMapping>();
                externalProviderMapping.Add(new ExternalProviderMapping
                {
                    ExternalField = "External 1",
                    InternalField = "Internal 1",
                    UserValue = "01"                    
                });
                externalProviderMapping.Add(new ExternalProviderMapping
                {
                    ExternalField = "External 2",
                    InternalField = "Internal 2",
                    UserValue = "02"
                });

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.GetExternalAuthenticationProviderMappings(101)).ReturnsAsync(externalProviderMapping);

                var userAdminRepository = new UserAdministrationRepository(mockContext1.Object, _mapper, userProfile);
                var response = await userAdminRepository.GetExternalAuthenticationProviderMappings(101);

                Assert.IsNotNull(response);
                Assert.AreEqual(response.Count, 2);
            }
            catch (Exception ex)
            { throw; }
        }

        [Test]
        public async Task ListUsersTest()
        {
            try
            {
                userProfile = new UserProfile();
                userProfile.UserId = 10291;

                var userAdministrationCount = new UserAdministrationCount
                    {
                        TotalCount = 1
                    };

                var UserAdministrationList = new List<UserAdministration>();
                UserAdministrationList.Add(new UserAdministration
                {
                    USER_ACCOUNT_ID = 1111,
                    Name = "Cass Internal Test",
                    COMPANY_NAME = "Company Test",
                    COMPANY_TYPE = "Type Test",
                    EMAIL = "aaa@test.com",
                    PHONE = "555-555-5555",                    
                    LOGIN_NAME = "logintest",
                    LOGIN_LEVEL = 1                    
                });


                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.ListUsers("S", "T", "0", "-1", "3", "0", "0", "2", 1, 10, null, null)).ReturnsAsync(UserAdministrationList);
                mockContext1.Setup(context => context.ListUsersCount("S", "T", "0", "-1", "3", "0", "0", "2")).ReturnsAsync(userAdministrationCount);

                var userAdminRepository = new UserAdministrationRepository(mockContext1.Object, _mapper, userProfile);
                var response = await userAdminRepository.ListUsers("S", "T", "0", "-1", "3", "0", "0", "2", 1, 10, null, null);

                Assert.IsNotNull(response);
                Assert.IsNotNull(response.UserAdministrationList);
                Assert.AreEqual(response.UserAdministrationList.Count, 1);
            }
            catch (Exception ex)
            { throw; }
        }

        [Test]
        public async Task AllListUsersTest()
        {
            try
            {
                userProfile = new UserProfile();
                userProfile.UserId = 10291;

                var userAdministrationCount = new UserAdministrationCount
                {
                    TotalCount = 2
                };

                var UserAdministrationList = new List<UserAdministration>();
                UserAdministrationList.Add(new UserAdministration
                {
                    USER_ACCOUNT_ID = 1111,
                    Name = "Cass Internal Test",
                    COMPANY_NAME = "Company Test",
                    COMPANY_TYPE = "Type Test",
                    EMAIL = "aaa@test.com",
                    PHONE = "555-555-5555",
                    LOGIN_NAME = "logintest",
                    LOGIN_LEVEL = 1
                });

                UserAdministrationList.Add(new UserAdministration
                {
                    USER_ACCOUNT_ID = 2222,
                    Name = "Cass Internal Test 2",
                    COMPANY_NAME = "Company Test 2",
                    COMPANY_TYPE = "Type Test 2",
                    EMAIL = "bbb@test.com",
                    PHONE = "555-555-5555",
                    LOGIN_NAME = "logintest2",
                    LOGIN_LEVEL = 1
                });


                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.ListAllUsers("0", "2", 1, 10, null, null)).ReturnsAsync(UserAdministrationList);
                mockContext1.Setup(context => context.ListAllUsersCount("0", "2")).ReturnsAsync(userAdministrationCount);

                var userAdminRepository = new UserAdministrationRepository(mockContext1.Object, _mapper, userProfile);
                var response = await userAdminRepository.AllListUsers("0", "2", 1, 10, null, null);

                Assert.IsNotNull(response);
                Assert.IsNotNull(response.UserAdministrationList);
                Assert.AreEqual(response.UserAdministrationList.Count, 2);
            }
            catch (Exception ex)
            { throw; }
        }

        [Test]
        public async Task VerifyUserIsLockedByEditingUserTest()
        {
            try
            {
                userProfile = new UserProfile();
                userProfile.UserId = 10291;

                var lockCount = new UserIsLockedByEditingUserCount();
                lockCount.LOCK_COUNT = 1;

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.VerifyUserIsLockedByEditingUser(userProfile.UserId, 102)).ReturnsAsync(lockCount);

                var userAdminRepository = new UserAdministrationRepository(mockContext1.Object, _mapper, userProfile);
                var response = await userAdminRepository.VerifyUserIsLockedByEditingUser(userProfile.UserId, 102);

                Assert.IsNotNull(response);
                Assert.AreEqual(response.LOCK_COUNT, 1);
            }
            catch (Exception ex)
            { throw; }
        }

        [Test]
        public void VerifyAdminCanEditUserTest()
        {
            try
            {
                userProfile = new UserProfile();
                userProfile.UserId = 1001;

                var accountID = new Core.Models.AccountID();
                accountID.USER_ACCOUNT_ID = 1001;

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.VerifyAdminCanEditUser(userProfile.UserId, 102)).Returns(accountID);

                var userAdminRepository = new UserAdministrationRepository(mockContext1.Object, _mapper, userProfile);
                var response = userAdminRepository.VerifyAdminCanEditUser(userProfile.UserId, 102);

                Assert.IsNotNull(response);
                Assert.AreEqual(response, true);
            }
            catch (Exception ex)
            { throw; }
        }

        [Test]
        public async Task GetUserStagingCarriersTest()
        {
            try
            {
                var data = BindCarriers();

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.GetUserCarriers(0, false)).ReturnsAsync(data);

                var userAdminRepository = new UserAdministrationRepository(mockContext1.Object, _mapper, userProfile);
                var response = userAdminRepository.GetUserStagingCarriers(0, false);

                Assert.IsNotNull(response);
            }
            catch (Exception ex)
            { throw; }
        }

        [Test]
        public async Task GetUserCarriersTest()
        {
            try
            {
                var data = BindCarriers();

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.GetUserCarriers(0, false)).ReturnsAsync(data);

                var userAdminRepository = new UserAdministrationRepository(mockContext1.Object, _mapper, userProfile);
                var response = userAdminRepository.GetUserCarriers(0, false);

                Assert.IsNotNull(response);
            }
            catch (Exception ex)
            { throw; }
        }

        [Test]
        public async Task GetUserStagingShippersTest()
        {
            try
            {
                var data = BindShippers();

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.GetUserShippers(0, false)).ReturnsAsync(data);

                var userAdminRepository = new UserAdministrationRepository(mockContext1.Object, _mapper, userProfile);
                var response = userAdminRepository.GetUserStagingShippers(0, false);

                Assert.IsNotNull(response);
            }
            catch (Exception ex)
            { throw; }
        }

        [Test]
        public async Task GetUserShippersTest()
        {
            try
            {
                var data = BindShippers();

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.GetUserShippers(0, false)).ReturnsAsync(data);

                var userAdminRepository = new UserAdministrationRepository(mockContext1.Object, _mapper, userProfile);
                var response = userAdminRepository.GetUserShippers(0, false);

                Assert.IsNotNull(response);
            }
            catch (Exception ex)
            { throw; }
        }

        [Test]
        public async Task GetUserPrivilegesTest()
        {
            try
            {
                var data = new List<Core.Models.UserPriviledge>();

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.GetAllUserPreviledge(0)).ReturnsAsync(data);

                var userAdminRepository = new UserAdministrationRepository(mockContext1.Object, _mapper, userProfile);
                var response = userAdminRepository.GetUserPrivileges(0);

                Assert.IsNotNull(response);
            }
            catch (Exception ex)
            { throw; }
        }

        [Test]
        public async Task GetUserShipPointsTest()
        {
            try
            {
                var data = new List<Core.Models.ShipPoint>();

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.GetUserShipPoints(0,"test")).ReturnsAsync(data);

                var userAdminRepository = new UserAdministrationRepository(mockContext1.Object, _mapper, userProfile);
                var response = userAdminRepository.GetUserShipPoints(0,"test");

                Assert.IsNotNull(response);
            }
            catch (Exception ex)
            { throw; }
        }

        [Test]
        public async Task GetUserPrivilegesLimitedTest()
        {
            try
            {
                var data = new List<Core.Models.UserPriviledge>();

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.GetUserPrivilledge(0,false, "test")).ReturnsAsync(data);

                var userAdminRepository = new UserAdministrationRepository(mockContext1.Object, _mapper, userProfile);
                var response = userAdminRepository.GetUserPrivilegesLimited(0, false, "test");

                Assert.IsNotNull(response);
            }
            catch (Exception ex)
            { throw; }
        }

        [Test]
        public async Task GetUserPrivilegeGroupsTest()
        {
            try
            {
                var data = new List<Core.Models.PrivilegeGroupList>();

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.GetUserPrivilegeGroups(0,false, "test")).ReturnsAsync(data);

                var userAdminRepository = new UserAdministrationRepository(mockContext1.Object, _mapper, userProfile);
                var response = userAdminRepository.GetUserPrivilegeGroups(0,false, "test");

                Assert.IsNotNull(response);
            }
            catch (Exception ex)
            { throw; }
        }

        [Test]
        public async Task IsExternalEmailAvailableTest()
        {
            try
            {
                var data = new ISEmailAvailable();

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.IsExternalEmailAvailable(0, "test", 1)).Returns(data);

                var userAdminRepository = new UserAdministrationRepository(mockContext1.Object, _mapper, userProfile);
                var response = userAdminRepository.IsExternalEmailAvailable(0, "test", 1);

                Assert.IsNotNull(response);
            }
            catch (Exception ex)
            { throw; }
        }

        [Test]
        public async Task GetLetterTextTest()
        {
            try
            {
                var data = new Letter { LETTER_TEXT="test"};

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.GetLetterText("test")).Returns(data);

                var userAdminRepository = new UserAdministrationRepository(mockContext1.Object, _mapper, userProfile);
                var response = userAdminRepository.GetLetterText("test");

                Assert.IsNotNull(response);
            }
            catch (Exception ex)
            { throw; }
        }

        [Test]
        public async Task VerifyUserInADTest()
        {
            try
            {
                var data = new ActiveDirectory { NT_USER_NAME = "test" };

                var mockContext1 = new Mock<ProfileContext>();
                mockContext1.Setup(context => context.VerifyUserInAD("test")).Returns(data);

                var userAdminRepository = new UserAdministrationRepository(mockContext1.Object, _mapper, userProfile);
                var response = userAdminRepository.VerifyUserInAD("test");

                Assert.IsNotNull(response);
            }
            catch (Exception ex)
            { throw; }
        }

        private List<Core.Models.Carrier> BindCarriers()
        {
            var carrierList = new List<Core.Models.Carrier>();
            carrierList.Add(new Core.Models.Carrier
            {
                Carrier_Code = "000001",
                Carrier_Name = "Test"
            });
            carrierList.Add(new Core.Models.Carrier
            {
                Carrier_Code = "000002",
                Carrier_Name = "Test 2"
            });

            return carrierList;
        }

        private List<Core.Models.Shipper> BindShippers()
        {
            var shipperList = new List<Core.Models.Shipper>();
            shipperList.Add(new Core.Models.Shipper
            {
                Shipper_Code = "000001",
                Shipper_Name = "Test"
            });
            shipperList.Add(new Core.Models.Shipper
            {
                Shipper_Code = "000002",
                Shipper_Name = "Test 2"
            });

            return shipperList;
        }

        //[Test]
        //public async Task GetUserAccountStagingTest()
        //{
        //    try
        //    {
        //        userProfile = new UserProfile();
        //        userProfile.UserId = 10291;                

        //        var userAccountStaging = new UserAccountStaging
        //        {
        //            FirstName = "Test Name",
        //            LastName = "LastName Test",
        //            CompanyName = "CompanyName Test",
        //            CompanyType = "CompanyType; Test",
        //            Department = "Department",
        //            Address1 = "Address1 Test",
        //            City = "City Test",
        //            State = "State Test",
        //            Country = "India",
        //            UserAccountStagingId = userProfile.UserId
        //        };

        //        //var mockContext1 = new Mock<ProfileContext>();               
        //        //mockContext.UserAccountStaging = 

        //        var userAdminRepository = new UserAdministrationRepository(mockContext, _mapper, userProfile);
        //        var response = await userAdminRepository.GetUserAccountStaging(userProfile.UserId);

        //        Assert.IsNotNull(response);
        //    }
        //    catch (Exception ex)
        //    { throw; }
        //}
    }
}
