﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CassPort.Core.Models;
using CassPort.Data.Context;
using CassPort.Data.Entities;
using CassPort.Data.Repositories;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;

namespace CassPort.Data.Test
{
    public class UserClaimRepositoryTest
    {
        private ProfileContext mockContext;
        private UserProfile userProfile;
        protected IMapper _mapper;

        [SetUp]
        public void Setup()
        {
            if (_mapper == null)
            {
                Mapper.Reset();
                Mapper.Initialize(cfg =>
                {

                });
                _mapper = new Mapper(Mapper.Configuration);
            }

            FakeContext context = new FakeContext();
            mockContext = context.SetupMockContext();
        }

        //[Test]
        public async Task GetUserProfileTest()
        {
            try
            {
                var mockContext2 = new Mock<ProfileContext>();
                mockContext2.SetupGet(c => c.UserAccount).Returns(GetMockUserProfile().Object);

                var userClaimsRepository = new UserClaimsRepository(mockContext2.Object, _mapper, new UserProfile());
                var response = await userClaimsRepository.GetUserProfile(1);

                Assert.IsNotNull(response);
            }
            catch (Exception ex)
            { throw; }
        }

        private static Mock<DbSet<CassPort.Data.Entities.UserAccount>> GetMockUserProfile()
        {
            IQueryable<CassPort.Data.Entities.UserAccount> userCarrier = new List<CassPort.Data.Entities.UserAccount>
            {
               new CassPort.Data.Entities.UserAccount {UserAccountId=1,AccountAuthorized=true,AccountEnabled=true,LoginName="test",FirstName="test",LastName="test",Email="test",LoginLevel=1,CompanyType="s" },
            }.AsQueryable();

            return MockDbSetHelper.GetDbSet<CassPort.Data.Entities.UserAccount>(userCarrier);
        }
    }
}
