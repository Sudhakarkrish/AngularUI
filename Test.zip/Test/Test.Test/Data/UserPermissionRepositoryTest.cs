﻿using AutoMapper;
using CassPort.Core.Models;
using CassPort.Data.Context;
using CassPort.Data.Repositories;
using CassPort.Data.Test;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CassPort.Core.Test
{
    public class UserPermissionRepositoryTest
    {
        private ProfileContext mockContext;
        protected IMapper _mapper;

        [SetUp]
        public void Setup()
        {
            if (_mapper == null)
            {
                Mapper.Reset();
                Mapper.Initialize(cfg =>
                {

                });
                _mapper = new Mapper(Mapper.Configuration);
            }

            FakeContext context = new FakeContext();
            mockContext = context.SetupMockContext();
        }

        //[Test]
        public async Task GetUserPermissionsTest()
        {
            var mockResponse = new List<Core.Models.UserPriviledge>();
            mockResponse.Add(new Models.UserPriviledge
            {
                Priviledge_Id = 100,
                Priviledge_Name = "ServiceTest",
                Priviledge_Sub_Group_Id = 100,
                Priviledge_Sub_Group_Name = "Group",
                Sort_Order = 3,
                Priviledge_Group_Id = 12,
                Active = true,
                Priviledge_External = true,
                Company_Type = "C"
            });
            mockResponse.Add(new Models.UserPriviledge
            {
                Priviledge_Id = 101,
                Priviledge_Name = "ServiceTest1",
                Priviledge_Sub_Group_Id = 11,
                Priviledge_Sub_Group_Name = "Group",
                Sort_Order = 32,
                Priviledge_Group_Id = 12,
                Active = true,
                Priviledge_External = true,
                Company_Type = "C"
            });

            var mockContext1 = new Mock<ProfileContext>();
            mockContext1.Setup(context => context.GetUserPrivilledge(0, true, "Shipper")).ReturnsAsync(mockResponse);
            var userPermissionRepository = new UserPermissionRepository(mockContext1.Object, _mapper, new UserProfile());
            var response = await userPermissionRepository.GetUserPermissions(true, "Shipper");
            Assert.IsNotNull(response);
        }

        [Test]
        public async Task GetUserPrivilegeGroupsTest()
        {
            var mockResponse = new List<Core.Models.PrivilegeGroupList>();
            mockResponse.Add(new Models.PrivilegeGroupList
            {
                Priviledge_Group_Id = 100,
                Priviledge_Group_Name = "ServiceTest"
            });
            mockResponse.Add(new Models.PrivilegeGroupList
            {
                Priviledge_Group_Id = 100,
                Priviledge_Group_Name = "ServiceTest"
            });

            var mockContext1 = new Mock<ProfileContext>();
            mockContext1.Setup(context => context.GetUserPrivilegeGroups(0, true, "Shipper")).ReturnsAsync(mockResponse);
            var userPermissionRepository = new UserPermissionRepository(mockContext1.Object, _mapper, new UserProfile());
            var response = await userPermissionRepository.GetUserPrivilegeGroups(true, "Shipper");
            Assert.IsNotNull(response);
        }

        [Test]
        public async Task GetUserPermissionsByGroupTest()
        {
            var mockResponse = new List<Core.Models.UserPriviledge>();
            mockResponse.Add(new Models.UserPriviledge
            {
                Priviledge_Id = 100,
                Priviledge_Name = "ServiceTest",
                Priviledge_Sub_Group_Id = 100,
                Priviledge_Sub_Group_Name = "Group",
                Sort_Order = 3,
                Priviledge_Group_Id = 12,
                Active = true,
                Priviledge_External = true,
                Company_Type = "C"
            });
            mockResponse.Add(new Models.UserPriviledge
            {
                Priviledge_Id = 100,
                Priviledge_Name = "ServiceTest",
                Priviledge_Sub_Group_Id = 100,
                Priviledge_Sub_Group_Name = "Group",
                Sort_Order = 3,
                Priviledge_Group_Id = 12,
                Active = true,
                Priviledge_External = true,
                Company_Type = "C"
            });

            var mockContext1 = new Mock<ProfileContext>();
            mockContext1.Setup(context => context.GetUserPrivilledgeByGroup(0, true, "S", "1", string.Empty)).ReturnsAsync(mockResponse);
            var userPermissionRepository = new UserPermissionRepository(mockContext1.Object, _mapper, new UserProfile());
            var response = await userPermissionRepository.GetUserPermissionsByGroup(true, "S", "1", string.Empty);
            Assert.IsNotNull(response);
        }
    }
}

