﻿using AutoMapper;
using CassPort.Core.Models;
using CassPort.Data.Context;
using CassPort.Data.Repositories;
using CassPort.Data.Test;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CassPort.Core.Test
{
    public class UserProfileRepositoryTest
    {
        private ProfileContext mockContext;
        protected IMapper _mapper;

        [SetUp]
        public void Setup()
        {
            if (_mapper == null)
            {
                Mapper.Reset();
                Mapper.Initialize(cfg =>
                {

                });
                _mapper = new Mapper(Mapper.Configuration);
            }

            FakeContext context = new FakeContext();
            mockContext = context.SetupMockContext();
        }

        [Test]
        public async Task GetCountriesTest()
        {
            var mockResponse = new List<Core.Models.Country>();
            mockResponse.Add(new Models.Country
            {
                Country_Code = "IN",
                Country_Name = "India"
            });

            var mockContext1 = new Mock<ProfileContext>();
            mockContext1.Setup(context => context.GetCountries()).ReturnsAsync(mockResponse);
            var userProfileRepository = new UserProfileRepository(mockContext1.Object, _mapper, new UserProfile());
            var response = await userProfileRepository.GetCountries();
            Assert.IsNotNull(response);
        }

        [Test]
        public async Task GetStatesTest()
        {
            var mockResponse = new List<Core.Models.State>();
            mockResponse.Add(new Models.State
            {
                Country_Code = "IN",
                Region_Code = "CH",
                Region_Name = "Chennai"
            });
            mockResponse.Add(new Models.State
            {
                Country_Code = "US",
                Region_Code = "MX",
                Region_Name = "Mexico"
            });
            mockResponse.Add(new Models.State
            {
                Country_Code = "US",
                Region_Code = "CN",
                Region_Name = "Canada"
            });

            var mockContext1 = new Mock<ProfileContext>();
            mockContext1.Setup(context => context.GetStates("US")).ReturnsAsync(mockResponse);
            var userProfileRepository = new UserProfileRepository(mockContext1.Object, _mapper, new UserProfile());
            var response = await userProfileRepository.GetStates("US");
            Assert.IsNotNull(response);
        }

        [Test]
        public async Task GetUserAccountTest()
        {
            var mockResponse = new Core.Models.EditProfile();
            mockResponse.FIRST_NAME = "Mj";
            mockResponse.LAST_NAME = "Mj";

            var mockContext1 = new Mock<ProfileContext>();
            mockContext1.Setup(context => context.GetUserAccount(9201)).ReturnsAsync(mockResponse);
            var userProfileRepository = new UserProfileRepository(mockContext1.Object, _mapper, new UserProfile());
            var response = await userProfileRepository.GetUserAccount(9201);
            Assert.IsNotNull(response);
        }

        //[Test]
        public void RegisterUserProfileTest()
        {
            var registerViewModel = new Core.Models.RegisterViewModel();
            registerViewModel.FirstName = "Mj";
            registerViewModel.MiddleInitial = "";
            registerViewModel.LastName = "Mj";
            registerViewModel.CompanyName = "";
            registerViewModel.CompanyType = "S";
            registerViewModel.Department = "";
            registerViewModel.JobTitle = "";
            registerViewModel.Address1 = "West street";
            registerViewModel.Address2 = "";
            registerViewModel.City = "Chennai";
            registerViewModel.State = "TN";
            registerViewModel.Zipcode = "600000";
            registerViewModel.Country = "IN";
            registerViewModel.Phone = "999-999-9999";
            registerViewModel.Fax = "";
            registerViewModel.Email = "mj@cassinfo.com";
            registerViewModel.ServiceLocation = "";

            var userProfileRepository = new UserProfileRepository(mockContext, _mapper, new UserProfile());
            var response = userProfileRepository.RegisterUserProfile(registerViewModel);
            Assert.IsNotNull(response);
        }

        //[Test]
        public void UpdateUserProfileTest()
        {
            var editProfile = new Core.Models.EditProfile();
            editProfile.FIRST_NAME = "Mj";
            editProfile.MIDDLE_INITIAL = "";
            editProfile.LAST_NAME = "Mj";
            editProfile.COMPANY_NAME = "";
            editProfile.COMPANY_TYPE = "S";
            editProfile.DEPARTMENT = "";
            editProfile.JOB_TITLE = "";
            editProfile.ADDRESS_1 = "West street";
            editProfile.ADDRESS_2 = "";
            editProfile.CITY = "Chennai";
            editProfile.STATE = "TN";
            editProfile.ZIPCODE = "600000";
            editProfile.COUNTRY = "IN";
            editProfile.PHONE = "999-999-9999";
            editProfile.FAX = "";
            editProfile.EMAIL = "mj@cassinfo.com";
            editProfile.SERVICE_LOCATION = "";
            editProfile.DISABLE_CUSTOM_EMAIL = true;
            editProfile.USER_ACCOUNT_ID = 1;

            var userProfileRepository = new UserProfileRepository(mockContext, _mapper, new UserProfile());
            var response = userProfileRepository.UpdateUserProfile(editProfile);
            Assert.IsNotNull(response);
        }

        [Test]
        public async Task GetTableauUserAccountTest()
        {
            var mockContext2 = new Mock<ProfileContext>();
            mockContext2.SetupGet(c => c.TableauUserAccount).Returns(GetMockTableauUserAccount().Object);

            var userProfileRepository = new UserProfileRepository(mockContext2.Object, _mapper, new UserProfile());
            var response = await userProfileRepository.GetTableauUserAccount(9201);

            Assert.IsNotNull(response);
        }

        private static Mock<DbSet<CassPort.Data.Entities.TableauUserAccount>> GetMockTableauUserAccount()
        {
            IQueryable<CassPort.Data.Entities.TableauUserAccount> tableauUserAccount = new List<CassPort.Data.Entities.TableauUserAccount>
            {
               new CassPort.Data.Entities.TableauUserAccount { TableauUserName="Test" },
               new CassPort.Data.Entities.TableauUserAccount { TableauUserName="Test1" }
            }.AsQueryable();

            return MockDbSetHelper.GetDbSet<CassPort.Data.Entities.TableauUserAccount>(tableauUserAccount);
        }
    }
}
