﻿namespace CassPort.WebApi.Test
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CassPort.Core.Models;
    using CassPort.Core.Services.Interfaces;
    using CassPort.WebApi.V1.Controllers;
    using Moq;
    using NUnit.Framework;

    public class CarrierControllerTest
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public async Task GetCarriersBySearchTest()
        {
            var mockCarrier = new List<Carrier>();
            var carrierService = new Mock<ICarrierService>();

            carrierService.Setup(context => context.GetCarriersBySearch("searchText")).ReturnsAsync(mockCarrier);
            var carrierController = new CarrierController(carrierService.Object);

            var response = await carrierController.GetCarriersBySearch("searchText");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUserCarriersTest()
        {
            var mockCarrier = new List<Carrier>();
            var carrierService = new Mock<ICarrierService>();

            carrierService.Setup(context => context.GetUserCarriers(false)).ReturnsAsync(mockCarrier);
            var carrierController = new CarrierController(carrierService.Object);

            var response = await carrierController.GetUserCarriers(false);
            Assert.NotNull(response);
        }

        [Test]
        public async Task PostTest()
        {
            var mockCarrier = new List<Carrier>();
            var carrierService = new Mock<ICarrierService>();

            carrierService.Setup(context => context.UpdateUserCarriers(mockCarrier, 22)).Returns(2);
            var carrierController = new CarrierController(carrierService.Object);

            var response = carrierController.Post(mockCarrier, 22);
            Assert.NotNull(response);
        }
    }
}
