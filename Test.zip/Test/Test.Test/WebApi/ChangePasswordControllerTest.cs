﻿namespace CassPort.WebApi.Test
{
    using System.Threading.Tasks;
    using CassPort.Core.Models;
    using CassPort.Core.Services.Interfaces;
    using CassPort.WebApi.V1.Controllers;
    using Moq;
    using NUnit.Framework;

    public class ChangePasswordControllerTest
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public async Task ChangePasswordTest()
        {
            var mockManagePassword = new ManagePassword();
            var changePasswordService = new Mock<IChangePasswordService>();

            changePasswordService.Setup(context => context.ChangePassword(It.IsAny<ManagePassword>())).ReturnsAsync(mockManagePassword);
            var changePasswordController = new ChangePasswordController(changePasswordService.Object);

            var response = await changePasswordController.ChangePassword(It.IsAny<ManagePassword>());
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetTest()
        {
            var mockUserProfile = new UserProfile();
            var changePasswordService = new Mock<IChangePasswordService>();

            changePasswordService.Setup(context => context.GetPasswordExpired()).Returns(mockUserProfile);
            var changePasswordController = new ChangePasswordController(changePasswordService.Object);

            var response = changePasswordController.Get();
            Assert.NotNull(response);

        }
    }
}
