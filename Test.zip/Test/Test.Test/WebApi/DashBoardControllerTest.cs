﻿namespace CassPort.WebApi.Test
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using CassPort.Core.Models;
    using CassPort.Core.Services;
    using CassPort.WebApi.V1.Controllers;
    using Moq;
    using NUnit.Framework;

    public class DashBoardControllerTest
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public async Task GetDashboardByIdTest()
        {
            var mockDashBoardDetail = new List<DashBoardDetail>();
            var dashBoardService = new Mock<IDashBoardService>();
            var mapper = new Mock<IMapper>();

            dashBoardService.Setup(context => context.GetDashboard("category")).ReturnsAsync(mockDashBoardDetail);
            var dashBoardController = new DashBoardController(dashBoardService.Object, mapper.Object);

            var response = await dashBoardController.GetDashboardById("category");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetTest()
        {
            var mockDashBoardCategory = new List<DashBoardCategory>();
            var dashBoardService = new Mock<IDashBoardService>();
            var mapper = new Mock<IMapper>();

            dashBoardService.Setup(context => context.GetCategory()).ReturnsAsync(mockDashBoardCategory);
            var dashBoardController = new DashBoardController(dashBoardService.Object, mapper.Object);

            var response = await dashBoardController.Get();
            Assert.NotNull(response);

        }

        [Test]
        public async Task PostTest()
        {
            var mockDashBoardDetail = new List<DashBoardDetail>();
            var dashBoardService = new Mock<IDashBoardService>();
            var mapper = new Mock<IMapper>();

            dashBoardService.Setup(context => context.SaveDashBoard(mockDashBoardDetail)).Returns(2);
            var dashBoardController = new DashBoardController(dashBoardService.Object, mapper.Object);

            var response = dashBoardController.Post(mockDashBoardDetail);
            Assert.NotNull(response);
        }
    }
}
