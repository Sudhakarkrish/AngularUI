﻿namespace CassPort.WebApi.Test
{
    using System.Threading.Tasks;
    using CassPort.Core.Models;
    using CassPort.Core.Services.Interfaces;
    using CassPort.WebApi.V1.Controllers;
    using Moq;
    using NUnit.Framework;

    public class ForgotPasswordControllerTest
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public async Task SendForgotPasswordTest()
        {
            var mockForgotPasswordViewModel = new ForgotPasswordViewModel();
            var forgotPasswordService = new Mock<IForgotPasswordService>();


            forgotPasswordService.Setup(context => context.SendForgotPassword(It.IsAny<ForgotPasswordViewModel>())).ReturnsAsync(mockForgotPasswordViewModel);
            var forgotPasswordController = new ForgotPasswordController(forgotPasswordService.Object);

            var response = await forgotPasswordController.SendForgotPassword(It.IsAny<ForgotPasswordViewModel>());
            Assert.NotNull(response);

        }

    }
}
