namespace CassPort.WebApi.Test
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CassPort.Core.Models;
    using CassPort.Core.Services;
    using CassPort.WebApi.V1.Controllers;
    using Moq;
    using NUnit.Framework;

    public class MenuControllerTest
    {
        [SetUp]
        public void Setup()
        {
        }

       [Test]
       public async Task GetTest()
        {
            var mockMenu = new List<Menu>();
            var menuService = new Mock<IMenuService>();

            menuService.Setup(context => context.GetMenus()).ReturnsAsync(mockMenu);
            var menuController = new MenuController(menuService.Object);

            var response = await menuController.Get();
            Assert.NotNull(response);
        }
    }
}