﻿namespace CassPort.WebApi.Test
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CassPort.Core.Models;
    using CassPort.Core.Services.Interfaces;
    using CassPort.WebApi.V1.Controllers;
    using Moq;
    using NUnit.Framework;

    public class MessageControllerTest
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public async Task UpdateMessageStatusTest()
        {
            var messageService = new Mock<IMessageService>();

            messageService.Setup(context => context.UpdateMessageStatus(2, 3)).Returns(1);
            var messageController = new MessageController(messageService.Object);

            var response = messageController.UpdateMessageStatus(2, 3);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetMyMessagesTest()
        {
            var mockMessages = new List<Messages>();
            var messageService = new Mock<IMessageService>();

            messageService.Setup(context => context.GetMyMessages(2, 3)).ReturnsAsync(mockMessages);
            var messageController = new MessageController(messageService.Object);

            var response = messageController.GetMyMessages(2, 3);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetMyMessagesForHeaderTest()
        {
            var mockMessages = new List<Messages>();
            var messageService = new Mock<IMessageService>();

            messageService.Setup(context => context.GetMyMessagesForHeader()).ReturnsAsync(mockMessages);
            var messageController = new MessageController(messageService.Object);

            var response = messageController.GetMyMessagesForHeader();
            Assert.NotNull(response);
        }
    }
}
