﻿namespace CassPort.WebApi.Test
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CassPort.Core.Models;
    using CassPort.Core.Services.Interfaces;
    using CassPort.WebApi.V1.Controllers;
    using Moq;
    using NUnit.Framework;

    public class ReportControllerTest
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public async Task GetUserReportTest()
        {
            var mockMyReport = new List<MyReport>();
            var reportService = new Mock<IReportService>();

            reportService.Setup(context => context.GetUserReport()).ReturnsAsync(mockMyReport);
            var reportController = new ReportController(reportService.Object);

            var response = await reportController.GetUserReport();
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetReportInstanceByIdTest()
        {
            var mockReportInstance = new List<ReportInstance>();
            var reportService = new Mock<IReportService>();

            reportService.Setup(context => context.GetReportInstanceById(2, true)).ReturnsAsync(mockReportInstance);
            var reportController = new ReportController(reportService.Object);

            var response = await reportController.GetReportInstanceById(2);
            Assert.NotNull(response);
        }

        /// <summary>
        /// should check for method when a null value is passed
        /// </summary>
        /// <returns></returns>

        [Test]
        public async Task GetUserReportBySearchTest()
        {
            var mockMyReport = new List<MyReport>();
            var reportService = new Mock<IReportService>();

            reportService.Setup(context => context.GetUserReportBySearch("searchValue")).ReturnsAsync(mockMyReport);
            var reportController = new ReportController(reportService.Object);

            var response = await reportController.GetUserReportBySearch("searchValue");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetReportInstanceBySearchValueTest()
        {
            var mockReportInstance = new List<ReportInstance>();
            var reportService = new Mock<IReportService>();

            reportService.Setup(context => context.GetReportInstanceBySearchValue(22, true, "9/9/2019", "13/9/2019")).ReturnsAsync(mockReportInstance);
            var reportController = new ReportController(reportService.Object);

            var response = await reportController.GetReportInstanceBySearchValue(22, true, "9-9-2019", "13-9-2019");
            Assert.NotNull(response);
        }
    }
}
