﻿namespace CassPort.WebApi.Test
{
    using System.Threading.Tasks;
    using CassPort.Core.Models;
    using CassPort.Core.Services.Interfaces;
    using CassPort.WebApi.V1.Controllers;
    using Moq;
    using NUnit.Framework;

    public class ResetPasswordControllerTest
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public async Task ResetPasswordTest()
        {
            var mockResetPassword = new ResetPassword();
            var resetPasswordService = new Mock<IResetPasswordService>();

            resetPasswordService.Setup(context => context.ResetPassword(It.IsAny<ResetPassword>())).ReturnsAsync(mockResetPassword);
            var resetPasswordController = new ResetPasswordController(resetPasswordService.Object);

            var response = await resetPasswordController.ResetPassword(It.IsAny<ResetPassword>());
            Assert.NotNull(response);
        }

        [Test]
        public async Task CancelResetPasswordTest()
        {
            var mockResetPassword = new ResetPassword();
            var resetPasswordService = new Mock<IResetPasswordService>();

            resetPasswordService.Setup(context => context.RevokeResetTokenAsync(It.IsAny<ResetPassword>())).ReturnsAsync(mockResetPassword);
            var resetPasswordController = new ResetPasswordController(resetPasswordService.Object);

            var response = await resetPasswordController.CancelResetPassword(It.IsAny<ResetPassword>());
            Assert.NotNull(response);
        }
    }
}
