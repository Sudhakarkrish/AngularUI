﻿namespace CassPort.WebApi.Test
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CassPort.Core.Models;
    using CassPort.Core.Services.Interfaces;
    using CassPort.WebApi.V1.Controllers;
    using Moq;
    using NUnit.Framework;

    public class ShipPointControllerTest
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public async Task GetUserShipPointsTest()
        {
            var mockShipPoint = new List<ShipPoint>();
            var shipPointService = new Mock<IShipPointService>();

            shipPointService.Setup(context => context.GetUserShipPoints("client", 2)).ReturnsAsync(mockShipPoint);
            var shipPointController = new ShipPointController(shipPointService.Object);

            var response = await shipPointController.GetUserShipPoints("client", 2);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetClientShipPointsTest()
        {
            var mockShipPoint = new List<ShipPoint>();
            var shipPointService = new Mock<IShipPointService>();

            shipPointService.Setup(context => context.GetClientShipPoints("searchText", "client")).ReturnsAsync(mockShipPoint);
            var shipPointController = new ShipPointController(shipPointService.Object);

            var response = await shipPointController.GetClientShipPoints("searchText", "client");
            Assert.NotNull(response);
        }
    }
}
