﻿namespace CassPort.WebApi.Test
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CassPort.Core.Models;
    using CassPort.Core.Services.Interfaces;
    using CassPort.WebApi.V1.Controllers;
    using Moq;
    using NUnit.Framework;

    public class ShipperControllerTest
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public async Task GetShippersBySearchTest()
        {
            var mockShipper = new List<Shipper>();
            var shipperService = new Mock<IShipperService>();

            shipperService.Setup(context => context.GetShippersBySearch("searchText")).ReturnsAsync(mockShipper);
            var shipperController = new ShipperController(shipperService.Object);

            var response = await shipperController.GetShippersBySearch("searchText");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUserShippersTest()
        {
            bool isStaging = false;
            var mockShipper = new List<Shipper>();
            var shipperService = new Mock<IShipperService>();

            shipperService.Setup(context => context.GetUserShippers(isStaging)).ReturnsAsync(mockShipper);
            var shipperController = new ShipperController(shipperService.Object);

            var response = await shipperController.GetUserShippers(isStaging);
            Assert.NotNull(response);
        }

        [Test]
        public async Task PostTest()
        {
            var mockShipper = new List<Shipper>();
            var shipperService = new Mock<IShipperService>();

            shipperService.Setup(context => context.UpdateUserShippers(mockShipper, 22)).Returns(1);
            var shipperController = new ShipperController(shipperService.Object);

            var response = shipperController.Post(mockShipper, 44);
            Assert.NotNull(response);
        }
    }
}
