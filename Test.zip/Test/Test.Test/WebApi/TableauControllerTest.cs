﻿namespace CassPort.WebApi.Test
{
    using System.Threading.Tasks;
    using CassPort.Core.Models;
    using CassPort.Core.Services.Interfaces;
    using CassPort.WebApi.V1.Controllers;
    using Moq;
    using NUnit.Framework;

    public class TableauControllerTest
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public async Task GetTrustedTokenTest()
        {
            var mockUserProfile = new UserProfile();
            var mockTableauResponse = new TableauResponse();
            var mockrequestModel = new TableauTrustedTicketer();
            var tableauService = new Mock<ITableauService>();

            tableauService.Setup(context => context.GetTrustedToken(mockrequestModel)).ReturnsAsync(mockTableauResponse);
            var tableauController = new TableauController(tableauService.Object, mockUserProfile);

            var response = await tableauController.GetTrustedToken(mockrequestModel);
            Assert.NotNull(response);
        }
    }
}
