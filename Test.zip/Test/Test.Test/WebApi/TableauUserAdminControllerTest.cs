﻿namespace CassPort.WebApi.Test
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CassPort.Core.Models;
    using CassPort.Core.Services.Interfaces;
    using CassPort.WebApi.V1.Controllers;
    using Moq;
    using NUnit.Framework;

    public class TableauUserAdminControllerTest
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public async Task GetCustomDashboardTest()
        {
            var mockStateParameter = new StateParameter();
            var mockTableauUserAdmin = new List<TableauUserAdmin>();
            var tableauUserAdminService = new Mock<ITableauUserAdminService>();

            tableauUserAdminService.Setup(context => context.GetCustomDashboard("test", 0, 0, mockStateParameter.Page, mockStateParameter.PageSize, mockStateParameter.SortBy, mockStateParameter.SortDirection)).ReturnsAsync(mockTableauUserAdmin);
            var tableauUserAdminController = new TableauUserAdminController(tableauUserAdminService.Object);

            var response = await tableauUserAdminController.GetCustomDashboard("test", 0, 0, mockStateParameter);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetSearchUserTest()
        {
            var mockStateParameter = new StateParameter();
            var mockTableauUserAccount = new List<TableauUserAccount>();
            var tableauUserAdminService = new Mock<ITableauUserAdminService>();

            tableauUserAdminService.Setup(context => context.GetSearchUser("userId", "firstName", "lastName", "companyName", mockStateParameter.Page, mockStateParameter.PageSize, mockStateParameter.SortBy, mockStateParameter.SortDirection)).ReturnsAsync(mockTableauUserAccount);
            var tableauUserAdminController = new TableauUserAdminController(tableauUserAdminService.Object);

            var response = await tableauUserAdminController.GetSearchUser("userId", "firstName", "lastName", "companyName", mockStateParameter);
            Assert.NotNull(response);
        }

        [Test]
        public async Task CreateDashboardTest()
        {
            var mockCreateDashboard = new CreateDashboard();
            var mockResultMessage = new ResultMessage();
            var tableauUserAdminService = new Mock<ITableauUserAdminService>();

            tableauUserAdminService.Setup(context => context.CreateDashboard(mockCreateDashboard)).ReturnsAsync(mockResultMessage);
            var tableauUserAdminController = new TableauUserAdminController(tableauUserAdminService.Object);

            var response = await tableauUserAdminController.CreateDashboard(mockCreateDashboard);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetDashboardTypeTest()
        {
            var mockDashboardType = new List<DashboardType>();
            var tableauUserAdminService = new Mock<ITableauUserAdminService>();

            tableauUserAdminService.Setup(context => context.GetDashboardType()).ReturnsAsync(mockDashboardType);
            var tableauUserAdminController = new TableauUserAdminController(tableauUserAdminService.Object);

            var response = await tableauUserAdminController.GetDashboardType();
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetDashboardCategoryTest()
        {
            var mockDashBoardCategory = new List<DashBoardCategory>();
            var tableauUserAdminService = new Mock<ITableauUserAdminService>();

            tableauUserAdminService.Setup(context => context.GetDashboardCategory()).ReturnsAsync(mockDashBoardCategory);
            var tableauUserAdminController = new TableauUserAdminController(tableauUserAdminService.Object);

            var response = await tableauUserAdminController.GetDashboardCategory();
            Assert.NotNull(response);
        }

        [Test]
        public async Task RemoveDashboardTest()
        {
            var mockResultMessage = new ResultMessage();
            var mockTableauUserAdmin = new List<TableauUserAdmin>();
            var tableauUserAdminService = new Mock<ITableauUserAdminService>();

            tableauUserAdminService.Setup(context => context.RemoveDashboard(mockTableauUserAdmin, 1)).Returns(mockResultMessage);
            var tableauUserAdminController = new TableauUserAdminController(tableauUserAdminService.Object);

            var response = tableauUserAdminController.RemoveDashboard(mockTableauUserAdmin, 1);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetManageDashboardByUsersTest()
        {
            var mockStateParameter = new StateParameter();
            var mockTableauUserAdmin = new List<TableauUserAdmin>();
            var tableauUserAdminService = new Mock<ITableauUserAdminService>();

            tableauUserAdminService.Setup(context => context.GetManageDashboardByUsers("test", 2, 4, mockStateParameter.Page, mockStateParameter.PageSize, mockStateParameter.SortBy, mockStateParameter.SortDirection)).ReturnsAsync(mockTableauUserAdmin);
            var tableauUserAdminController = new TableauUserAdminController(tableauUserAdminService.Object);

            var response = await tableauUserAdminController.GetManageDashboardByUsers("test", 2, 4, mockStateParameter);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUserDetailsForDashboardTest()
        {
            var mockDashboardUserDetail = new List<DashboardUserDetail>();
            var tableauUserAdminService = new Mock<ITableauUserAdminService>();

            tableauUserAdminService.Setup(context => context.GetUserDetailsForDashboard(3)).ReturnsAsync(mockDashboardUserDetail);
            var tableauUserAdminController = new TableauUserAdminController(tableauUserAdminService.Object);

            var response = await tableauUserAdminController.GetUserDetailsForDashboard(3);
            Assert.NotNull(response);
        }

        [Test]
        public async Task InsertSelectedUserToDashboardTest()
        {
            var mockInsertDashboardUsers = new List<InsertDashboardUsers>();
            var tableauUserAdminService = new Mock<ITableauUserAdminService>();

            tableauUserAdminService.Setup(context => context.InsertSelectedUserToDashboard(mockInsertDashboardUsers)).Returns(3);
            var tableauUserAdminController = new TableauUserAdminController(tableauUserAdminService.Object);

            var response = tableauUserAdminController.InsertSelectedUserToDashboard(mockInsertDashboardUsers);
            Assert.NotNull(response);
        }

        [Test]
        public async Task RemoveAssignedUserTest()
        {
            var tableauUserAdminService = new Mock<ITableauUserAdminService>();

            tableauUserAdminService.Setup(context => context.RemoveAssignedUser(4 , 1)).Returns(3);
            var tableauUserAdminController = new TableauUserAdminController(tableauUserAdminService.Object);

            var response = tableauUserAdminController.RemoveAssignedUser(4 , 1);
            Assert.NotNull(response);
        }
    }
}
