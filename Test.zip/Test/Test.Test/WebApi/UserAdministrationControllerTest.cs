﻿namespace CassPort.WebApi.Test
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CassPort.Core.Models;
    using CassPort.Core.Services.Interfaces;
    using CassPort.WebApi.V1.Controllers;
    using Moq;
    using NUnit.Framework;

    public class UserAdministrationControllerTest
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public async Task GetRegisterUsersTest()
        {
            var mockMyUserAdministration = new MyUserAdministration();
            var mockStateParameter = new StateParameter();
            var userAdministrationService = new Mock<IUserAdministrationService>();

            userAdministrationService.Setup(context => context.GetRegisteredUsers("filterValue", mockStateParameter.Page, mockStateParameter.PageSize, mockStateParameter.SortBy, mockStateParameter.SortDirection, "typeValue")).ReturnsAsync(mockMyUserAdministration);
            var userAdministrationController = new UserAdministrationController(userAdministrationService.Object);

            var response = await userAdministrationController.GetRegisterUsers("filterValue", "typeValue", mockStateParameter);
            Assert.NotNull(response);
        }

        [Test]
        public async Task DisableDeleteTest()
        {
            var mockUserAdministration = new List<UserAdministration>();
            var mockResultMessage = new ResultMessage();
            var userAdministrationService = new Mock<IUserAdministrationService>();

            userAdministrationService.Setup(context => context.DisableDelete(mockUserAdministration, "command", "STL", "N", false)).Returns(mockResultMessage);
            var userAdministrationController = new UserAdministrationController(userAdministrationService.Object);

            var response = userAdministrationController.DisableDelete(mockUserAdministration, "command", "STL", "N", false);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetInternalUsersTest()
        {
            var mockMyUserAdministration = new MyUserAdministration();
            var mockStateParameter = new StateParameter();
            var userAdministrationService = new Mock<IUserAdministrationService>();

            userAdministrationService.Setup(context => context.InternalUsers("filterValue", mockStateParameter.Page, mockStateParameter.PageSize, mockStateParameter.SortBy, mockStateParameter.SortDirection)).ReturnsAsync(mockMyUserAdministration);
            var userAdministrationController = new UserAdministrationController(userAdministrationService.Object);

            var response = await userAdministrationController.GetInternalUsers("filterValue", mockStateParameter);
            Assert.NotNull(response);
        }

        [Test]
        public async Task UnregisteredUsersTest()
        {
            var mockMyUserAdministration = new MyUserAdministration();
            var mockStateParameter = new StateParameter();
            var userAdministrationService = new Mock<IUserAdministrationService>();

            userAdministrationService.Setup(context => context.UnregisteredUsers("filterValue", mockStateParameter.Page, mockStateParameter.PageSize, mockStateParameter.SortBy, mockStateParameter.SortDirection, "typeValue")).ReturnsAsync(mockMyUserAdministration);
            var userAdministrationController = new UserAdministrationController(userAdministrationService.Object);

            var response = await userAdministrationController.UnregisteredUsers("filterValue", "typeValue", mockStateParameter);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetAllUsersTest()
        {
            var mockMyUserAdministration = new MyUserAdministration();
            var mockStateParameter = new StateParameter();
            var userAdministrationService = new Mock<IUserAdministrationService>();

            userAdministrationService.Setup(context => context.GetAllUsers("filterValue", mockStateParameter.Page, mockStateParameter.PageSize, mockStateParameter.SortBy, mockStateParameter.SortDirection)).ReturnsAsync(mockMyUserAdministration);
            var userAdministrationController = new UserAdministrationController(userAdministrationService.Object);

            var response = await userAdministrationController.GetAllUsers("filterValue", mockStateParameter);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetExternalAuthenticatorsTest()
        {
            var mockExternalAuthenticator = new List<ExternalAuthenticator>();
            var userAdministrationService = new Mock<IUserAdministrationService>();

            userAdministrationService.Setup(context => context.GetExternalAuthenticators()).ReturnsAsync(mockExternalAuthenticator);
            var userAdministrationController = new UserAdministrationController(userAdministrationService.Object);

            var response = await userAdministrationController.GetExternalAuthenticators();
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetExternalAuthenticationProviderMappingsTest()
        {
            var mockExternalProviderMapping = new List<ExternalProviderMapping>();
            var userAdministrationService = new Mock<IUserAdministrationService>();

            userAdministrationService.Setup(context => context.GetExternalAuthenticationProviderMappings(2)).ReturnsAsync(mockExternalProviderMapping);
            var userAdministrationController = new UserAdministrationController(userAdministrationService.Object);

            var response = await userAdministrationController.GetExternalAuthenticationProviderMappings(2);
            Assert.NotNull(response);
        }

        [Test]
        public async Task UserAdminTest()
        {
            var mockUserAdmin = new UserAdmin();
            var userAdministrationService = new Mock<IUserAdministrationService>();

            userAdministrationService.Setup(context => context.UserAdmin(2, "type", 3)).ReturnsAsync(mockUserAdmin);
            var userAdministrationController = new UserAdministrationController(userAdministrationService.Object);

            var response = await userAdministrationController.UserAdmin(2, "type", 3);
            Assert.NotNull(response);
        }

        [Test]
        public async Task RegisterUserTest()
        {
            var mockUserAdmin = new UserAdmin();
            var userAdministrationService = new Mock<IUserAdministrationService>();

            userAdministrationService.Setup(context => context.Register(mockUserAdmin)).ReturnsAsync(mockUserAdmin);
            var userAdministrationController = new UserAdministrationController(userAdministrationService.Object);

            var response = await userAdministrationController.RegisterUser(mockUserAdmin);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUserPrivilegeTest()
        {
            var mockUserPriviledge = new List<UserPriviledge>();
            IEnumerable<UserPriviledge> en = mockUserPriviledge;
            var userAdministrationService = new Mock<IUserAdministrationService>();

            userAdministrationService.Setup(context => context.GetUserPrivilege(2)).ReturnsAsync(en);
            var userAdministrationController = new UserAdministrationController(userAdministrationService.Object);

            var response = await userAdministrationController.GetUserPrivilege(2);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetCheckPriviledgeTest()
        {
            var userAdministrationService = new Mock<IUserAdministrationService>();

            userAdministrationService.Setup(context => context.GetCheckPriviledge("id")).Returns(true);
            var userAdministrationController = new UserAdministrationController(userAdministrationService.Object);

            var response = userAdministrationController.GetCheckPriviledge("id");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetVerifyInternalUserTest()
        {
            var mockActiveDirectory = new ActiveDirectory();
            var userAdministrationService = new Mock<IUserAdministrationService>();

            userAdministrationService.Setup(context => context.GetVerifyInternalUser("email")).Returns(mockActiveDirectory);
            var userAdministrationController = new UserAdministrationController(userAdministrationService.Object);

            var response = userAdministrationController.GetVerifyInternalUser("email");
            Assert.NotNull(response);
        }

        [Test]
        public async Task DeleteUserTest()
        {
            var mockResultMessage = new ResultMessage();
            var mockUserAdministration = new List<UserAdministration>();
            var userAdministrationService = new Mock<IUserAdministrationService>();

            userAdministrationService.Setup(context => context.RequestDeleteUser(mockUserAdministration)).ReturnsAsync(mockResultMessage);
            var userAdministrationController = new UserAdministrationController(userAdministrationService.Object);

            var response = userAdministrationController.DeleteUser(mockUserAdministration);
            Assert.NotNull(response);
        }
    }
}
