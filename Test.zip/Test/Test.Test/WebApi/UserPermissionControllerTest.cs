﻿namespace CassPort.WebApi.Test
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CassPort.Core.Models;
    using CassPort.Core.Services.Interfaces;
    using CassPort.WebApi.V1.Controllers;
    using Moq;
    using NUnit.Framework;

    public class UserPermissionControllerTest
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public async Task GetUserPermissionsTest()
        {
            var mockPriviledge = new List<Priviledge>();
            var userPermissionService = new Mock<IUserPermissionService>();

            userPermissionService.Setup(context => context.GetUserPermissions(true, "test")).ReturnsAsync(mockPriviledge);
            var userPermissionController = new UserPermissionController(userPermissionService.Object);

            var response = await userPermissionController.GetUserPermissions(true, "test");
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUserPrivilegeGroupsTest()
        {
            var mockPrivilegeGroupList = new List<PrivilegeGroupList>();
            mockPrivilegeGroupList.Add(new PrivilegeGroupList
            {
                Priviledge_Group_Id = 3,
                Priviledge_Group_Name = "group_name"
            });
            var userPermissionService = new Mock<IUserPermissionService>();

            userPermissionService.Setup(context => context.GetUserPrivilegeGroups(true, "test")).ReturnsAsync(mockPrivilegeGroupList);
            var userPermissionController = new UserPermissionController(userPermissionService.Object);

            var response = await userPermissionController.GetUserPrivilegeGroups(true, "test");
            Assert.NotNull(response);
        }

        /// <summary>
        /// have to check method when search value is null
        /// </summary>
        /// <returns></returns>
        [Test]
        public async Task GetUserPermissionsByGroupTest()
        {
            var mockPriviledge = new List<Priviledge>();
            var userPermissionService = new Mock<IUserPermissionService>();

            userPermissionService.Setup(context => context.GetUserPermissionsByGroup(true, "userType","userGroupId","searchVal")).ReturnsAsync(mockPriviledge);
            var userPermissionController = new UserPermissionController(userPermissionService.Object);

            var response = await userPermissionController.GetUserPermissionsByGroup(true, "userType", "userGroupId", "searchVal");
            Assert.NotNull(response);
        }
    }
}
