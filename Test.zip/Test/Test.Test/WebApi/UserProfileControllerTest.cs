﻿namespace CassPort.WebApi.Test
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CassPort.Core.Models;
    using CassPort.Core.Services.Interfaces;
    using CassPort.WebApi.V1.Controllers;
    using Moq;
    using NUnit.Framework;

    public class UserProfileControllerTest
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public async Task GetTest()
        {
            var mockUserRole = new UserRole();
            var userProfileService = new Mock<IUserProfileService>();

            userProfileService.Setup(context => context.GetUserDetail()).Returns(mockUserRole);
            var userProfileController = new UserProfileController(userProfileService.Object);

            var response = userProfileController.Get();
            Assert.NotNull(response);
        }

        [Test]
        public async Task RegisterUserProfileTest()
        {
            var mockRegisterViewModel = new RegisterViewModel();
            var userProfileService = new Mock<IUserProfileService>();

            userProfileService.Setup(context => context.RegisterUserProfile(mockRegisterViewModel)).Returns(true);
            var userProfileController = new UserProfileController(userProfileService.Object);

            var response = userProfileController.RegisterUserProfile(mockRegisterViewModel);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetCountriesTest()
        {
            var mockCountry = new List<Country>();
            var userProfileService = new Mock<IUserProfileService>();

            userProfileService.Setup(context => context.GetCountries()).ReturnsAsync(mockCountry);
            var userProfileController = new UserProfileController(userProfileService.Object);

            var response = await userProfileController.GetCountries();
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetStatesTest()
        {
            var mockState = new List<State>();
            var userProfileService = new Mock<IUserProfileService>();

            userProfileService.Setup(context => context.GetStates("country_code")).ReturnsAsync(mockState);
            var userProfileController = new UserProfileController(userProfileService.Object);

            var response = await userProfileController.GetStates("country_code");
            Assert.NotNull(response);
        }

        [Test]
        public async Task UpdateUserProfileTest()
        {
            var mockEditProfile = new EditProfile();
            var userProfileService = new Mock<IUserProfileService>();

            userProfileService.Setup(context => context.UpdateUserProfile(mockEditProfile)).Returns(true);
            var userProfileController = new UserProfileController(userProfileService.Object);

            var response = userProfileController.UpdateUserProfile(mockEditProfile);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetUserAccountTest()
        {
            var mockEditProfile = new EditProfile();
            var userProfileService = new Mock<IUserProfileService>();

            userProfileService.Setup(context => context.GetUserAccount(2)).ReturnsAsync(mockEditProfile);
            var userProfileController = new UserProfileController(userProfileService.Object);

            var response = await userProfileController.GetUserAccount(2);
            Assert.NotNull(response);
        }

        [Test]
        public async Task GetTableauUserAccountTest()
        {
            var mockTableauUserAccountDetail = new TableauUserAccountDetail();
            var userProfileService = new Mock<IUserProfileService>();

            userProfileService.Setup(context => context.GetTableauUserAccount(2)).ReturnsAsync(mockTableauUserAccountDetail);
            var userProfileController = new UserProfileController(userProfileService.Object);

            var response = await userProfileController.GetTableauUserAccount(2);
            Assert.NotNull(response);
        }
    }
}
