﻿namespace CassPort.WebApi
{
    using Microsoft.AspNetCore.Mvc;

    /// <summary>
    /// Base Controller
    /// </summary>
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class BaseApiController : ControllerBase
    {
    }
}
