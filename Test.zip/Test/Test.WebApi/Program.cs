﻿namespace CassPort.WebApi
{
    using System;
    using System.Diagnostics;
    using Microsoft.AspNetCore;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Application Program.
    /// </summary>
    public static class Program
    {
        /// <summary>
        /// Main method
        /// </summary>
        /// <param name="args">returns args</param>
        public static void Main(string[] args)
        {
            CreateWebHostBuilder(args).Build().Run();
        }

        /// <summary>
        /// Create Web Host builder
        /// </summary>
        /// <param name="args">args</param>
        /// <returns>returns webhost builder</returns>
        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .ConfigureAppConfiguration((builderContext, config) =>
                {
                    if (Debugger.IsAttached)
                    {
                        config.AddJsonFile("appsettings.json");
                    }
                    else
                    {
                        config.SetBasePath(builderContext.HostingEnvironment.ContentRootPath)
                        .AddJsonFile($"appsettings.{builderContext.HostingEnvironment.EnvironmentName}.json", optional: false, reloadOnChange: false)
                        .AddEnvironmentVariables();
                    }
                })
                .ConfigureLogging((builderContext, loggingBuilder) =>
                {
                    // Clear all default logging providers
                    loggingBuilder.ClearProviders();

                    // Enable Microsoft Console Logging
                    loggingBuilder.AddConfiguration(builderContext.Configuration.GetSection("Logging"));

                    loggingBuilder.AddConsole((options) =>
                    {
                        options.IncludeScopes = Convert.ToBoolean(builderContext.Configuration["Logging:IncludeScopes"]);
                    });
                })
                .UseStartup<Startup>();
    }
}
