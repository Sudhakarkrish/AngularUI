﻿namespace CassPort.WebApi.Security
{
    using System;
    using System.Security.Claims;
    using System.Threading.Tasks;
    using CassPort.Core.Models;
    using CassPort.Core.Services;
    using Microsoft.AspNetCore.Authentication;
    using Newtonsoft.Json;

    /// <summary>
    /// Claims Loader
    /// </summary>
    public class ClaimsLoader : IClaimsTransformation
    {
        private IUserClaimsService userAccountService;
        private UserProfile userProfile;

        /// <summary>
        /// Initializes a new instance of the <see cref="ClaimsLoader"/> class.
        /// </summary>
        /// <param name="userService">userService</param>
        /// <param name="user">User object</param>
        public ClaimsLoader(IUserClaimsService userService, UserProfile user)
        {
           this.userAccountService = userService;
           this.userProfile = user;
        }

        /// <summary>
        /// Transform claims
        /// </summary>
        /// <param name="principal">user claims</param>
        /// <returns>returns claims principal</returns>
        public async Task<ClaimsPrincipal> TransformAsync(ClaimsPrincipal principal)
        {
            var identity = (ClaimsIdentity)principal.Identity;

            // create a new ClaimsIdentity copying the existing one
            var claimsIdentity = new ClaimsIdentity(
                identity.Claims,
                identity.AuthenticationType,
                identity.NameClaimType,
                identity.RoleClaimType);

            string sUserId = principal.FindFirst(ClaimTypes.Sid)?.Value;
            string realUserId = principal.FindFirst(ClaimTypes.PrimarySid)?.Value;
            string passwordExpirationDays = principal.FindFirst("c_password_expiration").Value;
            if (this.userProfile.UserId > 0)
            {
                return new ClaimsPrincipal(claimsIdentity);
            }

            string externalProvider = principal.FindFirst("c_ext_auth")?.Value ?? null;
            if (int.TryParse(sUserId, out int iUserId))
            {
                this.userProfile = await this.userAccountService.GetUserProfile(iUserId);
            }

            if (sUserId != realUserId)
            {
                this.userProfile.IsImpersonate = true;
                this.userProfile.ChangeByUserId = Convert.ToInt32(realUserId);
            }

            this.userProfile.PasswordExpirationDays = Convert.ToInt32(passwordExpirationDays);
            if (!string.IsNullOrEmpty(externalProvider))
            {
                this.userProfile.ExternalAuth = JsonConvert.DeserializeObject<ExternalAuthenticator>(externalProvider);
            }

            return new ClaimsPrincipal(claimsIdentity);
        }
    }
}
