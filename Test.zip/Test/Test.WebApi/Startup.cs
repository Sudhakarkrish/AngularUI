﻿namespace CassPort.WebApi
{
    using CassPort.Core.Models;
    using CassPort.DependencyResolution;
    using CassPort.WebApi.Security;
    using Microsoft.AspNetCore.Authentication;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.ApiExplorer;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Hosting;

    /// <summary>
    /// Application starts here.
    /// </summary>
    public class Startup
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Startup"/> class.
        /// </summary>
        /// <param name="configuration">Application Configuration</param>
        public Startup(IConfiguration configuration)
        {
            this.Configuration = configuration;
            configuration.CreateLogger();
        }

        /// <summary>
        /// Gets gets or sets configuration.
        /// </summary>
        public IConfiguration Configuration { get; }

        /// <summary>
        /// This method gets called by the runtime. Use this method to add services to the container.
        /// </summary>
        /// <param name="services">Application service</param>
        public void ConfigureServices(IServiceCollection services)
        {
            IConfigurationSection dbConfig = this.Configuration.GetSection("ConnectionStrings");
            services.Configure<DBEnvironments>(dbConfig);

            // Get application name
            IConfigurationSection appConfig = this.Configuration.GetSection("Source");
            services.Configure<ApplicationConfig>(appConfig);
            services.AddScoped<UserProfile>();
            services.AddCors();

            services.AddAuthentication("Bearer")
                    .AddIdentityServerAuthentication(options =>
                    {
                        options.ApiName = this.Configuration.GetValue<string>("ApiProfile:WebApiProfile");
                        options.ApiSecret = this.Configuration.GetValue<string>("ClientSecret:Id");
                        options.Authority = this.Configuration.GetValue<string>("Authority:DevIdentityServer");
                        options.LegacyAudienceValidation = true;
                        options.RequireHttpsMetadata = false;
                    });

            services.AddApiVersioning();
            services.AddVersionedApiExplorer(
                    options =>
                    {
                          // The format of the version added to the route URL
                          options.GroupNameFormat = "'v'VVV";

                          // Tells swagger to replace the version in the controller route
                          options.SubstituteApiVersionInUrl = true;
                    });
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_3_0);
            services.AddMvc(option => option.EnableEndpointRouting = false);
            services.AddTransient<IClaimsTransformation, ClaimsLoader>();            
            services.RegisterDependencies(this.Configuration, this.GetType().Assembly);
        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        /// </summary>
        /// <param name="app">Application to handle</param>
        /// <param name="env">Environment details</param>
        /// <param name="provider">Provider</param>
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, IApiVersionDescriptionProvider provider)
        {
            EnvironmentConfig.EnvironmentName = env.EnvironmentName;
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseCors(x => x
             .AllowAnyOrigin()
             .AllowAnyMethod()
             .AllowAnyHeader());

            app.UseRouting();
            app.UseHttpsRedirection();
            app.UseAuthentication();
            app.UseAuthorization();
            app.RegisterMiddlewares(provider, env);

            app.UseEndpoints(endPoints =>
            {
                endPoints.MapControllerRoute("default", "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
