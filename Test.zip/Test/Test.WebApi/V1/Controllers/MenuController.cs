﻿namespace CassPort.WebApi.V1.Controllers
{
    using CassPort.Core.Models;
    using CassPort.Core.Services;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    /// <summary>
    /// Menu Controller
    /// </summary>
    [ApiVersion("1.0")]
    [Authorize]
    public class MenuController : BaseApiController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MenuController"/> class.
        /// </summary>
        /// <param name="menuService">menu service to handle</param>
        public MenuController(IMenuService menuService)
        {
            this.MenuService = menuService;
        }

        private IMenuService MenuService { get; }

        /// <summary>
        /// GET api/Get menu items
        /// </summary>
        /// <returns>returns menu list</returns>
        [HttpGet]
        public async Task<ActionResult<List<Menu>>> Get()
        {
            return await this.MenuService.GetMenus();
        }
    }
}