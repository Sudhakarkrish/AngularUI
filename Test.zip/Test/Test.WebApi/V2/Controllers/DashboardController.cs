﻿namespace CassPort.WebApi.V2.Controllers
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using CassPort.Core.Models;
    using CassPort.Core.Services;
    using Microsoft.AspNetCore.Mvc;

    /// <summary>
    /// DashBoard Controller
    /// </summary>
    [ApiVersion("2.0")]
    public class DashboardController : BaseApiController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DashboardController"/> class.
        /// </summary>
        /// <param name="dashboardService">dashbaord service to handle</param>
        /// <param name="mapper">mapper</param>
        public DashboardController(IDashboardService dashboardService, IMapper mapper)
        {
            this.DashBoardService = dashboardService;
            this.Mapper = mapper;
        }

        /// <summary>
        /// Gets mapper
        /// </summary>
        public IMapper Mapper { get; }

        private IDashboardService DashBoardService { get; }

        /// <summary>
        /// GET api/dashbaorditems
        /// </summary>
        /// <param name="category">Body values</param>
        /// <returns>returns dashbaord list</returns>
        [HttpGet]
        [Route("{category}")]
        public async Task<ActionResult<List<DashboardDetail>>> GetDashboardById(string category)
        {
            // throw new NotFoundCustomException("Test exception" , "description");
            return await this.DashBoardService.GetDashboard(category);
        }

        /// <summary>
        /// GET api/categoryitems
        /// </summary>
        /// <returns>returns dashbaord list</returns>
        [HttpGet]
        public async Task<ActionResult<List<DashboardCategory>>> Get()
        {
            // throw new NotFoundCustomException("Test exception" , "description");
            return await this.DashBoardService.GetCategory();
        }

        /// <summary>
        /// POST api/values
        /// </summary>
        /// <param name="dashBoardDetail">Body values</param>
        /// <returns>returns user id</returns>
        [HttpPost]
        public int Post([FromBody]List<DashboardDetail> dashBoardDetail)
        {
            return this.DashBoardService.SaveDashBoard(dashBoardDetail);
        }
    }
}