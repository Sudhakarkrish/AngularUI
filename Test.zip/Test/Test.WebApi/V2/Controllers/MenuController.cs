﻿namespace CassPort.WebApi.V2.Controllers
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using CassPort.Core.Models;
    using CassPort.Core.Services;
    using Microsoft.AspNetCore.Mvc;

    /// <summary>
    /// Menu Controller
    /// </summary>
    [ApiVersion("2.0")]
    public class MenuController : BaseApiController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MenuController"/> class.
        /// </summary>
        /// <param name="menuService">menu service to handle</param>
        /// <param name="mapper">mapper</param>
        public MenuController(IMenuService menuService, IMapper mapper)
        {
            this.MenuService = menuService;
            this.Mapper = mapper;
        }

        /// <summary>
        /// Gets mapper
        /// </summary>
        public IMapper Mapper { get; }

        private IMenuService MenuService { get; }

        /// <summary>
        /// GET api/Get menu items
        /// </summary>
        /// <returns>returns menu list</returns>
        [HttpGet]
        public async Task<ActionResult<List<Menu>>> Get()
        {
            return await this.MenuService.GetMenus();
        }
    }
}