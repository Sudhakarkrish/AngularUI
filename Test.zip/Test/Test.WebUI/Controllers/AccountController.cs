﻿namespace CassPort.WebUI.Controllers
{
    using CassPort.WebUI.Helpers;
    using CassPort.WebUI.Models;
    using Microsoft.AspNetCore.Authentication;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using System;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    [Authorize]
    public class AccountController : Controller
    {
        private readonly ILogger<AccountController> logger;

        public AccountController(ILogger<AccountController> logger)
        {
            this.logger = logger;
        }

        [AllowAnonymous]
        [HttpGet]
        public IActionResult RegisterUser()
        {
            var registerView = new RegisterViewModel();

            return View(new RegisterViewModel { Country = "US" });
        }

        [HttpPost]
        [AllowAnonymous]
        public IActionResult RegisterUser(RegisterViewModel model)
        {
            var registerView = new RegisterViewModel();
            int rowsAffected = 0;
            if (ModelState.IsValid)
            {
                model.CompanyName.Trim();
                model.Address1.Trim();
                rowsAffected = AccountRepository.ApplyForRegistration(model);
                if (rowsAffected == 1)
                {
                    registerView.IsRegistered = true;
                    return View(registerView);
                }
                else
                {
                    registerView.IsRegistered = false;
                    return View(registerView);
                }
            }
            else
            {

                return View(registerView);
            }
        }

        [AllowAnonymous]
        [HttpGet]
        public async Task<ActionResult> GetCountryRegions()
        {
            var countryRegions = AccountRepository.GetCountryRegions();

            // Build the js array of countries and regions.
            var jsContent = new StringBuilder("var countryRegions=[];");
            foreach (CountryRegionModel countryRegion in countryRegions)
            {
                jsContent.Append($"countryRegions[\"{countryRegion.CountryCode}\"]=[");
                jsContent.Append(string.Join(",",
                    countryRegion.Regions.Select(region => $"[\"{region.Code}\",\"{region.Name}\"]")));
                jsContent.Append("];");
            }

            return Content(jsContent.ToString(), "text/javascript");
        }

        [AllowAnonymous]
        [HttpGet]
        public IActionResult ForgotPassword()
        {
            var forgotpassword = new ForgotPasswordViewModel();

            return View(forgotpassword);
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> ForgotPassword(ForgotPasswordViewModel forgotPassword)
        {
            try
            {
                forgotPassword = await Helpers.ServiceHelpers.SendForgotPassword(forgotPassword);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, "Error occured in ForgotPassword");
                forgotPassword.Confirmed = false;
                forgotPassword.Token = null;
            }
            return View(forgotPassword);
        }

        [HttpPost]
        public async Task<Response> Logout()
        {
            await HttpContext.SignOutAsync();
            Response response = new Response()
            {
                Status = "OK"
            };

            return response;
        }

        [AllowAnonymous]
        public async Task<IActionResult> ResetPassword(string email, string loginId, string code)
        {
            bool isValidDate = false;
            var resetPassword = new ResetPassword
            {
                Email = email,
                LoginId = loginId,
                Token = code
            };
            isValidDate = AccountRepository.IsTokenConfirmed(loginId, email, code);
            if (!isValidDate)
            {
                resetPassword.Message = "Failed";
            }           
            return View(resetPassword);
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> ResetPassword(ResetPassword resetPassword)
        {
            try
            {
                resetPassword = await Helpers.ServiceHelpers.ResetPassword(resetPassword);
            }
            catch(Exception ex)
            {
                this.logger.LogError(ex, "Error occured in ResetPassword");
            }
            return View(resetPassword);
        }

        [AllowAnonymous]
        public async Task<IActionResult> CancelResetPassword(string email, string code)
        {           
            try
            {
                var model = new ResetPassword();

                if (code == null || email == null)
                {
                    model.IsEmailSent = false;
                    return View(model);
                }

                model.Token = code;
                model.Email = email;

                if (await Helpers.ServiceHelpers.RevokeResetTokenAsync(model) != 1)
                {
                    return View(model);
                }

                //Revoke the Reset Token
                return View(model);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, "Error occured in CancelResetPassword");
                return View("Error");
            }

        }

    }
}