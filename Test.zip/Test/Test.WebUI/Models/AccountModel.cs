﻿namespace CassPort.WebUI.Models
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class CodeNameValue
    {
        public string Code { get; set; }
        public string Name { get; set; }
    }

    public class CountryRegionModel
    {
        public string CountryCode { get; set; }
        public IList<CodeNameValue> Regions { get; set; }
    }

    public class Response
    {
        public string Status { get; set; }
    }

    public class RegisterViewModel
    {

        [Required(ErrorMessage = "First Name is required")]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }


        [Display(Name = "MI")]
        [DisplayFormat(ConvertEmptyStringToNull = false)]
        public string MiddleInitial { get; set; }

        [Required(ErrorMessage = "Last Name is required")]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Company Name is required")]
        [Display(Name = "Company Name")]
        [RegularExpression(@"^[^\s].*", ErrorMessage = "Whitespace not allowed at the beginning")]
        public string CompanyName { get; set; }

        [Required(ErrorMessage = "Company Type is required")]
        [Display(Name = "Company Type")]
        public string CompanyType { get; set; }

        [DisplayFormat(ConvertEmptyStringToNull = false)]
        public string Department { get; set; }

        [DisplayFormat(ConvertEmptyStringToNull = false)]
        [Display(Name = "Job Title")]
        public string JobTitle { get; set; }

        [Required(ErrorMessage = "Street Address 1 is required")]
        [Display(Name = "Street Address 1")]
        [RegularExpression(@"^[^\s].*", ErrorMessage = "Whitespace not allowed at the beginning")]
        public string Address1 { get; set; }

        [Display(Name = "Street Address 2")]
        [DisplayFormat(ConvertEmptyStringToNull = false)]
        public string Address2 { get; set; }

        [Required(ErrorMessage = "City is required")]
        public string City { get; set; }

        [Display(Name = "State/Province")]
        public string State { get; set; }

        [Required(ErrorMessage = "Postal Code is required")]
        [Display(Name = "Zip / Postal Code")]
        [RegularExpression(@"^[A-Za-z0-9]+$", ErrorMessage = "Postal Code will accept only alphanumeric characters")]
        public string Zipcode { get; set; }

        [Required(ErrorMessage = "Country is required")]
        public string Country { get; set; }

        [RegularExpression(@"^[0-9]{3}-[0-9]{3}-[0-9]{4}$", ErrorMessage = "This phone number entry is incorrect. Please follow the proper entry format (555-555-1212)")]
        [DisplayFormat(ConvertEmptyStringToNull = false)]
        public string Phone { get; set; }

        [DisplayFormat(ConvertEmptyStringToNull = false)]
        public string Fax { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [Display(Name = "Email")]
        [RegularExpression(@"^[A-Za-z0-9_.+%-]+@[A-Za-z0-9.-]+[.]+[A-Za-z]{2,3}$", ErrorMessage = "Email format is not correct")]
        public string Email { get; set; }

        [Display(Name = "Service Location")]
        public string ServiceLocation { get; set; }

        public string FooterVersion { get; set; }

        public string CurrentYear { get; set; }

        public bool IsRegistered { get; set; } = false;

        public string LoginUrl { get; set; } = "";
    }
}
