﻿using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Events;
using System.Diagnostics;

namespace CassPort.WebUI
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            CreateWebHostBuilder(args).Build().Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
             .ConfigureAppConfiguration((builderContext, config) =>
             {
                 if (Debugger.IsAttached)
                 {
                     config.AddJsonFile("appsettings.json");
                 }
                 else
                 {
                     config.SetBasePath(builderContext.HostingEnvironment.ContentRootPath)
                     .AddJsonFile($"appsettings.{builderContext.HostingEnvironment.EnvironmentName}.json", optional: false, reloadOnChange: false)
                     .AddEnvironmentVariables();
                 }
             })
                .ConfigureLogging((builderContext, loggingBuilder) =>
                {
                    // Clear all default logging providers
                    loggingBuilder.ClearProviders();

                    // Enable Microsoft Console Logging
                    loggingBuilder.AddConfiguration(builderContext.Configuration.GetSection("Logging"));

                })
            .UseStartup<Startup>();
                   

    }
}
