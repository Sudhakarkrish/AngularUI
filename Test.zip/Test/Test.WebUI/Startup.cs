﻿namespace CassPort.WebUI
{
    using CassPort.Core.Models;
    using CassPort.Infrastructure.Middleware;
    using CassPort.WebUI.Models;
    using Microsoft.AspNetCore.Authentication.Cookies;
    using Microsoft.AspNetCore.Authentication.OpenIdConnect;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Hosting;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.IdentityModel.Protocols.OpenIdConnect;
    using Serilog;
    using StackExchange.Profiling.Storage;
    using System;
    using System.Diagnostics;
    using System.Security.Claims;
    using System.Threading.Tasks;

    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Log.Logger = new LoggerConfiguration()
                           .ReadFrom.Configuration(configuration)
                           .CreateLogger();
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            AppConstants();
            services.AddOptions();
            services.AddCors();

            services.AddAuthentication(sharedOptions =>
            {
                sharedOptions.DefaultAuthenticateScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                sharedOptions.DefaultSignInScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                sharedOptions.DefaultChallengeScheme = OpenIdConnectDefaults.AuthenticationScheme;
            })
                .AddCookie(options =>
                {                   
                    options.SessionStore = new MemoryCacheTicketStore();
                    options.Cookie.Path = "/";
                })
             
                .AddOpenIdConnect(options =>
                {
                    options.CallbackPath = new PathString("/Home");
                    options.ClientSecret = Configuration.GetValue<string>("ClientSecret:Id");
                    if (Debugger.IsAttached)
                    {
                        // Client Id and Authority is set manually here so we can use "Development" settings while in debug mode without affecting mynew.dev settings
                        options.ClientId = Configuration.GetValue<string>("ClientId:Local");
                        options.Authority = Configuration.GetValue<string>("Authority:DevIdentityServer");
                        options.GetClaimsFromUserInfoEndpoint = true;
                        options.RequireHttpsMetadata = false;
                    }
                    else
                    {
                        options.ClientId = Configuration.GetValue<string>("ClientId:Local");
                        options.Authority = Configuration.GetValue<string>("Authority:DevIdentityServer");
                    }
                    options.ResponseType = OpenIdConnectResponseType.IdTokenToken;
                    options.Scope.Clear();
                    options.Scope.Add(OpenIdConnectScope.OpenIdProfile + " roles cisfbsys_account");                   
                    options.UseTokenLifetime = true;
                    options.Events = new OpenIdConnectEvents
                    {
                        OnRedirectToIdentityProvider = async context =>
                        {
                            await Task.FromResult(0);
                        },
                        OnMessageReceived = async context =>
                        {
                            await Task.FromResult(0);
                        },
                        OnTokenValidated = async context =>
                        {
                            var identity = (ClaimsIdentity)context.Principal.Identity;

                            // add access token for sample API
                            identity.AddClaim(new Claim("access_token", context.ProtocolMessage.AccessToken));

                            // keep track of access token expiration
                            identity.AddClaim(new Claim("expires_at",
                                DateTimeOffset.Now.AddSeconds(int.Parse(context.ProtocolMessage.ExpiresIn))
                                    .ToString()));

                            await Task.FromResult(0);
                        },
                        OnAuthorizationCodeReceived = async context =>
                        {
                            await Task.FromResult(0);
                        },
                        OnTokenResponseReceived = async context =>
                        {
                            await Task.FromResult(0);
                        },
                        OnTicketReceived = async context =>
                        {
                            //context.Principal = TransformClaims(context.Principal);
                            await Task.FromResult(0);
                        },
                        OnAuthenticationFailed = async context =>
                        {
                            await Task.FromResult(0);
                        },
                        OnUserInformationReceived = async context =>
                        {
                            // OIDC supports a separate endpoint for user information.
                            await Task.FromResult(0);
                        },
                        OnRemoteFailure = async context =>
                        {
                            await Task.FromResult(0);
                        }
                    };
                });

            // Get Application Name
            IConfigurationSection appConfig = this.Configuration.GetSection("Source");
            services.Configure<ApplicationConfig>(appConfig);
            services.AddScoped<UserProfile>();

            services.AddLogging((builder) =>
            {
                builder.AddSerilog(dispose: true);
            });

            //HttpContext.AuthenticateAsync("scheme1");
            services.Configure<CookiePolicyOptions>(options =>
            {
                //This lambda determines whether user consent for non - essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });

            services.AddMiniProfiler(options =>
            {
                // ALL of this is optional. You can simply call .AddMiniProfiler() for all defaults
                // Defaults: In-Memory for 30 minutes, everything profiled, every user can see

                // Path to use for profiler URLs, default is /mini-profiler-resources
                options.RouteBasePath = "/profiler";

                // Control storage - the default is 30 minutes
                (options.Storage as MemoryCacheStorage).CacheDuration = TimeSpan.FromMinutes(60);
                //options.Storage = new SqlServerStorage("Data Source=.;Initial Catalog=MiniProfiler;Integrated Security=True;");

                // Control which SQL formatter to use, InlineFormatter is the default
                options.SqlFormatter = new StackExchange.Profiling.SqlFormatters.SqlServerFormatter();

                // To control authorization, you can use the Func<HttpRequest, bool> options:
                //options.ResultsAuthorize = request => !Program.DisableProfilingResults;
                //options.ResultsListAuthorize = request => MyGetUserFunction(request).CanSeeMiniProfiler;

                // To control which requests are profiled, use the Func<HttpRequest, bool> option:
                //options.ShouldProfile = request => MyShouldThisBeProfiledFunction(request);

                // Profiles are stored under a user ID, function to get it:
                //options.UserIdProvider =  request => MyGetUserIdFunction(request);

                // Optionally swap out the entire profiler provider, if you want
                // The default handles async and works fine for almost all applications
                //options.ProfilerProvider = new MyProfilerProvider();

                // Optionally disable "Connection Open()", "Connection Close()" (and async variants).
                options.TrackConnectionOpenClose = false;
            });

            services.AddRazorPages();

            services.AddSpaStaticFiles(configuration =>
            {
                configuration.RootPath = "wwwroot/bundles";
            });

            services.AddMvc(option => option.EnableEndpointRouting = false);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                //app.UseMiniProfiler(); //Enable this line to track the performance
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }
            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseStaticFiles();
            app.UseCookiePolicy();
            app.UseSpaStaticFiles();

            app.UseCors(x => x
            .AllowAnyOrigin()
            .AllowAnyMethod()
            .AllowAnyHeader());

            app.UseHttpsRedirection();
            app.UseScopedLoggingMiddleware();
            app.UseExceptionMiddleware();
            
            app.UseEndpoints(endPoints =>
            {
                endPoints.MapControllerRoute("default", "{controller=Home}/{action=Index}/{id?}");
            });
        }  
        
        public void AppConstants()
        {
            AppSettingsProvider.DbConnectionString = Configuration.GetValue<string>("ConnectionStrings:CassPortConnection");
            AppSettingsProvider.ConnectionTimeOut = Configuration.GetValue<int>("ConnectionStrings:ConnectionTimeout");
            AppSettingsProvider.LoginUrl = Configuration.GetValue<string>("RedirectUrl:LoginUrl");
            AppSettingsProvider.HomeLink = Configuration.GetValue<string>("ForgotPassword:HomeLink");
            AppSettingsProvider.EmailServer = Configuration.GetValue<string>("ForgotPassword:EmailServer");
            AppSettingsProvider.EmailAlias = Configuration.GetValue<string>("ForgotPassword:EMAIL_ALIAS");
            AppSettingsProvider.ResetPassword = Configuration.GetValue<string>("ForgotPassword:ResetPassword");
            AppSettingsProvider.CancelResetPassword = Configuration.GetValue<string>("ForgotPassword:CancelResetPassword");
            AppSettingsProvider.Title = Configuration.GetValue<string>("ForgotPassword:Title");
            AppSettingsProvider.Message1 = Configuration.GetValue<string>("ForgotPassword:Message1");
            AppSettingsProvider.Message2 = Configuration.GetValue<string>("ForgotPassword:Message2");
            AppSettingsProvider.Message3 = Configuration.GetValue<string>("ForgotPassword:Message3");
            AppSettingsProvider.Message4 = Configuration.GetValue<string>("ForgotPassword:Message4");
            AppSettingsProvider.DisabledMessage = Configuration.GetValue<string>("ForgotPassword:DisabledMessage");

            AppSettingsProvider.PrivacyLink = Configuration.GetValue<string>("FooterLink:PrivacyLink");
            AppSettingsProvider.PrivacyText = Configuration.GetValue<string>("FooterText:PrivacyText");
            AppSettingsProvider.RateMakerLink = Configuration.GetValue<string>("FooterLink:RateMakerLink");
            AppSettingsProvider.RateMakerText = Configuration.GetValue<string>("FooterText:RateMakerText");
            AppSettingsProvider.SystemReqLink = Configuration.GetValue<string>("FooterLink:SystemReqLink");
            AppSettingsProvider.SystemRequirementText = Configuration.GetValue<string>("FooterText:SystemRequirementText");
            AppSettingsProvider.FrieghtLink = Configuration.GetValue<string>("FooterLink:FrieghtLink");
            AppSettingsProvider.FrieghtText = Configuration.GetValue<string>("FooterText:FrieghtText");
            AppSettingsProvider.ContactUsLink = Configuration.GetValue<string>("FooterLink:ContactUsLink");
            AppSettingsProvider.ContactUsText = Configuration.GetValue<string>("FooterText:ContactUsText");
            AppSettingsProvider.CassHomeLink = Configuration.GetValue<string>("FooterLink:CassHomeLink");
            AppSettingsProvider.CassHomeText = Configuration.GetValue<string>("FooterText:CassHomeText");
            AppSettingsProvider.CarrierLink = Configuration.GetValue<string>("FooterLink:CarrierLink");
            AppSettingsProvider.CarrierText = Configuration.GetValue<string>("FooterText:CarrierText");

            AppSettingsProvider.WebsiteNameEnv = Configuration.GetValue<string>("WebsiteName:Env");
            AppSettingsProvider.WebsiteName = Configuration.GetValue<string>("WebsiteName:Name");
        }
    }
}
