﻿function TryRegisterSubmit() {
    var msg = "";
    var bGood = true;
    if ($("#FirstName").val().trim().length === 0) {
        msg += "Please enter the user's first name.<br>";
        bGood = false;
    }

    if ($("#LastName").val().trim().length === 0) {
        msg += "Please enter the user's last name.<br>";
        bGood = false;
    }

    if ($("#CompanyName").val().trim().length === 0) {
        msg += "Please enter the user's Company Name.<br>";
        bGood = false;
    }

    if ($("#Address1").val().trim().length === 0) {
        msg += "Please enter the user's Street Address.<br>";
        bGood = false;
    }

    if ($("#City").val().trim().length === 0) {
        msg += "Please enter the user's City.<br>";
        bGood = false;
    }
    if ($("#State").children("option").length > 0 && $("#State").val().trim().length === 0) {
        msg += "Please enter the user's State.<br>";
        bGood = false;
    }
    if ($("#Country").val().trim().length === 0) {
        msg += "Please enter the user's Country.<br>";
        bGood = false;
    }
    if ($("#Zipcode").val().trim().length === 0) {
        msg += "Please enter the user's Zipcode.<br>";
        bGood = false;
    }

    var Phone = $("#Phone").val();

    if (Phone.length != 0 && (Phone.substring(3, 4) != "-" || Phone.substring(7, 8) != "-" || Phone.length != 12)) {
        msg += "This phone number entry is incorrect. Please follow the proper entry format (555-555-1212).<br>";
        bGood = false;
    }

    var Email = $("#Email").val();

    if (Email.length === 0) {
        msg += "Please enter the user's Internet Email Address.<br>";
        bGood = false;
    }
    else if (Email.indexOf(" ") !== -1) {
        msg += "The Email Address cannot contain spaces.<br>";
        bGood = false;
    }
    else if (Email.indexOf("@") === -1) {
        msg += "The Email Address must contain an @ (e.g. janesmith@mycompany.com).<br>";
        bGood = false;
    }
    else if (Email.indexOf(".") === -1) {
        msg += "The Email Address must contain a period ('dot') after your company name."
            + " (e.g. janesmith@mycompany.com).<br>";
        bGood = false;
    }

    if ($("#CompanyType").val().length === 0) {
        msg += "Please enter the user's Company Type.<br>";
        bGood = false;
    }

    if ($("#CompanyType").val() == "S") {
        if ($('#ServiceLocation').val().length === 0) {
            msg += "Please enter the user's Cass Service Location.<br>";
            bGood = false;
        }
    }
}

function TryForgotPasswordSubmit() {
    var msg = "";
    var bGood = true;
    if ($("#LoginId").val().trim().length === 0) {
        msg += "Please enter the user's Login ID.<br>";
        bGood = false;
    }

    var Email = $("#Email").val();

    if (Email.length === 0) {
        msg += "Please enter the user's Internet Email Address.<br>";
        bGood = false;
    }
    else if (Email.indexOf(" ") !== -1) {
        msg += "The Email Address cannot contain spaces.<br>";
        bGood = false;
    }
    else if (Email.indexOf("@") === -1) {
        msg += "The Email Address must contain an @ (e.g. janesmith@mycompany.com).<br>";
        bGood = false;
    }
    else if (Email.indexOf(".") === -1) {
        msg += "The Email Address must contain a period ('dot') after your company name."
            + " (e.g. janesmith@mycompany.com).<br>";
        bGood = false;
    }
}

function TryResetPasswordSubmit() {
    var msg = "";
    var bGood = true;
    if ($("#Password").val().trim().length === 0) {
        msg += "Please enter Password.<br>";
        bGood = false;
    }

    if ($("#ConfirmPassword").val().trim().length === 0) {
        msg += "Please enter Confirm Password.<br>";
        bGood = false;
    }
}


$(document).ready(function () {
    var pass = document.getElementById("Password");
    if (document.getElementById("resetpwd") !== null) {
        document.getElementById("resetpwd").style.display = "block";
    }
    if (document.getElementById("registeruser") !== null) {
        document.getElementById("registeruser").style.display = "block";
    }
    if (document.getElementById("forgotpwd") !== null) {
        document.getElementById("forgotpwd").style.display = "block";
    }
    if (document.getElementById("cancelresetpwd") !== null) {
        document.getElementById("cancelresetpwd").style.display = "block";
    }
    if (pass) {
        pass.addEventListener("keyup", function (event) {
            // set value of input field to variable
            var value = this.value;

            // fire function to test password strength
            passwordStrength(value);
        });
    }

    var confirmPass = document.getElementById("ConfirmPassword");
    if (confirmPass) {
        confirmPass.addEventListener("keyup", function (event) {
            // set value of input field to variable
            var value1 = this.value;

            // fire function to test password strength
            passwordcompare(document.getElementById("Password").value, value1);
        });
    }
});

function passwordcompare(password, confirmPassword) {
    var msg = "";
    var bGood = true;
    var pwdCompareResult = password.localeCompare(confirmPassword);
    if (pwdCompareResult !== 0) {
        msg += "Your new Password and Confirmation Password do not Match.<br>";
        bGood = false;
    }
}

function passwordStrength(password) {
    var desc = new Array();
    desc[0] = "Very Weak";
    desc[1] = "Very Weak";
    desc[2] = "Weak";
    desc[3] = "Medium";
    desc[4] = "Good";
    desc[5] = "Very Good";
    var score = 0;

    //if password bigger than 10 give 1 point

    if (password.length > 8) score++;

    //if password has lower characters give 1 point

    if (password.match(/[a-z]/)) score++;

    //if password has uppercase characters give 1 point

    if (password.match(/[A-Z]/)) score++;

    //if password has at least one number give 1 point

    if (password.match(/[0-9]/)) score++;

    //if password has at least one special caracther give 1 point

    if (password.match(/.[!,@,#,$,%,^,&,*,?,_,~,-,(,)]/)) score++;

    document.getElementById("passwordDescription").innerHTML = desc[score];
    document.getElementById("passwordStrength").className = "strength" + score;
}

function Validationcheck(e) {
    $("form").validate().element('#' + e.currentTarget.id);
}

function SpaceCheck(e) {
    var value = e.target.value;
    if (value.trim().length === 0 && e.which === 32) {
        e.preventDefault();
    }
}

function NoSpaceCheck(e) {
    if (e.which === 32) {
        e.preventDefault();
    }
}

$(function () {
    $("#Phone").on("keyup", function () {
        $(this).val($(this).val().replace(/^(\d{3})(\d{3})(\d{4})+$/, "$1-$2-$3"));
    });
});

$(function () {
    $("#Country").on("change", function () {
        let label = $('label[for="State"]');
        let input = $("#State");
        let parent = input.parent();
        input.remove();
        let stateSelections = countryRegions[$("#Country").val()];
        if (typeof stateSelections === "undefined" || stateSelections === null) {
            label.addClass("hidden");
            input = $('<input type="hidden" name="State" id="State"/>');
            $("#statediv").hide();
        } else {
            label.removeClass("hidden");
            input = $('<select name="State" id="State" class="col-md-12 pl-0 form-control"></select>');
            $("#statediv").show();
            $.each(stateSelections, function (index, item) {
                input.append($("<option>", {
                    value: item[0],
                    text: item[1]
                }));
            });
        }
        parent.append(input);
    });
});

$(function () {
    $("#Password").on("keyup", function () {
        jQuery.validator.addMethod("PasswordCheck", function (value, element) {
            if (CheckPassword(value) == false) {
                return false;  // FAIL validation when REGEX matches
            } else {
                return true;   // PASS validation otherwise
            };
        });
    });
});


$("form").validate({
    rules: {
        'Password': {
            PasswordCheck: true
        }
    },
    messages: {
        'Password': {
            PasswordCheck: "Password does not meet the password criteria"
        }
    }
});

function CheckPassword(MyPassword) {

    MyPassword = MyPassword.toUpperCase();

    var iLetter = 0;
    var iNumber = 0;
    var iOther = 0;
    var iTotal = 0;

    for (var i = 0; i < MyPassword.length; i++) {
        if (MyPassword.charCodeAt(i) >= 65 && MyPassword.charCodeAt(i) <= 90) {
            iLetter = 1;
        }
        if (MyPassword.charCodeAt(i) >= 48 && MyPassword.charCodeAt(i) <= 57) {
            iNumber = 1;
        }
        if ((MyPassword.charCodeAt(i) >= 0 && MyPassword.charCodeAt(i) <= 47)
            || (MyPassword.charCodeAt(i) >= 58 && MyPassword.charCodeAt(i) <= 64)
            || (MyPassword.charCodeAt(i) >= 91)) {
            iOther = 1;
        }
    }

    iTotal = iLetter + iNumber + iOther;

    if (iTotal < 2) {
        return false;
    }
    else {
        return true;
    }
}
